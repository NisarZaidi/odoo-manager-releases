#compdef odoo-manager

##############################################################################
# completion.zsh
# Zsh tab-completion for `odoo-manager`
#
# Suggests:
#   - top-level commands            (start, stop, restart, status, list, ...)
#   - flags for each command        (--workspace, --project, --json)
#   - real workspace names          (odoo17, odoo18, ...) after --workspace
#   - real project names            (agri, school, ...) after --project,
#     scoped to whichever --workspace was already typed on the line
#
# Installed automatically by scripts/install.sh. To load it manually in
# your current shell:
#
#   fpath+=(/path/to/odoo-development-manager/completion)
#   autoload -Uz compinit && compinit
#
# Respects ODOO_MANAGER_WORKSPACE_ROOT if set (falls back to the tool's
# own default of $HOME/Documents), so completion matches wherever your
# workspaces actually live.
##############################################################################

_odoo_manager_workspace_root()
{
    echo "${ODOO_MANAGER_WORKSPACE_ROOT:-$HOME/Documents}"
}

##############################################################################
# Complete workspace names (odoo9, odoo17, odoo18 ...)
##############################################################################

_odoo_manager_workspaces()
{

    local root="$(_odoo_manager_workspace_root)"
    local -a ws

    if [ -d "$root" ]
    then

        local d base

        for d in "$root"/odoo*(N/)
        do

            base="${d:t}"

            if [[ "$base" =~ ^odoo[0-9]+$ ]]
            then
                ws+=("$base")
            fi

        done

    fi

    _describe -t workspaces 'workspace' ws

}

##############################################################################
# Complete project names inside the --workspace already typed on the line
##############################################################################

_odoo_manager_projects()
{

    local root="$(_odoo_manager_workspace_root)"
    local ws_name=""

    local i
    for (( i = 1; i <= ${#words[@]}; i++ ))
    do

        if [[ "${words[i]}" == "--workspace" && -n "${words[i+1]}" ]]
        then
            ws_name="${words[i+1]}"
            break
        fi

    done

    local -a projects
    local projects_dir="$root/$ws_name/projects"

    if [ -n "$ws_name" ] && [ -d "$projects_dir" ]
    then

        local p

        for p in "$projects_dir"/*(N/)
        do
            projects+=("${p:t}")
        done

    fi

    _describe -t projects 'project' projects

}

##############################################################################
# Main Completion Entry Point
##############################################################################

_odoo_manager()
{

    local -a commands
    commands=(
        'start:Start Odoo for a workspace'
        'stop:Stop Odoo for a workspace'
        'restart:Restart Odoo for a workspace'
        'status:Show status of one or all workspaces'
        'list:List all workspaces'
        'doctor:Show workspace health'
        'check-db-connection:Check PostgreSQL connectivity'
        '--auto-update:Auto git pull if an update is found'
        '--help:Show CLI help'
        '--version:Show installed version'
    )

    if (( CURRENT == 2 ))
    then
        _describe -t commands 'odoo-manager command' commands
        return
    fi

    local cmd="${words[2]}"

    case "$cmd" in

        start|restart)

            _arguments \
                '--workspace[Workspace name]:workspace:_odoo_manager_workspaces' \
                '--project[Project name]:project:_odoo_manager_projects'
            ;;

        stop)

            _arguments \
                '--workspace[Workspace name]:workspace:_odoo_manager_workspaces'
            ;;

        status)

            _arguments \
                '--workspace[Workspace name]:workspace:_odoo_manager_workspaces' \
                '--json[Output as JSON]'
            ;;

        list)

            _arguments \
                '--json[Output as JSON]'
            ;;

        doctor)

            _arguments \
                '--workspace[Workspace name]:workspace:_odoo_manager_workspaces' \
                '--json[Output as JSON]'
            ;;

        *)
            ;;

    esac

}

_odoo_manager "$@"
