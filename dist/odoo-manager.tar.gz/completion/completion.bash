#!/bin/bash

##############################################################################
# completion.bash
# Bash tab-completion for `odoo-manager`
#
# Suggests:
#   - top-level commands            (start, stop, restart, status, list, ...)
#   - flags for each command        (--workspace, --project, --json)
#   - real workspace names          (odoo17, odoo18, ...) after --workspace
#   - real project names            (agri, school, ...) after --project,
#     scoped to whichever --workspace was already typed on the line
#
# Installed automatically by scripts/install.sh. To load it manually in
# your current shell:
#
#   source completion/completion.bash
#
# Respects ODOO_MANAGER_WORKSPACE_ROOT if set (falls back to the tool's
# own default of $HOME/Documents), so completion matches wherever your
# workspaces actually live.
##############################################################################

_odoo_manager_workspace_root()
{
    echo "${ODOO_MANAGER_WORKSPACE_ROOT:-$HOME/Documents}"
}

##############################################################################
# List existing workspace folder names (odoo9, odoo17, odoo18 ...)
##############################################################################

_odoo_manager_list_workspaces()
{

    local ROOT
    ROOT="$(_odoo_manager_workspace_root)"

    [ -d "$ROOT" ] || return

    local WS BASENAME

    for WS in "$ROOT"/odoo*
    do

        [ -d "$WS" ] || continue

        BASENAME="$(basename "$WS")"

        if [[ "$BASENAME" =~ ^odoo[0-9]+$ ]]
        then
            echo "$BASENAME"
        fi

    done

}

##############################################################################
# List project names inside a given workspace's projects/ folder
##############################################################################

_odoo_manager_list_projects()
{

    local WS_NAME="$1"
    local ROOT
    ROOT="$(_odoo_manager_workspace_root)"

    local PROJECTS_DIR="$ROOT/$WS_NAME/projects"

    [ -d "$PROJECTS_DIR" ] || return

    local P

    for P in "$PROJECTS_DIR"/*
    do
        [ -d "$P" ] && basename "$P"
    done

}

##############################################################################
# Find the --workspace value already typed earlier on the current line,
# so --project completion can be scoped to the right workspace.
##############################################################################

_odoo_manager_find_typed_workspace()
{

    local i

    for (( i = 1; i < COMP_CWORD; i++ ))
    do

        if [ "${COMP_WORDS[i]}" = "--workspace" ] && [ -n "${COMP_WORDS[i+1]}" ]
        then
            echo "${COMP_WORDS[i+1]}"
            return
        fi

    done

}

##############################################################################
# Main Completion Function
##############################################################################

_odoo_manager_completions()
{

    local cur prev

    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"

    local COMMANDS="start stop restart status list doctor check-db-connection --auto-update --version --help -h help"

    # Figure out which subcommand is being completed (first non-flag word)
    local CMD=""
    local i

    for (( i = 1; i < COMP_CWORD; i++ ))
    do

        case "${COMP_WORDS[i]}" in
            --*)
                ;;
            *)
                CMD="${COMP_WORDS[i]}"
                break
                ;;
        esac

    done

    # Completing the value right after --workspace / --project
    case "$prev" in

        --workspace)

            COMPREPLY=( $(compgen -W "$(_odoo_manager_list_workspaces)" -- "$cur") )
            return 0
            ;;

        --project)

            local WS_NAME
            WS_NAME="$(_odoo_manager_find_typed_workspace)"

            COMPREPLY=( $(compgen -W "$(_odoo_manager_list_projects "$WS_NAME")" -- "$cur") )
            return 0
            ;;

    esac

    # Completing the subcommand itself (first argument)
    if [ "$COMP_CWORD" -eq 1 ]
    then
        COMPREPLY=( $(compgen -W "$COMMANDS" -- "$cur") )
        return 0
    fi

    # Completing flags, based on which subcommand was already typed
    case "$CMD" in

        start|restart)
            COMPREPLY=( $(compgen -W "--workspace --project" -- "$cur") )
            ;;

        stop)
            COMPREPLY=( $(compgen -W "--workspace" -- "$cur") )
            ;;

        status)
            COMPREPLY=( $(compgen -W "--workspace --json" -- "$cur") )
            ;;

        list)
            COMPREPLY=( $(compgen -W "--json" -- "$cur") )
            ;;

        doctor)
            COMPREPLY=( $(compgen -W "--workspace --json" -- "$cur") )
            ;;

        *)
            COMPREPLY=()
            ;;

    esac

    return 0

}

complete -F _odoo_manager_completions odoo-manager
