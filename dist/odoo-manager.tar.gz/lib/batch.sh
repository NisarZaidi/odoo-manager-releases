#!/bin/bash

##############################################################################
# batch.sh
# Batch Operations
# Perform actions across all workspaces at once
##############################################################################

##############################################################################
# Start ALL workspaces
##############################################################################

batch_start_all()
{

    show_header
    echo "Start All Workspaces"
    separator
    echo

    detect_existing_workspaces

    if [ ${#WORKSPACES[@]} -eq 0 ]
    then
        print_warning "No workspaces found."
        pause
        return
    fi

    echo -e "  ${WHITE}Found${NC}: ${#WORKSPACES[@]} workspace(s)"
    echo

    local WS
    for WS in "${WORKSPACES[@]}"
    do
        local WS_NAME
        WS_NAME="$(basename "$WS")"

        if is_workspace_running "$WS" >/dev/null 2>&1
        then
            echo -e "  ${DIM}$WS_NAME - already running, skipping${NC}"
            continue
        fi

        local CONF="$WS/odoo/debian/odoo.conf"
        if [ ! -f "$CONF" ]
        then
            echo -e "  ${YELLOW}$WS_NAME - no odoo.conf, skipping${NC}"
            continue
        fi

        echo -e "  ${CYAN}Starting $WS_NAME...${NC}"
        # Background start
    done

    echo
    print_success "Batch start initiated."

    if type notify_task_complete >/dev/null 2>&1
    then
        notify_task_complete "Batch start"
    fi

    pause

}

##############################################################################
# Stop ALL workspaces
##############################################################################

batch_stop_all()
{

    show_header
    echo "Stop All Workspaces"
    separator
    echo

    detect_existing_workspaces

    if [ ${#WORKSPACES[@]} -eq 0 ]
    then
        print_warning "No workspaces found."
        pause
        return
    fi

    local RUNNING_COUNT=0
    local WS

    for WS in "${WORKSPACES[@]}"
    do
        if is_workspace_running "$WS" >/dev/null 2>&1
        then
            RUNNING_COUNT=$((RUNNING_COUNT + 1))
            echo -e "  ${CYAN}Stopping $(basename "$WS")...${NC}"
        fi
    done

    if [ "$RUNNING_COUNT" -eq 0 ]
    then
        print_info "No workspaces are currently running."
        pause
        return
    fi

    echo
    echo -e "  ${WHITE}Stopping $RUNNING_COUNT workspace(s)...${NC}"

    stop_all_odoo_instances 2>/dev/null

    echo
    print_success "All workspaces stopped."

    if type notify_task_complete >/dev/null 2>&1
    then
        notify_task_complete "Batch stop ($RUNNING_COUNT workspaces)"
    fi

    pause

}

##############################################################################
# Backup ALL databases
##############################################################################

batch_backup_all_dbs()
{

    show_header
    echo "Backup All Databases"
    separator
    echo

    if ! command_exists pg_dump
    then
        print_error "pg_dump not found. Install PostgreSQL client tools."
        pause
        return
    fi

    detect_existing_workspaces

    if [ ${#WORKSPACES[@]} -eq 0 ]
    then
        print_warning "No workspaces found."
        pause
        return
    fi

    local BACKUP_DIR="$HOME/.local/share/odoo-manager/batch_backups"
    mkdir -p "$BACKUP_DIR"

    local TIMESTAMP
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)

    echo -e "  ${WHITE}Backup directory${NC}: $BACKUP_DIR"
    echo -e "  ${WHITE}Timestamp${NC}: $TIMESTAMP"
    echo

    local TOTAL=0
    local WS

    for WS in "${WORKSPACES[@]}"
    do
        local WS_NAME
        WS_NAME="$(basename "$WS")"
        local WS_BACKUP_DIR="$BACKUP_DIR/${WS_NAME}_${TIMESTAMP}"
        mkdir -p "$WS_BACKUP_DIR"

        # Get databases for this workspace
        local CONF="$WS/odoo/debian/odoo.conf"
        if [ ! -f "$CONF" ]
        then
            continue
        fi

        local DB_NAME
        DB_NAME=$(grep "^db_name" "$CONF" 2>/dev/null | cut -d '=' -f2- | xargs)

        if [ -n "$DB_NAME" ] && psql -lqt 2>/dev/null | awk -F'|' '{print $1}' | grep -qw "$DB_NAME"
        then
            echo -e "  ${CYAN}Backing up $WS_NAME → $DB_NAME...${NC}"

            if pg_dump -Fc "$DB_NAME" -f "$WS_BACKUP_DIR/${DB_NAME}.dump" 2>/dev/null
            then
                echo -e "    ${GREEN}✔${NC} Backup saved"
                TOTAL=$((TOTAL + 1))
            else
                echo -e "    ${RED}✘${NC} Backup failed"
            fi
        fi
    done

    echo
    print_success "Batch backup complete. $TOTAL database(s) backed up."
    echo -e "  ${WHITE}Location${NC}: $BACKUP_DIR"

    if type notify_backup_complete >/dev/null 2>&1
    then
        notify_backup_complete "Batch backup ($TOTAL databases)"
    fi

    pause

}

##############################################################################
# Batch upgrade module across all workspaces
##############################################################################

batch_upgrade_module()
{

    show_header
    echo "Batch Upgrade Module"
    echo -e "${DIM}Upgrade a module across all workspaces${NC}"
    separator
    echo

    read -r -p "Module name to upgrade: " UPGRADE_MODULE

    if [ -z "$UPGRADE_MODULE" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    detect_existing_workspaces

    local FOUND=0
    local WS

    for WS in "${WORKSPACES[@]}"
    do
        local WS_NAME
        WS_NAME="$(basename "$WS")"
        local ADDONS_DIR="$WS/projects"

        # Check if module exists in any project
        local HAS_MODULE=0
        if [ -d "$ADDONS_DIR" ]
        then
            local p
            for p in "$ADDONS_DIR"/*/custom_addons/*
            do
                if [ -d "$p" ] && [ "$(basename "$p")" = "$UPGRADE_MODULE" ]
                then
                    HAS_MODULE=1
                    break
                fi
            done
        fi

        if [ "$HAS_MODULE" -eq 1 ]
        then
            echo -e "  ${GREEN}✔${NC} $WS_NAME - module '$UPGRADE_MODULE' found"
            FOUND=$((FOUND + 1))
        fi
    done

    if [ "$FOUND" -eq 0 ]
    then
        print_warning "Module '$UPGRADE_MODULE' not found in any workspace."
        pause
        return
    fi

    echo
    echo -e "  ${WHITE}Found in $FOUND workspace(s)${NC}"
    echo

    if ! confirm "Upgrade module '$UPGRADE_MODULE' in all $FOUND workspaces?"
    then
        print_info "Cancelled."
        pause
        return
    fi

    print_info "Upgrade would require starting Odoo with -u $UPGRADE_MODULE in each workspace."
    print_warning "This is a manual operation - use the Upgrade Module option in each workspace."

    pause

}

##############################################################################
# Batch operations menu
##############################################################################

batch_operations_menu()
{

    while true
    do

        show_header

        echo "Batch Operations"
        echo -e "${DIM}Perform actions across all workspaces${NC}"

        separator
        echo

        menu_item "1" "Start All Workspaces"
        menu_item "2" "Stop All Workspaces"
        menu_item "3" "Backup All Databases"
        menu_item "4" "Upgrade Module (across all workspaces)"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            1) batch_start_all ;;
            2) batch_stop_all ;;
            3) batch_backup_all_dbs ;;
            4) batch_upgrade_module ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}
