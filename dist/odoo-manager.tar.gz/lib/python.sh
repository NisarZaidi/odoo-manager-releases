#!/bin/bash

##############################################################################
# python.sh
# Version-Aware Python Management (via pyenv)
#
# Problem this solves:
#   Odoo 13/14 need Python 3.8, which is NOT in Ubuntu 22.04+/24.04's
#   default apt repos ("Unable to locate package python3.8"). Relying on
#   system python3 for venv creation silently breaks older workspaces on
#   newer Ubuntu releases.
#
# Fix:
#   Every workspace's venv is built from a pyenv-managed Python that
#   matches the Odoo version being installed, not whatever python3
#   happens to be on PATH. pyenv itself, its build deps, and the
#   specific Python version are all installed automatically and
#   idempotently - safe to call every time, does nothing if already
#   present.
##############################################################################

PYENV_ROOT_DEFAULT="$HOME/.pyenv"

##############################################################################
# Odoo Version -> Required Python Version
#
# Source: Odoo's own officially supported Python versions per series.
# Extend this table as new Odoo versions are released.
##############################################################################

odoo_required_python_version()
{

    local ODOO_VERSION="$1"

    case "$ODOO_VERSION" in

        9|10|11|12)   echo "2.7.18"  ;;   # legacy - py2, not handled by this script
        13|14)        echo "3.8.20"  ;;
        15|16|17)     echo "3.10.14" ;;
        18)           echo "3.11.9"  ;;
        19)           echo "3.12.6"  ;;

        *)
            # Unknown/future version - default to the newest mapped version
            # rather than failing outright.
            echo "3.12.6"
            ;;

    esac

}

##############################################################################
# Is pyenv Installed?
##############################################################################

pyenv_is_installed()
{

    [ -d "$PYENV_ROOT_DEFAULT/bin" ] || command_exists pyenv

}

##############################################################################
# Load pyenv Into The Current Shell Session (idempotent)
#
# Needed because a freshly-installed pyenv isn't on PATH until the shell
# is reloaded - this makes it usable immediately, in the same run.
##############################################################################

pyenv_load()
{

    export PYENV_ROOT="${PYENV_ROOT:-$PYENV_ROOT_DEFAULT}"

    if [ -d "$PYENV_ROOT/bin" ] && [[ ":$PATH:" != *":$PYENV_ROOT/bin:"* ]]
    then
        export PATH="$PYENV_ROOT/bin:$PATH"
    fi

    if command_exists pyenv
    then
        eval "$(pyenv init - bash 2>/dev/null)"
    fi

}

##############################################################################
# Ensure Build Dependencies (required to COMPILE any Python version)
##############################################################################

ensure_python_build_deps()
{

    if ! command_exists apt-get
    then
        print_warning "Automatic build-dependency install only supports apt-get (Debian/Ubuntu)."
        print_warning "Please install Python build dependencies manually before continuing."
        return 1
    fi

    local DEPS=(
        build-essential curl git
        libssl-dev zlib1g-dev libbz2-dev
        libreadline-dev libsqlite3-dev
        libncursesw5-dev xz-utils tk-dev
        libxml2-dev libxmlsec1-dev libffi-dev
        liblzma-dev llvm
    )

    # Only install what's actually missing
    local MISSING=()
    local PKG

    for PKG in "${DEPS[@]}"
    do
        dpkg -s "$PKG" >/dev/null 2>&1 || MISSING+=("$PKG")
    done

    if [ ${#MISSING[@]} -eq 0 ]
    then
        return 0
    fi

    require_sudo || return 1

    print_info "Installing Python build dependencies (${#MISSING[@]} package(s))..."

    sudo apt-get update -y
    sudo apt-get install -y "${MISSING[@]}"

}

##############################################################################
# Ensure pyenv Itself Is Installed
##############################################################################

ensure_pyenv_installed()
{

    if pyenv_is_installed
    then
        pyenv_load
        return 0
    fi

    print_info "pyenv not found - installing (needed to manage multiple Python versions safely)..."

    if ! command_exists curl
    then
        print_error "curl is required to install pyenv. Install it first (sudo apt-get install curl)."
        return 1
    fi

    ensure_python_build_deps || return 1

    if ! curl -fsSL https://pyenv.run | bash
    then
        print_error "pyenv installation failed."
        return 1
    fi

    pyenv_load

    # Persist for future shells (only if not already there)
    local RC
    for RC in "$HOME/.bashrc" "$HOME/.zshrc"
    do

        [ -f "$RC" ] || continue

        if ! grep -q 'PYENV_ROOT' "$RC"
        then

            {
                echo
                echo '# pyenv (added by odoo-manager)'
                echo 'export PYENV_ROOT="$HOME/.pyenv"'
                echo '[[ -d $PYENV_ROOT/bin ]] && export PATH="$PYENV_ROOT/bin:$PATH"'
                echo 'eval "$(pyenv init - bash)"'
            } >> "$RC"

        fi

    done

    if ! command_exists pyenv
    then
        print_error "pyenv was installed but is not available in this session."
        print_warning "Restart your terminal (or: source ~/.bashrc) and re-run odoo-manager."
        return 1
    fi

    print_success "pyenv installed."

    return 0

}

##############################################################################
# Ensure A Specific Python Version Is Installed Under pyenv
##############################################################################

ensure_python_version_installed()
{

    local PY_VERSION="$1"

    ensure_pyenv_installed || return 1

    if pyenv versions --bare 2>/dev/null | grep -qx "$PY_VERSION"
    then
        return 0
    fi

    ensure_python_build_deps || return 1

    print_info "Building Python $PY_VERSION via pyenv (this can take a few minutes, one-time only)..."
    echo

    if ! pyenv install -s "$PY_VERSION"
    then
        print_error "Failed to build Python $PY_VERSION."
        echo "Common cause: missing build dependencies. Try installing manually and retry:"
        echo "  sudo apt-get install -y build-essential libssl-dev zlib1g-dev libbz2-dev \\"
        echo "    libreadline-dev libsqlite3-dev libncursesw5-dev xz-utils tk-dev \\"
        echo "    libxml2-dev libxmlsec1-dev libffi-dev liblzma-dev llvm"
        return 1
    fi

    print_success "Python $PY_VERSION ready."

    return 0

}

##############################################################################
# Get The Full Path To A pyenv-managed Python Binary
##############################################################################

pyenv_python_bin()
{

    local PY_VERSION="$1"

    pyenv_load

    echo "${PYENV_ROOT:-$PYENV_ROOT_DEFAULT}/versions/$PY_VERSION/bin/python3"

}

##############################################################################
# Create A Workspace's venv Using The Correct Python Version For Its
# Odoo Series. THIS is what wizard.sh should call instead of a bare
# "python3 -m venv".
#
# Usage: create_odoo_venv <workspace_path> <odoo_version>
# Returns 0 on success, 1 on failure. Prints status as it goes.
##############################################################################

create_odoo_venv()
{

    local WORKSPACE_PATH="$1"
    local ODOO_VERSION="$2"

    local PY_VERSION
    PY_VERSION="$(odoo_required_python_version "$ODOO_VERSION")"

    print_info "Odoo $ODOO_VERSION requires Python $PY_VERSION"

    if ! ensure_python_version_installed "$PY_VERSION"
    then

        print_warning "Falling back to system python3 (may not be fully compatible with Odoo $ODOO_VERSION)."

        if command_exists python3
        then
            python3 -m venv "$WORKSPACE_PATH/env"
            return $?
        else
            print_error "No usable Python found. Cannot create virtual environment."
            return 1
        fi

    fi

    local PY_BIN
    PY_BIN="$(pyenv_python_bin "$PY_VERSION")"

    if [ ! -x "$PY_BIN" ]
    then
        print_error "pyenv reported Python $PY_VERSION as installed, but $PY_BIN is missing."
        return 1
    fi

    print_info "Creating virtual environment with Python $PY_VERSION..."

    "$PY_BIN" -m venv "$WORKSPACE_PATH/env"

}
