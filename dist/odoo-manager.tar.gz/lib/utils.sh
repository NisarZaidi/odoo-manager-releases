#!/bin/bash

##############################################################################
# utils.sh
# Common Utility Functions
##############################################################################

##############################################################################
# Colors
##############################################################################

# shellcheck disable=SC2034 # these are consumed by other sourced lib files (ui.sh, project.sh, etc.), not this one
RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
BLUE="\033[0;34m"
CYAN="\033[0;36m"
WHITE="\033[1;37m"
BOLD="\033[1m"
DIM="\033[2m"
NC="\033[0m"

##############################################################################
# Print Helpers
##############################################################################

print_success()
{
    echo -e "${GREEN}$1${NC}"
}

print_error()
{
    echo -e "${RED}$1${NC}"
}

print_warning()
{
    echo -e "${YELLOW}$1${NC}"
}

print_info()
{
    echo -e "${CYAN}$1${NC}"
}

print_title()
{
    echo
    echo -e "${BLUE}$1${NC}"
    echo
}

##############################################################################
# Pause
##############################################################################

pause()
{
    echo
    read -r -p "Press Enter to continue..."
}

##############################################################################
# Confirm
##############################################################################

confirm()
{

    local MESSAGE="${1:-Continue?}"

    read -r -p "$MESSAGE (Y/n): " ANSWER

    case "$ANSWER" in

        ""|Y|y)
            return 0
            ;;

        *)
            return 1
            ;;

    esac

}

##############################################################################
# Check Command
##############################################################################

command_exists()
{
    command -v "$1" >/dev/null 2>&1
}

##############################################################################
# Check If Port Is In Use
##############################################################################

is_port_in_use()
{

    local PORT="$1"

    if command_exists lsof
    then
        lsof -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1
        return $?
    fi

    if command_exists ss
    then
        ss -ltn 2>/dev/null | awk '{print $4}' | grep -q ":$PORT\$"
        return $?
    fi

    if command_exists netstat
    then
        netstat -ltn 2>/dev/null | awk '{print $4}' | grep -q ":$PORT\$"
        return $?
    fi

    # No tool available to check - assume free
    return 1

}

##############################################################################
# Check Required Software
##############################################################################

check_required_commands()
{

    # Maps the command we check for -> the apt package that provides it
    local REQUIRED_CMDS=(git python3 pip3 psql)
    local REQUIRED_PKGS=(git python3 python3-pip postgresql)

    local MISSING_CMDS=()
    local MISSING_PKGS=()

    print_title "Checking System Requirements"

    local i
    for i in "${!REQUIRED_CMDS[@]}"
    do

        local CMD="${REQUIRED_CMDS[$i]}"

        if command_exists "$CMD"
        then
            print_success "✔ $CMD"
        else
            print_error "✘ $CMD not installed"
            MISSING_CMDS+=("$CMD")
            MISSING_PKGS+=("${REQUIRED_PKGS[$i]}")
        fi

    done

    # python3-venv is required to create workspace virtual environments,
    # but has no standalone command to probe for - check it separately.
    if ! python3 -m venv --help >/dev/null 2>&1
    then
        print_error "✘ python3-venv not installed"
        MISSING_PKGS+=("python3-venv")
    else
        print_success "✔ python3-venv"
    fi

    if [ ${#MISSING_PKGS[@]} -eq 0 ]
    then
        return 0
    fi

    echo

    if ! command_exists apt-get
    then

        print_error "Missing packages: ${MISSING_PKGS[*]}"
        echo
        print_warning "Automatic install is only supported on Debian/Ubuntu (apt-get)."
        echo "Please install these manually, then re-run odoo-manager."
        echo
        exit 1

    fi

    print_warning "This is a Linux system - the following packages can be installed automatically:"
    echo

    local PKG
    for PKG in "${MISSING_PKGS[@]}"
    do
        echo "  - $PKG"
    done

    echo

    if confirm "Install missing packages now? (requires sudo)"
    then

        if ! require_sudo
        then
            exit 1
        fi

        loading "Installing missing system requirements..."

        sudo apt-get update -y

        if sudo apt-get install -y "${MISSING_PKGS[@]}"
        then

            print_success "System requirements installed successfully."
            echo

        else

            print_error "Package installation failed. Please install manually:"
            echo "  sudo apt-get install ${MISSING_PKGS[*]}"
            echo
            exit 1

        fi

    else

        print_error "Cannot continue without: ${MISSING_PKGS[*]}"
        echo
        exit 1

    fi

}

##############################################################################
# Sudo Preflight Check
#
# Warns the user clearly before any step that will invoke sudo, so a
# password prompt never appears out of nowhere. Returns 1 (and prints an
# error) only if sudo itself isn't installed at all - a genuinely
# unrecoverable case for automatic installs.
##############################################################################

require_sudo()
{

    if ! command_exists sudo
    then
        print_error "'sudo' is not available on this system."
        echo "Install the required package(s) manually as root, then re-run this."
        return 1
    fi

    if ! sudo -n true 2>/dev/null
    then
        print_warning "This step needs administrator privileges."
        echo -e "${DIM}You may be prompted for your sudo password below.${NC}"
        echo
    fi

    return 0

}

##############################################################################
# Individual Requirement Installers (Linux / apt-get only)
#
# Each one is safe to run any time - checks first, installs only if
# missing. Used both by check_required_commands (bulk, startup) and by
# system_requirements_menu (on-demand, one at a time).
##############################################################################

_apt_install_pkg()
{

    local LABEL="$1"
    shift
    local PKGS=("$@")

    if ! command_exists apt-get
    then
        print_warning "Automatic install only supports apt-get (Debian/Ubuntu)."
        return 1
    fi

    require_sudo || return 1

    print_info "Installing $LABEL (requires sudo)..."
    echo

    sudo apt-get update -y

    if sudo apt-get install -y "${PKGS[@]}"
    then
        print_success "$LABEL installed successfully."
        return 0
    else
        print_error "$LABEL installation failed."
        return 1
    fi

}

install_git()
{

    show_header
    echo "Install Git"
    separator
    echo

    if command_exists git
    then
        print_success "Git is already installed."
        pause
        return 0
    fi

    _apt_install_pkg "Git" git
    pause

}

install_python3()
{

    show_header
    echo "Install Python 3"
    separator
    echo

    if command_exists python3 && python3 -m venv --help >/dev/null 2>&1
    then
        print_success "Python 3 (with venv) is already installed."
        pause
        return 0
    fi

    _apt_install_pkg "Python 3" python3 python3-venv
    pause

}

install_pip()
{

    show_header
    echo "Install pip"
    separator
    echo

    if command_exists pip3
    then
        print_success "pip is already installed."
        pause
        return 0
    fi

    _apt_install_pkg "pip" python3-pip
    pause

}

install_postgresql()
{

    show_header
    echo "Install PostgreSQL"
    separator
    echo

    if command_exists psql
    then
        print_success "PostgreSQL client is already installed."
        pause
        return 0
    fi

    if _apt_install_pkg "PostgreSQL" postgresql postgresql-contrib libpq-dev
    then

        if command_exists systemctl
        then
            sudo systemctl enable --now postgresql >/dev/null 2>&1
        fi

        print_info "PostgreSQL service started."

    fi

    pause

}

install_openssl()
{

    show_header
    echo "Install openssl"
    separator
    echo

    if command_exists openssl
    then
        print_success "openssl is already installed."
        pause
        return 0
    fi

    _apt_install_pkg "openssl" openssl
    pause

}

install_build_essential()
{

    show_header
    echo "Install Build Tools (build-essential)"
    separator
    echo

    if command_exists gcc
    then
        print_success "build-essential is already installed."
        pause
        return 0
    fi

    _apt_install_pkg "build-essential" build-essential
    pause

}

##############################################################################
# Requirement Status Badge (used by system_requirements_menu)
##############################################################################

requirement_status_badge()
{

    if "$@" >/dev/null 2>&1
    then
        echo -e "${GREEN}✔ Installed${NC}"
    else
        echo -e "${DIM}✘ Not installed${NC}"
    fi

}

_check_git()         { command_exists git; }
_check_python3()     { command_exists python3 && python3 -m venv --help >/dev/null 2>&1; }
_check_pip()         { command_exists pip3; }
_check_postgresql()  { command_exists psql; }
_check_openssl()     { command_exists openssl; }

##############################################################################
# System Requirements Menu (install any/all requirements, one at a time)
##############################################################################

system_requirements_menu()
{

    while true
    do

        show_header

        echo "Install System Requirements"
        echo -e "${DIM}Linux (Debian/Ubuntu) only - installs via apt-get, asks for sudo when needed.${NC}"

        separator
        echo

        printf "  ${GREEN}1${NC}) %-18s %b\n" "Git"         "$(requirement_status_badge _check_git)"
        printf "  ${GREEN}2${NC}) %-18s %b\n" "Python 3"    "$(requirement_status_badge _check_python3)"
        printf "  ${GREEN}3${NC}) %-18s %b\n" "pip"         "$(requirement_status_badge _check_pip)"
        printf "  ${GREEN}4${NC}) %-18s %b\n" "PostgreSQL"  "$(requirement_status_badge _check_postgresql)"
        printf "  ${GREEN}5${NC}) %-18s %b\n" "openssl"     "$(requirement_status_badge _check_openssl)"
        printf "  ${GREEN}6${NC}) %-18s %b\n" "build tools" "$(requirement_status_badge command_exists gcc)"

        echo
        menu_section "Bulk Actions"
        menu_item "A" "Install All Missing"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in

            1) install_git ;;
            2) install_python3 ;;
            3) install_pip ;;
            4) install_postgresql ;;
            5) install_openssl ;;
            6) install_build_essential ;;

            A|a)

                _check_git        || install_git
                _check_python3    || install_python3
                _check_pip        || install_pip
                _check_postgresql || install_postgresql
                _check_openssl    || install_openssl
                command_exists gcc || install_build_essential

                ;;

            B|b)
                return
                ;;

            *)
                invalid_option
                ;;

        esac

    done

}

##############################################################################
# Create Directory
##############################################################################

create_directory()
{

    local DIR="$1"

    if [ ! -d "$DIR" ]
    then
        mkdir -p "$DIR"
    fi

}

##############################################################################
# Create File
##############################################################################

create_file()
{

    local FILE="$1"

    if [ ! -f "$FILE" ]
    then
        touch "$FILE"
    fi

}

##############################################################################
# Get Absolute Path
##############################################################################

absolute_path()
{
    realpath "$1"
}

##############################################################################
# Spinner
##############################################################################

spinner()
{

    local PID=$!

    local DELAY=0.10

    local SPIN='|/-\'

    while ps -p "$PID" >/dev/null 2>&1
    do

        for i in $(seq 0 3)
        do
            printf "\r[%c] Working..." "${SPIN:$i:1}"
            sleep $DELAY
        done

    done

    printf "\r"

}

##############################################################################
# Version Exists
##############################################################################

workspace_exists()
{

    local VERSION="$1"

    if [ -d "$WORKSPACE_ROOT/$VERSION" ]
    then
        return 0
    fi

    return 1

}

##############################################################################
# Get Workspace Path
##############################################################################

workspace_path()
{
    echo "$WORKSPACE_ROOT/$1"
}

##############################################################################
# Header Line
##############################################################################

line()
{
    echo -e "${CYAN}──────────────────────────────────────────────${NC}"
}

##############################################################################
# Exit With Error
#
# Prints the message to the screen (as before) AND appends a timestamped
# copy to a central error.log so failures leave a persistent trail for
# debugging, even after the terminal is closed.
##############################################################################

get_error_log_file()
{

    if [ -n "$ROOT_DIR" ]
    then
        echo "$ROOT_DIR/error.log"
    else
        echo "$HOME/.odoo-manager-error.log"
    fi

}

log_error()
{

    local MSG="$1"
    local ERR_LOG
    ERR_LOG="$(get_error_log_file)"

    {
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] $MSG"
    } >> "$ERR_LOG" 2>/dev/null

}

die()
{
    print_error "$1"
    log_error "$1"
    exit 1
}

##############################################################################
# Center Text (used for header box)
##############################################################################

center_text()
{

    local TEXT="$1"
    local WIDTH="$2"
    local LEN=${#TEXT}

    if [ "$LEN" -ge "$WIDTH" ]
    then
        echo "$TEXT"
        return
    fi

    local TOTAL_PAD=$((WIDTH - LEN))
    local LEFT_PAD=$((TOTAL_PAD / 2))
    local RIGHT_PAD=$((TOTAL_PAD - LEFT_PAD))

    printf "%*s%s%*s" "$LEFT_PAD" "" "$TEXT" "$RIGHT_PAD" ""

}

##############################################################################
# Debug
##############################################################################

debug()
{

    if [ "$DEBUG" = "1" ]
    then
        echo "[DEBUG] $1"
    fi

}
