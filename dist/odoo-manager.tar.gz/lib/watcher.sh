#!/bin/bash

##############################################################################
# watcher.sh
# Hot Reload / Auto-Restart
# Watches Python files for changes and auto-restarts Odoo
##############################################################################

##############################################################################
# Check if inotifywait is available
##############################################################################

watcher_available()
{
    command_exists inotifywait
}

install_inotify()
{

    if watcher_available
    then
        print_success "inotify-tools already installed."
        return 0
    fi

    if ! command_exists apt-get
    then
        print_warning "Automatic install only supports apt-get (Debian/Ubuntu)."
        return 1
    fi

    require_sudo || return 1

    print_info "Installing inotify-tools (required for file watching)..."

    if sudo apt-get install -y inotify-tools
    then
        print_success "inotify-tools installed."
        return 0
    else
        print_error "Failed to install inotify-tools."
        return 1
    fi

}

##############################################################################
# Start Odoo with file watching
# Watches all .py and .xml files in the project's custom_addons directory.
# When a change is detected, stops and restarts Odoo automatically.
##############################################################################

start_odoo_with_watch()
{

    show_header

    echo "Start Odoo with Hot Reload"
    echo -e "${DIM}Watches Python/XML files and auto-restarts Odoo on changes${NC}"

    separator
    echo

    if ! watcher_available
    then

        print_warning "inotify-tools is not installed (required for file watching)."
        echo

        if confirm "Install inotify-tools now? (requires sudo)"
        then
            install_inotify || { pause; return; }
        else
            pause
            return
        fi

    fi

    local WATCH_DIR="$PROJECT_PATH"

    if [ -z "$PROJECT_PATH" ] || [ ! -d "$PROJECT_PATH" ]
    then
        print_error "No project selected or project directory not found."
        pause
        return
    fi

    local ODOO_BIN="$ODOO_PATH/odoo/odoo-bin"
    local VENV_PYTHON="$ODOO_PATH/env/bin/python3"

    if [ ! -f "$ODOO_BIN" ]
    then
        print_error "odoo-bin not found at $ODOO_BIN"
        pause
        return
    fi

    echo -e "  ${WHITE}Project${NC}    : $(basename "$PROJECT_PATH")"
    echo -e "  ${WHITE}Watching${NC}   : $WATCH_DIR"
    echo -e "  ${WHITE}Patterns${NC}   : *.py, *.xml, *.csv"
    echo

    print_info "Starting Odoo with hot reload... (Ctrl+C to stop)"
    echo

    # Stop any existing Odoo first
    stop_odoo_silent 2>/dev/null

    # Start Odoo
    (
        cd "$ODOO_PATH/odoo" || exit 1
        "$VENV_PYTHON" odoo-bin -c "$CONFIG_FILE" 2>&1 &
    )

    local ODOO_PID=$!
    sleep 2

    print_success "Odoo started (PID: $ODOO_PID). Watching for changes..."
    echo
    echo -e "  ${DIM}Press Ctrl+C to stop watching and Odoo${NC}"
    echo

    # Watch loop
    while true
    do

        local CHANGED_FILE
        CHANGED_FILE=$(inotifywait -r -q -e modify,create,delete,move \
            --include '\.(py|xml|csv)$' \
            "$WATCH_DIR" 2>/dev/null)

        if [ -n "$CHANGED_FILE" ]
        then

            echo -e "  ${YELLOW}Change detected${NC}: $CHANGED_FILE"
            echo -e "  ${CYAN}Restarting Odoo...${NC}"

            # Stop current Odoo
            kill "$ODOO_PID" 2>/dev/null
            wait "$ODOO_PID" 2>/dev/null
            sleep 1

            # Restart
            (
                cd "$ODOO_PATH/odoo" || exit 1
                "$VENV_PYTHON" odoo-bin -c "$CONFIG_FILE" 2>&1 &
            )

            ODOO_PID=$!
            sleep 2

            print_success "Odoo restarted (PID: $ODOO_PID)"
            echo

        fi

    done

}

##############################################################################
# Stop the watcher (clean up)
##############################################################################

stop_watcher()
{
    stop_odoo_silent 2>/dev/null
    print_success "File watcher stopped."
}
