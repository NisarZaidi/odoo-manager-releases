#!/bin/bash

##############################################################################
# odoo.sh
# Odoo Server Management
##############################################################################

ODOO_PID=""

##############################################################################
# Auto-Open Browser At The Database Manager Page
#
# On a fresh workspace there's no database yet - hitting the normal
# start page throws a confusing "relation does not exist" error until
# a database is created. Sending the user straight to
# /web/database/manager instead means they land exactly where they can
# create a new database or restore a backup, with no extra clicking.
#
# Best-effort only: silently does nothing if there's no GUI browser
# available (headless server, SSH session, etc.) or no display.
##############################################################################

open_odoo_browser()
{

    local PORT="$1"

    [ -n "$PORT" ] || return 0

    # No graphical session to open a browser in (SSH/headless) - skip.
    [ -n "$DISPLAY" ] || [ -n "$WAYLAND_DISPLAY" ] || return 0

    local URL="http://localhost:${PORT}/web/database/manager"

    if command_exists xdg-open
    then
        (xdg-open "$URL" >/dev/null 2>&1 &)
    elif command_exists gio
    then
        (gio open "$URL" >/dev/null 2>&1 &)
    elif command_exists sensible-browser
    then
        (sensible-browser "$URL" >/dev/null 2>&1 &)
    fi

}

##############################################################################
# PID File
##############################################################################

get_pid_file()
{

    echo "$ODOO_PATH/odoo.pid"

}

##############################################################################
# Wait For A List Of PIDs To Exit
#
# Polls every 0.5s (instead of one fixed sleep) for up to MAX_WAIT
# seconds, so a fast-shutting-down Odoo doesn't get an unnecessary
# SIGKILL, while a slow one doesn't get falsely declared dead early.
# Prints the PIDs that are STILL alive after the timeout (if any).
##############################################################################

wait_for_pids_exit()
{

    local MAX_WAIT="${2:-5}"
    local PIDS="$1"

    local ELAPSED=0
    local STEP=0.5

    while :
    do

        local STILL_ALIVE=""
        local P

        for P in $PIDS
        do
            ps -p "$P" >/dev/null 2>&1 && STILL_ALIVE="$STILL_ALIVE $P"
        done

        STILL_ALIVE=$(echo "$STILL_ALIVE" | xargs)

        [ -z "$STILL_ALIVE" ] && return 0

        if awk "BEGIN{exit !($ELAPSED >= $MAX_WAIT)}"
        then
            echo "$STILL_ALIVE"
            return 1
        fi

        sleep "$STEP"

        ELAPSED=$(awk "BEGIN{print $ELAPSED + $STEP}")

    done

}

##############################################################################
# Wait For Odoo To Actually Be Ready After Start
#
# Fixed "sleep 3" was unreliable both ways: too short for workspaces with
# a large addons_path (slow module scan on first boot), and too slow to
# report an early crash (bad addon, syntax error) that fails within the
# first second.
#
# Polls every 0.5s for up to MAX_WAIT seconds and returns as soon as ONE
# of these happens:
#   - the process died                       -> return 1 (fast failure)
#   - Odoo's own readiness line hits the log  -> return 0 (confirmed up)
#   - timeout reached, process still alive    -> return 0 (probably just
#                                                 a slow boot, not a crash)
##############################################################################

wait_for_odoo_ready()
{

    local PID="$1"
    local LOG="$2"
    local MAX_WAIT="${3:-15}"

    local ELAPSED=0
    local STEP=0.5

    while :
    do

        if ! ps -p "$PID" >/dev/null 2>&1
        then
            return 1
        fi

        if [ -f "$LOG" ] && grep -qE "HTTP service \(werkzeug\) running|Modules loaded\." "$LOG" 2>/dev/null
        then
            return 0
        fi

        if awk "BEGIN{exit !($ELAPSED >= $MAX_WAIT)}"
        then
            return 0
        fi

        sleep "$STEP"

        ELAPSED=$(awk "BEGIN{print $ELAPSED + $STEP}")

    done

}


#
# The running process's command line is just "python3 odoo-bin ..." (Odoo
# is started after a `cd` into the odoo/ folder, so the workspace's full
# path never appears in the command line - only "odoo-bin" itself does).
# Because of that, pgrep -f "$WS/odoo/odoo-bin" never matches anything.
#
# This checks (in order):
#   1. The workspace's own odoo.pid file (fast, authoritative)
#   2. pgrep matching on the workspace's own odoo.conf path, which IS
#      unique and DOES appear in the command line (-c <path>)
##############################################################################

is_workspace_running()
{

    local WS="$1"

    [ -d "$WS" ] || return 1

    local PID_FILE="$WS/odoo.pid"

    if [ -f "$PID_FILE" ]
    then

        local PID
        PID=$(cat "$PID_FILE" 2>/dev/null)

        if [ -n "$PID" ] && ps -p "$PID" >/dev/null 2>&1
        then
            echo "$PID"
            return 0
        fi

    fi

    local FOUND_PID
    FOUND_PID=$(pgrep -f "odoo-bin.*-c $WS/odoo/debian/odoo.conf" 2>/dev/null | head -n1)

    if [ -n "$FOUND_PID" ]
    then
        echo "$FOUND_PID"
        return 0
    fi

    return 1

}

##############################################################################
# Start Diagnostics
##############################################################################

odoo_emit_start_error()
{

    local MODE="$1"
    local MESSAGE="$2"

    if [ "$MODE" = "cli" ]
    then
        echo "Error: $MESSAGE" >&2
    else
        print_error "$MESSAGE"
    fi

}

odoo_start_preflight()
{

    local MODE="${1:-interactive}"

    validate_configuration

    if [ ! -f "$ODOO_PATH/env/bin/activate" ]
    then
        odoo_emit_start_error "$MODE" "Python virtual environment is missing ($ODOO_PATH/env). Run Workspace Doctor first."
        return 1
    fi

    if [ ! -f "$ODOO_PATH/odoo/odoo-bin" ]
    then
        odoo_emit_start_error "$MODE" "odoo-bin not found in $ODOO_PATH/odoo. The workspace looks incomplete."
        return 1
    fi

    if [ -z "$ADDONS_PATH" ]
    then
        odoo_emit_start_error "$MODE" "No valid addons path could be built for this workspace."
        return 1
    fi

    return 0

}

odoo_recent_log_excerpt()
{

    local LOG="$1"
    local LINES="${2:-25}"

    [ -f "$LOG" ] || return 0

    tail -n "$LINES" "$LOG" 2>/dev/null

}

odoo_start_failure_hint()
{

    local LOG="$1"
    local EXCERPT
    EXCERPT=$(odoo_recent_log_excerpt "$LOG" 60)

    if echo "$EXCERPT" | grep -q "not a valid addons directory"
    then
        echo "Likely cause: addons_path mein invalid ya empty directory include hai."
    elif echo "$EXCERPT" | grep -qE "ModuleNotFoundError|No module named"
    then
        echo "Likely cause: Python dependency missing hai ya virtual environment incomplete hai."
    elif echo "$EXCERPT" | grep -q "Address already in use"
    then
        echo "Likely cause: configured port kisi aur process ne already occupy ki hui hai."
    elif echo "$EXCERPT" | grep -q "Connection to the database failed"
    then
        echo "Likely cause: PostgreSQL connection ya selected database access fail ho rahi hai."
    elif echo "$EXCERPT" | grep -qE "Permission denied|Errno 13"
    then
        echo "Likely cause: file permissions ya workspace ownership ka issue hai."
    fi

}

odoo_report_start_failure()
{

    local MODE="${1:-interactive}"
    local LOG="$2"

    local HINT
    HINT=$(odoo_start_failure_hint "$LOG")

    if [ -n "$HINT" ]
    then
        if [ "$MODE" = "cli" ]
        then
            echo "$HINT" >&2
        else
            print_warning "$HINT"
        fi
    fi

    if [ -n "$ADDONS_PATH" ]
    then
        if [ "$MODE" = "cli" ]
        then
            echo "Effective addons_path:" >&2
            echo "$ADDONS_PATH" | tr ',' '\n' | sed 's/^/  - /' >&2
        else
            echo
            echo "Effective addons_path:"
            echo "$ADDONS_PATH" | tr ',' '\n' | sed 's/^/  - /'
        fi
    fi

    local EXCERPT
    EXCERPT=$(odoo_recent_log_excerpt "$LOG" 25)

    if [ -n "$EXCERPT" ]
    then
        if [ "$MODE" = "cli" ]
        then
            echo "Recent log excerpt:" >&2
            echo "$EXCERPT" | sed 's/^/  /' >&2
        else
            echo
            echo "Recent log excerpt:"
            echo "$EXCERPT" | sed 's/^/  /'
        fi
    fi

}

##############################################################################
# Start Odoo
##############################################################################

start_odoo()
{

    if ! odoo_start_preflight "interactive"
    then
        pause
        return
    fi

    if is_odoo_running
    then

        print_warning "Odoo is already running."

        pause

        return

    fi

    local CHECK_PORT
    CHECK_PORT="$(get_configured_port)"

    # Guard the "is the port free? -> spawn Odoo on it" sequence with a
    # lock, so starting two workspaces at the exact same moment can't
    # both pass the port check and then collide on the same port.
    local PORT_LOCK_FILE="/tmp/.odoo-manager-start.lock"
    local PORT_LOCK_FD=""

    if command_exists flock
    then

        exec {PORT_LOCK_FD}>"$PORT_LOCK_FILE"

        if ! flock -x -w 10 "$PORT_LOCK_FD"
        then

            print_error "Another odoo-manager start is already in progress. Please try again."

            exec {PORT_LOCK_FD}>&-

            pause

            return

        fi

    fi

    if is_port_in_use "$CHECK_PORT"
    then

        print_error "Port $CHECK_PORT is already in use by another process."
        echo
        echo "Another Odoo instance (or a different app) is using this port."
        echo "Stop that process, or change 'http_port' in odoo.conf, then try again."

        [ -n "$PORT_LOCK_FD" ] && exec {PORT_LOCK_FD}>&-

        pause

        return

    fi

    show_header

    echo "Starting Odoo..."
    echo "Port : $CHECK_PORT"
    echo

    source "$ODOO_PATH/env/bin/activate"

    build_addons_path

    cd "$ODOO_PATH/odoo" || die "Unable to open Odoo directory."

    # Direct redirection only (no tee) so output does not stream
    # onto the menu screen. Everything still goes to the log file.
    nohup setsid python3 odoo-bin \
         -c "$CONFIG_FILE" \
         --addons-path="$ADDONS_PATH" \
         >>"$LOG_FILE" 2>&1 \
         </dev/null &

    ODOO_PID=$!

    disown "$ODOO_PID" 2>/dev/null

    echo "$ODOO_PID" > "$(get_pid_file)"

    # Port is now genuinely bound (or Odoo is at least starting up on
    # it) - release the lock so the next workspace can proceed.
    [ -n "$PORT_LOCK_FD" ] && exec {PORT_LOCK_FD}>&-

    print_info "Waiting for Odoo to come up (this can take longer on large addons_path)..."

    if wait_for_odoo_ready "$ODOO_PID" "$LOG_FILE" 20
    then

        print_success "Odoo started successfully."
        echo
        echo "PID : $ODOO_PID"
        echo "Log : $LOG_FILE"

        open_odoo_browser "$CHECK_PORT"

    else

        print_error "Failed to start Odoo."
        echo "Check the log for details: $LOG_FILE"
        odoo_report_start_failure "interactive" "$LOG_FILE"

        rm -f "$(get_pid_file)"

    fi

    deactivate

    pause

}

##############################################################################
# Stop Odoo
##############################################################################

stop_odoo()
{

    local PID_FILE
    PID_FILE="$(get_pid_file)"

    local PID=""

    if [ -f "$PID_FILE" ]
    then
        PID=$(cat "$PID_FILE")
    fi

    # Fallback if pidfile is stale/missing
    if [ -z "$PID" ] || ! ps -p "$PID" >/dev/null 2>&1
    then
        PID=$(pgrep -f "odoo-bin.*-c $ODOO_PATH/odoo/debian/odoo.conf")
    fi

    if [ -z "$PID" ]
    then

        print_warning "Odoo is not running."

        rm -f "$PID_FILE"

        pause

        return

    fi

    kill "$PID"

    if ! wait_for_pids_exit "$PID" 5 >/dev/null
    then
        kill -9 "$PID" 2>/dev/null
    fi

    rm -f "$PID_FILE"

    print_success "Odoo stopped."

    pause

}

##############################################################################
# Stop Odoo (Silent - used on Quit)
##############################################################################

stop_odoo_silent()
{

    if [ -z "$ODOO_PATH" ] || [ ! -d "$ODOO_PATH" ]
    then
        return
    fi

    local PID_FILE
    PID_FILE="$(get_pid_file)"

    local PID=""

    if [ -f "$PID_FILE" ]
    then
        PID=$(cat "$PID_FILE")
    fi

    if [ -z "$PID" ] || ! ps -p "$PID" >/dev/null 2>&1
    then
        PID=$(pgrep -f "odoo-bin.*-c $ODOO_PATH/odoo/debian/odoo.conf" 2>/dev/null)
    fi

    if [ -n "$PID" ]
    then

        kill "$PID" 2>/dev/null

        sleep 2

        if ps -p "$PID" >/dev/null 2>&1
        then
            kill -9 "$PID" 2>/dev/null
        fi

    fi

    rm -f "$PID_FILE"

}

##############################################################################
# Stop A Single Workspace's Odoo Instance(s)
# Internal helper used by stop_all_odoo_instances - runs standalone so it
# can be dispatched as a background job per workspace.
##############################################################################

_stop_workspace_instances()
{

    local WS="$1"
    local STATUS_DIR="$2"

    [ -d "$WS" ] || return

    local PIDS
    PIDS=$(pgrep -f "odoo-bin.*-c $WS/odoo/debian/odoo.conf" 2>/dev/null)

    local PID_FILE="$WS/odoo.pid"

    if [ -f "$PID_FILE" ]
    then

        local STORED_PID
        STORED_PID=$(cat "$PID_FILE" 2>/dev/null)

        if [ -n "$STORED_PID" ] && ps -p "$STORED_PID" >/dev/null 2>&1
        then
            PIDS=$(printf '%s\n%s\n' "$PIDS" "$STORED_PID" | sort -u)
        fi

    fi

    if [ -n "$PIDS" ]
    then

        print_warning "Stopping Odoo running from workspace: $(basename "$WS")"

        # Mark that at least one workspace was actually stopped
        [ -n "$STATUS_DIR" ] && touch "$STATUS_DIR/$(basename "$WS")" 2>/dev/null

        local P
        for P in $PIDS
        do
            kill "$P" 2>/dev/null
        done

        local STILL_ALIVE
        if ! STILL_ALIVE=$(wait_for_pids_exit "$PIDS" 5)
        then

            for P in $STILL_ALIVE
            do
                kill -9 "$P" 2>/dev/null
            done

        fi

    fi

    rm -f "$PID_FILE"

}

##############################################################################
# Stop ALL Running Odoo Instances (across every workspace)
# Used on Quit / Ctrl+C so switching between multiple workspaces (each
# on its own port, see wizard.sh) never leaves a background instance
# running after the manager exits.
#
# Each workspace is stopped in its own background job so multiple
# workspaces (5+) shut down in parallel instead of one after another.
##############################################################################

stop_all_odoo_instances()
{

    # Refresh the workspace list so newly created workspaces are included.
    if command_exists detect_existing_workspaces
    then
        detect_existing_workspaces >/dev/null 2>&1
    fi

    local STATUS_DIR
    STATUS_DIR=$(mktemp -d 2>/dev/null)

    local WS
    local BG_PIDS=()

    for WS in "${WORKSPACES[@]}"
    do

        _stop_workspace_instances "$WS" "$STATUS_DIR" &

        BG_PIDS+=("$!")

    done

    local P
    for P in "${BG_PIDS[@]}"
    do
        wait "$P" 2>/dev/null
    done

    local ANY_STOPPED=0

    if [ -n "$STATUS_DIR" ] && [ -d "$STATUS_DIR" ] && [ -n "$(ls -A "$STATUS_DIR" 2>/dev/null)" ]
    then
        ANY_STOPPED=1
    fi

    rm -rf "$STATUS_DIR" 2>/dev/null

    if [ "$ANY_STOPPED" -eq 1 ]
    then
        print_success "All Odoo instances stopped."
    fi

}

##############################################################################
# Quit Manager (stops every running Odoo instance across all workspaces,
# then exits)
##############################################################################

quit_manager()
{

    stop_all_odoo_instances

    goodbye

    exit 0

}

##############################################################################
# Restart Odoo
##############################################################################

restart_odoo()
{

    show_header

    echo "Restarting Odoo..."
    echo

    if is_odoo_running
    then
        stop_odoo_silent
        print_success "Odoo stopped."
    else
        print_warning "Odoo was not running. Starting a fresh instance..."
    fi

    sleep 1

    start_odoo

}

##############################################################################
# View Logs
##############################################################################

view_logs()
{

    if [ ! -f "$LOG_FILE" ]
    then

        print_warning "Log file not found."

        pause

        return

    fi

    show_header

    echo -e "${BOLD}${WHITE}Live Log Viewer${NC}"
    echo -e "${DIM}$LOG_FILE${NC}"
    echo
    separator
    echo

    # Try to reserve the bottom line of the terminal as a sticky
    # footer, so the "Press ENTER" hint stays visible no matter how
    # much the log scrolls. Falls back to a plain one-time message
    # if the terminal doesn't support this.
    local STICKY=0
    local TOTAL_LINES
    local BODY_LINES

    if command_exists tput && [ -t 1 ]
    then

        TOTAL_LINES=$(tput lines 2>/dev/null)

        if [ -n "$TOTAL_LINES" ] && [ "$TOTAL_LINES" -gt 6 ]
        then
            STICKY=1
            BODY_LINES=$((TOTAL_LINES - 2))
        fi

    fi

    if [ "$STICKY" -eq 1 ]
    then

        # Reserve rows 1..BODY_LINES for scrolling log output,
        # keep the last 2 rows fixed for the footer.
        printf '\e[1;%dr' "$BODY_LINES"

        tput cup "$BODY_LINES" 0
        echo -e "${CYAN}──────────────────────────────────────────────${NC}"

        tput cup "$((BODY_LINES + 1))" 0
        echo -ne "${GREEN}Press ENTER${NC} to go back to the menu — Odoo keeps running."

        tput cup "$((BODY_LINES - 1))" 0

    else

        echo "Press ENTER to go back to the menu — Odoo keeps running."
        echo

    fi

    # Run tail in the background and only kill THIS process on exit.
    # Ctrl+C is avoided on purpose: in a non-interactive script, SIGINT
    # can propagate to the whole process group and kill the running
    # Odoo server too. Enter only stops the tail, never the service.
    tail -n 200 -f "$LOG_FILE" &

    local TAIL_PID=$!

    read -r

    kill "$TAIL_PID" >/dev/null 2>&1

    wait "$TAIL_PID" 2>/dev/null

    if [ "$STICKY" -eq 1 ]
    then
        # Reset scroll region back to full screen
        printf '\e[r'
        tput cup "$((TOTAL_LINES - 1))" 0
    fi

}

##############################################################################
# Running Status
##############################################################################

is_odoo_running()
{

    local PID_FILE
    PID_FILE="$(get_pid_file)"

    if [ -f "$PID_FILE" ]
    then

        local PID
        PID=$(cat "$PID_FILE")

        if [ -n "$PID" ] && ps -p "$PID" >/dev/null 2>&1
        then
            return 0
        fi

    fi

    pgrep -f "odoo-bin.*-c $ODOO_PATH/odoo/debian/odoo.conf" >/dev/null 2>&1

}

##############################################################################
# Server Status
##############################################################################

server_status()
{

    if is_odoo_running
    then

        print_success "Status : Running"

    else

        print_warning "Status : Stopped"

    fi

}

##############################################################################
# PID
##############################################################################

get_odoo_pid()
{

    local PID_FILE
    PID_FILE="$(get_pid_file)"

    if [ -f "$PID_FILE" ]
    then

        local PID
        PID=$(cat "$PID_FILE")

        if [ -n "$PID" ] && ps -p "$PID" >/dev/null 2>&1
        then
            echo "$PID"
            return
        fi

    fi

    pgrep -f "odoo-bin.*-c $ODOO_PATH/odoo/debian/odoo.conf"

}

##############################################################################
# Force Stop
##############################################################################

force_stop_odoo()
{

    PID=$(get_odoo_pid)

    if [ -n "$PID" ]
    then

        kill -9 "$PID"

        rm -f "$(get_pid_file)"

        print_success "Odoo force stopped."

    else

        print_warning "No running Odoo instance found."

    fi

}

##############################################################################
# Open Shell
##############################################################################

open_odoo_shell()
{

    validate_configuration

    source "$ODOO_PATH/env/bin/activate"

    build_addons_path

    cd "$ODOO_PATH/odoo" || return

    python3 odoo-bin shell \
        -c "$CONFIG_FILE" \
        --addons-path="$ADDONS_PATH"

    deactivate

}

##############################################################################
# Upgrade Module
##############################################################################

upgrade_module()
{

    MODULE="$1"
    DB_NAME="$2"

    if [ -z "$MODULE" ]
    then

        print_warning "Module name required."

        return

    fi

    if [ -z "$DB_NAME" ]
    then

        print_warning "Database name required."

        return

    fi

    validate_configuration

    source "$ODOO_PATH/env/bin/activate"

    build_addons_path

    cd "$ODOO_PATH/odoo" || return

    python3 odoo-bin \
        -c "$CONFIG_FILE" \
        -d "$DB_NAME" \
        -u "$MODULE" \
        --stop-after-init \
        --addons-path="$ADDONS_PATH"

    deactivate

    print_success "Module upgraded."

}

##############################################################################
# Update Odoo (git pull + requirements upgrade)
##############################################################################

update_odoo()
{

    show_header

    echo "Update Odoo Core"

    separator

    echo

    if is_odoo_running
    then

        print_warning "Please stop Odoo before updating."

        pause

        return

    fi

    if [ ! -d "$ODOO_PATH/odoo/.git" ]
    then

        print_warning "Odoo Community source is not a git repository. Cannot update."

        pause

        return

    fi

    echo "This will:"
    echo "  1. Pull the latest changes for this Odoo version (git pull)"
    echo "  2. Reinstall/upgrade Python dependencies (requirements.txt)"
    echo

    # Smart check: warn if Odoo source has uncommitted local changes
    if type project_git_dirty_count >/dev/null 2>&1
    then
        local ODOO_DIRTY
        ODOO_DIRTY=$(project_git_dirty_count "$ODOO_PATH/odoo")

        if [ "$ODOO_DIRTY" -gt 0 ] 2>/dev/null
        then
            print_warning "Odoo source has $ODOO_DIRTY uncommitted local change(s)."

            if confirm "Stash local changes before updating?"
            then
                git -C "$ODOO_PATH/odoo" stash push -m "auto-stash before update $(date +%Y-%m-%d_%H:%M)"
                print_success "Local changes stashed."
                echo
            fi
        fi
    fi

    if ! confirm "Continue?"
    then

        print_warning "Update cancelled."

        pause

        return

    fi

    loading "Pulling latest changes..."

    if ! (cd "$ODOO_PATH/odoo" && git pull)
    then

        print_error "Git pull failed. Resolve any local changes/conflicts and try again."

        pause

        return

    fi

    loading "Updating Python dependencies..."

    source "$ODOO_PATH/env/bin/activate"

    pip install --upgrade pip >/dev/null

    local REQ_FILE="$ODOO_PATH/odoo/requirements.txt"
    local REQ_OK=1

    if [ -f "$REQ_FILE" ]
    then

        if command_exists _install_requirements_txt
        then

            if ! _install_requirements_txt "$REQ_FILE"
            then
                REQ_OK=0
            fi

        else
            # Fallback if wizard.sh's helper isn't loaded for some reason
            pip install -r "$REQ_FILE" || REQ_OK=0
        fi

    fi

    deactivate

    if [ "$REQ_OK" -eq 1 ]
    then
        print_success "Odoo updated successfully."
    else
        print_warning "Odoo source updated, but some Python packages failed to install."
        echo "Fix manually with:"
        echo "  source \"$ODOO_PATH/env/bin/activate\""
        echo "  pip install -r \"$REQ_FILE\""
        echo "  deactivate"
    fi

    pause

}

##############################################################################
# CLI: Start Odoo (non-interactive, plain output for scripting)
##############################################################################

start_odoo_cli()
{

    if ! odoo_start_preflight "cli"
    then
        return 1
    fi

    if is_odoo_running
    then
        echo "Odoo is already running in workspace $(basename "$ODOO_PATH")."
        return 0
    fi

    local CHECK_PORT
    CHECK_PORT="$(get_configured_port)"

    local PORT_LOCK_FILE="/tmp/.odoo-manager-start.lock"
    local PORT_LOCK_FD=""

    if command_exists flock
    then

        exec {PORT_LOCK_FD}>"$PORT_LOCK_FILE"

        if ! flock -x -w 10 "$PORT_LOCK_FD"
        then
            echo "Error: another odoo-manager start is already in progress." >&2
            exec {PORT_LOCK_FD}>&-
            return 1
        fi

    fi

    if is_port_in_use "$CHECK_PORT"
    then
        echo "Error: port $CHECK_PORT is already in use." >&2
        [ -n "$PORT_LOCK_FD" ] && exec {PORT_LOCK_FD}>&-
        return 1
    fi

    source "$ODOO_PATH/env/bin/activate"

    build_addons_path

    cd "$ODOO_PATH/odoo" || {
        echo "Error: unable to open Odoo directory." >&2
        deactivate
        [ -n "$PORT_LOCK_FD" ] && exec {PORT_LOCK_FD}>&-
        return 1
    }

    nohup python3 odoo-bin \
        -c "$CONFIG_FILE" \
        --addons-path="$ADDONS_PATH" \
        >> "$LOG_FILE" 2>&1 &

    ODOO_PID=$!

    echo "$ODOO_PID" > "$(get_pid_file)"

    [ -n "$PORT_LOCK_FD" ] && exec {PORT_LOCK_FD}>&-

    local ODOO_READY=0

    if wait_for_odoo_ready "$ODOO_PID" "$LOG_FILE" 20
    then
        ODOO_READY=1
    fi

    deactivate

    if [ "$ODOO_READY" -eq 1 ]
    then
        echo "Odoo started (workspace: $(basename "$ODOO_PATH"), PID: $ODOO_PID, port: $CHECK_PORT)."
        return 0
    else
        echo "Error: Odoo failed to start. Check log: $LOG_FILE" >&2
        odoo_report_start_failure "cli" "$LOG_FILE"
        rm -f "$(get_pid_file)"
        return 1
    fi

}

##############################################################################
# CLI: Stop Odoo (non-interactive, plain output for scripting)
##############################################################################

stop_odoo_cli()
{

    local PID_FILE
    PID_FILE="$(get_pid_file)"

    local PID=""

    if [ -f "$PID_FILE" ]
    then
        PID=$(cat "$PID_FILE")
    fi

    if [ -z "$PID" ] || ! ps -p "$PID" >/dev/null 2>&1
    then
        PID=$(pgrep -f "odoo-bin.*-c $ODOO_PATH/odoo/debian/odoo.conf")
    fi

    if [ -z "$PID" ]
    then
        echo "Odoo is not running in workspace $(basename "$ODOO_PATH")."
        rm -f "$PID_FILE"
        return 0
    fi

    kill "$PID"

    if ! wait_for_pids_exit "$PID" 5 >/dev/null
    then
        kill -9 "$PID" 2>/dev/null
    fi

    rm -f "$PID_FILE"

    echo "Odoo stopped (workspace: $(basename "$ODOO_PATH"))."

}

##############################################################################
# CLI: Print Running Status Of A Single Workspace Path
##############################################################################

cli_status_one()
{

    local WS="$1"
    local NAME
    NAME=$(basename "$WS")

    local PID
    PID=$(is_workspace_running "$WS")

    if [ -n "$PID" ]
    then
        echo "$NAME : RUNNING (PID $PID)"
    else
        echo "$NAME : stopped"
    fi

}
