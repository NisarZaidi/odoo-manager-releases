#!/bin/bash

##############################################################################
# workspace.sh
# Workspace Detection & Selection
##############################################################################

WORKSPACES=()

workspace_json_escape()
{

    local VALUE="${1:-}"

    VALUE="${VALUE//\\/\\\\}"
    VALUE="${VALUE//\"/\\\"}"
    VALUE="${VALUE//$'\n'/\\n}"
    VALUE="${VALUE//$'\r'/\\r}"
    VALUE="${VALUE//$'\t'/\\t}"

    printf '%s' "$VALUE"

}


##############################################################################
# Detect Existing Workspaces
##############################################################################

detect_existing_workspaces()
{

    WORKSPACES=()

    if [ -d "$WORKSPACE_ROOT" ]
    then

        for DIR in "$WORKSPACE_ROOT"/odoo*
        do

            if [ -d "$DIR" ]
            then

                BASENAME=$(basename "$DIR")

                # Only match folders like odoo9, odoo13, odoo17 ... (any version number)
                if [[ "$BASENAME" =~ ^odoo[0-9]+$ ]]
                then
                    WORKSPACES+=("$DIR")
                fi

            fi

        done

    fi

    export WORKSPACES

}

sort_workspaces_for_menu()
{

    ensure_state_storage

    local SORTED=()
    local NAME
    local WS

    while IFS= read -r NAME
    do

        [ -n "$NAME" ] || continue

        for WS in "${WORKSPACES[@]}"
        do

            if [ "$(basename "$WS")" = "$NAME" ]
            then
                SORTED+=("$WS")
            fi

        done

    done < <(state_read_lines "$(state_file favorite_workspaces)")

    while IFS= read -r NAME
    do

        [ -n "$NAME" ] || continue

        for WS in "${WORKSPACES[@]}"
        do

            if [ "$(basename "$WS")" = "$NAME" ]
            then
                local EXISTS=0
                local ADDED

                for ADDED in "${SORTED[@]}"
                do
                    [ "$ADDED" = "$WS" ] && EXISTS=1
                done

                [ "$EXISTS" -eq 0 ] && SORTED+=("$WS")
            fi

        done

    done < <(state_read_lines "$(state_file recent_workspaces)")

    for WS in "${WORKSPACES[@]}"
    do

        local EXISTS=0
        local ADDED

        for ADDED in "${SORTED[@]}"
        do
            [ "$ADDED" = "$WS" ] && EXISTS=1
        done

        [ "$EXISTS" -eq 0 ] && SORTED+=("$WS")

    done

    WORKSPACES=("${SORTED[@]}")

}


##############################################################################
# Show Workspace List
##############################################################################

##############################################################################
# Show Workspace List (see ui.sh: show_workspace_menu)
##############################################################################


##############################################################################
# Select Odoo Workspace
##############################################################################

select_odoo_version()
{

    while true
    do

        detect_existing_workspaces
        sort_workspaces_for_menu


        if [ ${#WORKSPACES[@]} -eq 0 ]
        then

            run_workspace_wizard

            detect_existing_workspaces

            continue

        fi


        show_workspace_menu


        prompt_read CHOICE "Select Version: "



        case "$CHOICE" in


            N|n)

                run_workspace_wizard

                ;;


            R|r)

                detect_existing_workspaces

                ;;


            I|i)

                editors_menu

                ;;


            Y|y)

                system_requirements_menu

                ;;


            B|b)

                batch_operations_menu

                ;;


            E|e)

                templates_menu

                ;;


            M|m)

                remote_server_menu

                ;;


            A|a)

                aliases_menu

                ;;


            Q|q)

                quit_manager

                ;;


            *)

                if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]
                then

                    invalid_option

                    continue

                fi


                INDEX=$((CHOICE-1))


                if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#WORKSPACES[@]}" ]
                then

                    invalid_option

                    continue

                fi



                ODOO_PATH="${WORKSPACES[$INDEX]}"

                export ODOO_PATH



                CONFIG_FILE="$ODOO_PATH/odoo/debian/odoo.conf"

                LOG_FILE="$ODOO_PATH/logs/odoo.log"


                export CONFIG_FILE
                export LOG_FILE

                record_recent_workspace "$ODOO_PATH"

                validate_workspace


                select_project


                return

                ;;

        esac


    done

}

workspace_doctor_json_one()
{

    local WS="$1"
    local WS_NAME
    WS_NAME=$(basename "$WS")

    local CONFIG="$WS/odoo/debian/odoo.conf"
    local PID_FILE="$WS/odoo.pid"
    local PORT=""
    local PORT_BUSY=false
    local PID=""
    local STALE_PID=false
    local ISSUES=0

    if [ -f "$CONFIG" ]
    then
        PORT=$(grep "^http_port" "$CONFIG" 2>/dev/null | cut -d '=' -f2- | xargs)
    else
        ISSUES=$((ISSUES+1))
    fi

    if [ -f "$PID_FILE" ]
    then
        PID=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$PID" ] && ! ps -p "$PID" >/dev/null 2>&1
        then
            STALE_PID=true
            ISSUES=$((ISSUES+1))
        fi
    fi

    if [ -n "$PORT" ]
    then
        if is_workspace_running "$WS" >/dev/null 2>&1
        then
            PORT_BUSY=false
        elif is_port_in_use "$PORT"
        then
            PORT_BUSY=true
            ISSUES=$((ISSUES+1))
        fi
    fi

    local ADDONS_REPAIR=false
    local OLD_ODOO_PATH="$ODOO_PATH"
    local OLD_CONFIG_FILE="$CONFIG_FILE"
    ODOO_PATH="$WS"
    CONFIG_FILE="$CONFIG"

    if [ -f "$CONFIG" ] && workspace_addons_path_needs_repair
    then
        ADDONS_REPAIR=true
        ISSUES=$((ISSUES+1))
    fi

    local ENTERPRISE_COUNT
    ENTERPRISE_COUNT=$(count_odoo_modules_in_dir "$WS/enterprise")

    local LEGACY_COUNT
    LEGACY_COUNT=$(count_odoo_modules_in_dir "$WS/custom_addons")

    local PROJECT_COUNT=0
    if [ -d "$WS/projects" ]
    then
        PROJECT_COUNT=$(find "$WS/projects" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')
    fi

    local PG_STATUS=2
    if type check_database_connection >/dev/null 2>&1
    then
        check_database_connection
        PG_STATUS=$?
    fi

    printf '{'
    printf '"workspace":"%s",' "$(workspace_json_escape "$WS_NAME")"
    printf '"path":"%s",' "$(workspace_json_escape "$WS")"
    printf '"config_file":"%s",' "$(workspace_json_escape "$CONFIG")"
    printf '"running":%s,' "$([ -n "$(is_workspace_running "$WS")" ] && echo true || echo false)"
    if [ -n "$PORT" ]; then
        printf '"http_port":%s,' "$PORT"
    else
        printf '"http_port":null,'
    fi
    printf '"issues_count":%s,' "$ISSUES"
    printf '"addons_path_needs_repair":%s,' "$ADDONS_REPAIR"
    printf '"odoo_git_present":%s,' "$([ -d "$WS/odoo/.git" ] && echo true || echo false)"
    printf '"venv_present":%s,' "$([ -f "$WS/env/bin/activate" ] && echo true || echo false)"
    printf '"postgres_reachable":%s,' "$([ "$PG_STATUS" -eq 0 ] && echo true || echo false)"
    printf '"stale_pid":%s,' "$STALE_PID"
    printf '"port_busy":%s,' "$PORT_BUSY"
    printf '"enterprise_modules":%s,' "$ENTERPRISE_COUNT"
    printf '"legacy_custom_addons_modules":%s,' "$LEGACY_COUNT"
    printf '"project_count":%s' "$PROJECT_COUNT"
    printf '}'

    ODOO_PATH="$OLD_ODOO_PATH"
    CONFIG_FILE="$OLD_CONFIG_FILE"

}

workspace_doctor_json_report()
{

    local FILTER_WORKSPACE="${1:-}"
    local LOCAL_WORKSPACES=()

    if [ -n "$FILTER_WORKSPACE" ]
    then
        LOCAL_WORKSPACES=("$WORKSPACE_ROOT/$FILTER_WORKSPACE")
    else
        detect_existing_workspaces
        LOCAL_WORKSPACES=("${WORKSPACES[@]}")
    fi

    printf '{"workspace_root":"%s","count":%s,"workspaces":[' \
        "$(workspace_json_escape "$WORKSPACE_ROOT")" "${#LOCAL_WORKSPACES[@]}"

    local FIRST=1
    local WS
    for WS in "${LOCAL_WORKSPACES[@]}"
    do
        [ "$FIRST" -eq 1 ] || printf ','
        workspace_doctor_json_one "$WS"
        FIRST=0
    done

    printf ']}\n'

}



##############################################################################
# Workspace Summary
##############################################################################

workspace_summary()
{

    echo

    echo "Workspace : $ODOO_PATH"

    echo "Version   : $(basename "$ODOO_PATH")"

    echo "Config    : $CONFIG_FILE"

    echo "Log File  : $LOG_FILE"

    echo

}



##############################################################################
# Validate Workspace Structure
##############################################################################

validate_workspace()
{

    REQUIRED=(
        "odoo"
        "enterprise"
        "custom_addons"
        "env"
        "logs"
        "projects"
        "backup"
    )


    for ITEM in "${REQUIRED[@]}"
    do

        if [ ! -e "$ODOO_PATH/$ITEM" ]
        then

            print_warning "Missing folder: $ITEM"

            return 1

        fi

    done


    return 0

}



##############################################################################
# Workspace Doctor (Health Check + Auto-Repair)
##############################################################################

workspace_doctor()
{

    show_header

    echo "Workspace Doctor"
    echo "$ODOO_PATH"

    separator

    echo

    local ISSUES=0

    local REQUIRED_DIRS=(
        "odoo"
        "enterprise"
        "env"
        "logs"
        "projects"
        "backup"
    )

    for DIR in "${REQUIRED_DIRS[@]}"
    do

        if [ -d "$ODOO_PATH/$DIR" ]
        then
            print_success "✔ $DIR/"
        else
            print_warning "✘ $DIR/ missing - creating..."
            mkdir -p "$ODOO_PATH/$DIR"
            ISSUES=$((ISSUES+1))
        fi

    done

    echo

    if [ -f "$ODOO_PATH/odoo/debian/odoo.conf" ]
    then
        print_success "✔ odoo.conf found"

        if type workspace_addons_path_needs_repair >/dev/null 2>&1 && workspace_addons_path_needs_repair
        then

            print_warning "✘ addons_path contains legacy or invalid entries"

            ISSUES=$((ISSUES+1))

            echo

            if confirm "Repair addons_path to the safe default now?"
            then
                repair_workspace_addons_path
                print_success "addons_path reset to the safe workspace default."
            fi

        else
            print_success "✔ addons_path is in the safe default format"
        fi
    else

        print_warning "✘ odoo.conf missing"

        ISSUES=$((ISSUES+1))

        echo

        if confirm "Auto-generate a default odoo.conf now?"
        then
            auto_fix_odoo_conf
        else
            print_info "Skipped. You can re-run Workspace Doctor any time to fix this."
        fi

    fi

    if type count_odoo_modules_in_dir >/dev/null 2>&1
    then

        local LEGACY_MODULE_COUNT
        LEGACY_MODULE_COUNT=$(count_odoo_modules_in_dir "$ODOO_PATH/custom_addons")

        if [ "$LEGACY_MODULE_COUNT" -gt 0 ]
        then
            print_info "Legacy custom_addons/ detected (${LEGACY_MODULE_COUNT} module(s)) - runtime compatibility is enabled."
        fi

    fi

    if [ -d "$ODOO_PATH/odoo/.git" ]
    then
        print_success "✔ Odoo Community repository present"
    else
        print_warning "✘ Odoo Community not cloned"
        ISSUES=$((ISSUES+1))
    fi

    local WS_ODOO_VERSION
    WS_ODOO_VERSION=$(basename "$ODOO_PATH" | grep -o '[0-9]\+' | head -n1)

    if [ -f "$ODOO_PATH/env/bin/activate" ]
    then

        print_success "✔ Python virtual environment found"

        if [ -n "$WS_ODOO_VERSION" ] && command_exists odoo_required_python_version
        then

            local REQUIRED_PY CURRENT_PY
            REQUIRED_PY="$(odoo_required_python_version "$WS_ODOO_VERSION")"
            CURRENT_PY=$("$ODOO_PATH/env/bin/python3" --version 2>&1 | awk '{print $2}')

            # Compare only major.minor - patch versions (3.8.20 vs 3.8.18) are fine
            local REQUIRED_MM="${REQUIRED_PY%.*}"
            local CURRENT_MM="${CURRENT_PY%.*}"

            if [ "$REQUIRED_MM" = "$CURRENT_MM" ]
            then

                print_success "✔ Python version matches (Odoo $WS_ODOO_VERSION needs $REQUIRED_PY, venv has $CURRENT_PY)"

                # Check that the core packages Odoo itself imports at
                # startup are actually present - catches the case where
                # requirements.txt install partially failed earlier
                # (e.g. one broken legacy package aborted the whole batch)
                # even though the venv/Python version itself is fine.
                local CORE_PACKAGES=(psycopg2 lxml babel PyPDF2 werkzeug passlib)
                local MISSING_CORE=()
                local PKG

                for PKG in "${CORE_PACKAGES[@]}"
                do
                    "$ODOO_PATH/env/bin/pip" show "$PKG" >/dev/null 2>&1 || MISSING_CORE+=("$PKG")
                done

                if [ ${#MISSING_CORE[@]} -gt 0 ]
                then

                    print_warning "✘ Missing Python package(s): ${MISSING_CORE[*]}"

                    ISSUES=$((ISSUES+1))

                    echo

                    if confirm "Reinstall Python dependencies now (requirements.txt)?"
                    then

                        local REQ_FILE="$ODOO_PATH/odoo/requirements.txt"

                        if [ -f "$REQ_FILE" ]
                        then

                            loading "Reinstalling Python dependencies (one package at a time)..."

                            source "$ODOO_PATH/env/bin/activate"
                            pip install --upgrade pip "setuptools<58" wheel >/dev/null 2>&1

                            if command_exists _install_requirements_txt
                            then

                                if _install_requirements_txt "$REQ_FILE"
                                then
                                    print_success "All Python dependencies installed."
                                else
                                    print_warning "Some packages still could not be installed - see above."
                                fi

                            else
                                pip install -r "$REQ_FILE"
                            fi

                            # lxml 5.x+ split out lxml.html.clean into a
                            # separate package whose API doesn't match
                            # what older Odoo expects - keep lxml itself
                            # below 5.0 instead (bundled clean.defs).
                            pip uninstall -y lxml_html_clean >/dev/null 2>&1
                            pip install "lxml<5" >/dev/null 2>&1

                            deactivate

                        else

                            print_warning "requirements.txt not found - cannot reinstall automatically."

                        fi

                    fi

                else

                    print_success "✔ Core Python packages present"

                    # lxml 5.x+ removed the bundled html.clean.defs that
                    # older Odoo's mail.py relies on directly - check the
                    # installed major version, not just presence.
                    local LXML_VERSION
                    LXML_VERSION=$("$ODOO_PATH/env/bin/pip" show lxml 2>/dev/null | awk '/^Version:/ {print $2}')

                    local LXML_MAJOR="${LXML_VERSION%%.*}"

                    if [ -n "$LXML_MAJOR" ] && [ "$LXML_MAJOR" -ge 5 ] 2>/dev/null
                    then

                        print_warning "✘ lxml $LXML_VERSION is too new for Odoo $WS_ODOO_VERSION (needs lxml < 5)"

                        ISSUES=$((ISSUES+1))

                        echo

                        if confirm "Downgrade lxml to a compatible version now?"
                        then

                            source "$ODOO_PATH/env/bin/activate"
                            pip uninstall -y lxml_html_clean >/dev/null 2>&1
                            pip install "lxml<5" >/dev/null 2>&1
                            deactivate

                            print_success "lxml downgraded to a version compatible with Odoo $WS_ODOO_VERSION."

                        fi

                    fi

                fi

            else

                print_warning "✘ Python version mismatch: venv has $CURRENT_PY, Odoo $WS_ODOO_VERSION needs $REQUIRED_PY"

                ISSUES=$((ISSUES+1))

                echo

                if confirm "Rebuild the virtual environment with the correct Python version now?"
                then

                    loading "Rebuilding virtual environment (Python $REQUIRED_PY)..."

                    rm -rf "$ODOO_PATH/env"

                    if create_odoo_venv "$ODOO_PATH" "$WS_ODOO_VERSION"
                    then

                        print_success "Virtual environment rebuilt with Python $REQUIRED_PY."

                        local REQ_FILE="$ODOO_PATH/odoo/requirements.txt"

                        if [ -f "$REQ_FILE" ]
                        then

                            loading "Reinstalling Python dependencies..."

                            source "$ODOO_PATH/env/bin/activate"
                            pip install --upgrade pip >/dev/null 2>&1

                            if command_exists _install_requirements_txt
                            then
                                _install_requirements_txt "$REQ_FILE"
                            else
                                pip install -r "$REQ_FILE"
                            fi

                            deactivate

                        fi

                    else

                        print_error "Failed to rebuild virtual environment. See messages above."

                    fi

                else

                    print_info "Skipped. Odoo may fail to start until the Python version is fixed."

                fi

            fi

        fi

    else

        print_warning "✘ Python virtual environment missing"

        ISSUES=$((ISSUES+1))

        echo

        if [ -n "$WS_ODOO_VERSION" ] && confirm "Create the virtual environment now?"
        then

            loading "Creating virtual environment..."

            if create_odoo_venv "$ODOO_PATH" "$WS_ODOO_VERSION"
            then
                print_success "Virtual environment created."
            else
                print_error "Failed to create virtual environment."
            fi

        fi

    fi

    if command_exists psql
    then
        print_success "✔ PostgreSQL client available"
    else
        print_warning "✘ psql not found"
        ISSUES=$((ISSUES+1))
    fi

    if type check_database_connection >/dev/null 2>&1
    then

        check_database_connection

        case "$?" in
            0)
                print_success "✔ PostgreSQL is reachable"
                ;;
            1)
                print_warning "✘ PostgreSQL is installed but not reachable"
                ISSUES=$((ISSUES+1))
                ;;
            2)
                print_warning "✘ PostgreSQL client tools missing - reachability not checked"
                ISSUES=$((ISSUES+1))
                ;;
        esac

    fi

    local PID_FILE="$ODOO_PATH/odoo.pid"

    if [ -f "$PID_FILE" ]
    then

        local STORED_PID
        STORED_PID=$(cat "$PID_FILE" 2>/dev/null)

        if [ -n "$STORED_PID" ] && ps -p "$STORED_PID" >/dev/null 2>&1
        then
            print_success "✔ PID file points to running Odoo process ($STORED_PID)"
        else
            print_warning "✘ Stale PID file found - removing..."
            rm -f "$PID_FILE"
            ISSUES=$((ISSUES+1))
        fi

    fi

    if [ -f "$ODOO_PATH/odoo/debian/odoo.conf" ]
    then

        local WS_PORT
        WS_PORT=$(grep "^http_port" "$ODOO_PATH/odoo/debian/odoo.conf" 2>/dev/null | cut -d '=' -f2- | xargs)

        if [ -n "$WS_PORT" ]
        then

            if type is_workspace_running >/dev/null 2>&1 && is_workspace_running "$ODOO_PATH" >/dev/null 2>&1
            then
                print_success "✔ Workspace port $WS_PORT is already owned by this Odoo instance"
            elif is_port_in_use "$WS_PORT"
            then
                print_warning "✘ Workspace port $WS_PORT is already busy"
                ISSUES=$((ISSUES+1))
            else
                print_success "✔ Workspace port $WS_PORT is free"
            fi

        fi

    fi

    if command_exists git
    then
        print_success "✔ git available"
    else
        print_warning "✘ git not found"
        ISSUES=$((ISSUES+1))
    fi

    echo

    separator

    echo

    if [ "$ISSUES" -eq 0 ]
    then
        print_success "Workspace is healthy. No issues found."
    else
        print_warning "$ISSUES issue(s) found."
        echo "Missing folders were created automatically."
        echo "Workspace Doctor also checked addons_path, stale pid files, PostgreSQL reachability, and port conflicts."
    fi

    pause

}



##############################################################################
# Refresh Workspace
##############################################################################

refresh_workspace()
{

    detect_existing_workspaces

}



##############################################################################
# Get Workspace Version
##############################################################################

workspace_version()
{

    basename "$ODOO_PATH"

}



##############################################################################
# Check Workspace Exists
##############################################################################

workspace_available()
{

    [ -d "$ODOO_PATH" ]

}



##############################################################################
# Change Workspace
##############################################################################

change_workspace()
{

    ODOO_PATH=""

    PROJECT_PATH=""

    PROJECT_NAME=""


    export ODOO_PATH
    export PROJECT_PATH
    export PROJECT_NAME


    select_odoo_version

}
