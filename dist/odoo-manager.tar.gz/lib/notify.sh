#!/bin/bash

##############################################################################
# notify.sh
# Desktop Notification System
# Sends desktop notifications for important events (crash, long task done, etc.)
##############################################################################

notify_send_available()
{
    command_exists notify-send
}

##############################################################################
# Send a desktop notification
# Usage: notify_user "Title" "Message" [urgency]
# urgency: low, normal, critical (default: normal)
##############################################################################

notify_user()
{

    local TITLE="${1:-Odoo Manager}"
    local MESSAGE="${2:-}"
    local URGENCY="${3:-normal}"

    if notify_send_available
    then
        notify-send -u "$URGENCY" -i "utilities-terminal" "$TITLE" "$MESSAGE" 2>/dev/null &
    fi

}

notify_success()
{
    notify_user "$1" "$2" "normal"
}

notify_warning()
{
    notify_user "$1" "$2" "normal"
}

notify_critical()
{
    notify_user "$1" "$2" "critical"
}

notify_odoo_started()
{
    local WS_NAME="${1:-Odoo}"
    local PORT="${2:-8069}"

    notify_success "Odoo Started" "$WS_NAME is running on port $PORT"
}

notify_odoo_stopped()
{
    local WS_NAME="${1:-Odoo}"

    notify_warning "Odoo Stopped" "$WS_NAME has been stopped"
}

notify_odoo_crashed()
{
    local WS_NAME="${1:-Odoo}"

    notify_critical "Odoo Crashed" "$WS_NAME has stopped unexpectedly! Check logs."
}

notify_task_complete()
{
    local TASK_NAME="${1:-Task}"

    notify_success "Task Complete" "$TASK_NAME finished successfully"
}

notify_backup_complete()
{
    local WS_NAME="${1:-Workspace}"

    notify_success "Backup Complete" "$WS_NAME backup finished"
}

notify_update_available()
{
    local NEW_VER="${1:-}"

    notify_user "Update Available" "Odoo Manager v${NEW_VER} is available. Run odoo-manager --auto-update" "normal"
}
