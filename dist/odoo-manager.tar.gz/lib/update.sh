#!/bin/bash

##############################################################################
# update.sh
# Update Checker (GitHub)
##############################################################################

##############################################################################
# Check For Updates
#
# Compares the local git HEAD against the latest commit on the remote
# tracking branch. Designed to never get in the user's way:
#
#   - Skips silently if this install isn't a git checkout (e.g. a
#     tarball drop, or ODOO_MANAGER_HOME pointing somewhere without .git)
#   - Skips silently if git/curl/the network is unavailable
#   - Bounded by a short timeout so a dead network never hangs startup
#   - Never treated as fatal - always returns 0
##############################################################################

check_for_updates()
{

    # Allow the user to fully disable this (e.g. air-gapped machines, CI)
    if [ "$ODOO_MANAGER_SKIP_UPDATE_CHECK" = "1" ]
    then
        return 0
    fi

    [ -n "$ROOT_DIR" ] || return 0

    [ -d "$ROOT_DIR/.git" ] || return 0

    command_exists git || return 0

    local REMOTE_URL
    REMOTE_URL=$(git -C "$ROOT_DIR" config --get remote.origin.url 2>/dev/null)

    [ -n "$REMOTE_URL" ] || return 0

    local LOCAL_HASH
    LOCAL_HASH=$(git -C "$ROOT_DIR" rev-parse HEAD 2>/dev/null)

    [ -n "$LOCAL_HASH" ] || return 0

    local BRANCH
    BRANCH=$(git -C "$ROOT_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null)

    if [ -z "$BRANCH" ] || [ "$BRANCH" = "HEAD" ]
    then
        BRANCH="main"
    fi

    local TIMEOUT_CMD=""

    if command_exists timeout
    then
        TIMEOUT_CMD="timeout 3"
    fi

    local REMOTE_HASH
    REMOTE_HASH=$($TIMEOUT_CMD git ls-remote "$REMOTE_URL" "refs/heads/$BRANCH" 2>/dev/null | awk '{print $1}')

    # No internet, private repo without creds, timeout, etc. - fail silently
    [ -n "$REMOTE_HASH" ] || return 0

    if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]
    then

        if [ "$ODOO_MANAGER_AUTO_UPDATE" = "1" ]
        then

            echo
            print_info "Update available. Auto-updating (--auto-update)..."

            if $TIMEOUT_CMD git -C "$ROOT_DIR" pull 2>&1
            then
                print_success "Odoo Development Manager updated to the latest version."
            else
                print_warning "Auto-update failed. Run manually: git -C \"$ROOT_DIR\" pull"
            fi

            echo

        else

            echo
            print_warning "Update available for Odoo Development Manager."
            echo -e "${DIM}Run: git -C \"$ROOT_DIR\" pull${NC}"
            echo -e "${DIM}Or relaunch with: odoo-manager --auto-update${NC}"
            echo

        fi

    fi

    return 0

}
