#!/bin/bash

##############################################################################
# templates.sh
# Environment Templates
# Save and restore workspace configurations as reusable templates
##############################################################################

template_dir()
{
    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}/templates"
}

##############################################################################
# Save current workspace as a template
##############################################################################

save_workspace_template()
{

    show_header
    echo "Save Workspace Template"
    separator
    echo

    if [ -z "$ODOO_PATH" ] || [ ! -d "$ODOO_PATH" ]
    then
        print_error "No workspace selected."
        pause
        return
    fi

    read -r -p "Template name (e.g., odoo18-enterprise): " TPL_NAME

    if [ -z "$TPL_NAME" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    TPL_NAME=$(echo "$TPL_NAME" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9_-]/_/g')

    local TPL_DIR
    TPL_DIR="$(template_dir)"
    mkdir -p "$TPL_DIR"

    local TPL_FILE="$TPL_DIR/${TPL_NAME}.json"

    # Extract workspace config
    local ODOO_VERSION
    ODOO_VERSION=$(basename "$ODOO_PATH" | grep -oE '[0-9]+')

    local HTTP_PORT=""
    local DB_NAME=""
    local DB_USER=""

    if [ -f "$CONFIG_FILE" ]
    then
        HTTP_PORT=$(grep "^http_port" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
        DB_NAME=$(grep "^db_name" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
        DB_USER=$(grep "^db_user" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
    fi

    # Collect project names
    local PROJECTS_LIST=""
    if [ -d "$ODOO_PATH/projects" ]
    then
        PROJECTS_LIST=$(find "$ODOO_PATH/projects" -mindepth 1 -maxdepth 1 -type d -exec basename {} \; 2>/dev/null | paste -sd ',' -)
    fi

    cat > "$TPL_FILE" <<JSONEOF
{
    "template_name": "$TPL_NAME",
    "odoo_version": "$ODOO_VERSION",
    "http_port": "$HTTP_PORT",
    "db_name": "$DB_NAME",
    "db_user": "$DB_USER",
    "projects": "$PROJECTS_LIST",
    "has_enterprise": $([ -d "$ODOO_PATH/enterprise" ] && [ "$(find "$ODOO_PATH/enterprise" -name '__manifest__.py' 2>/dev/null | head -1)" ] && echo "true" || echo "false"),
    "created": "$(date -Iseconds)",
    "source_workspace": "$(basename "$ODOO_PATH")"
}
JSONEOF

    echo
    print_success "Template saved: $TPL_NAME"
    echo -e "  ${WHITE}Location${NC}: $TPL_FILE"
    echo -e "  ${WHITE}Odoo Version${NC}: $ODOO_VERSION"
    echo -e "  ${WHITE}Projects${NC}: ${PROJECTS_LIST:-none}"

    pause

}

##############################################################################
# List saved templates
##############################################################################

list_templates()
{

    local TPL_DIR
    TPL_DIR="$(template_dir)"

    if [ ! -d "$TPL_DIR" ] || [ -z "$(ls -A "$TPL_DIR"/*.json 2>/dev/null)" ]
    then
        echo -e "  ${DIM}No templates saved yet.${NC}"
        return
    fi

    local TPL_FILE
    for TPL_FILE in "$TPL_DIR"/*.json
    do
        local NAME VER PROJS CREATED
        NAME=$(grep '"template_name"' "$TPL_FILE" | cut -d'"' -f4)
        VER=$(grep '"odoo_version"' "$TPL_FILE" | cut -d'"' -f4)
        PROJS=$(grep '"projects"' "$TPL_FILE" | cut -d'"' -f4)
        CREATED=$(grep '"created"' "$TPL_FILE" | cut -d'"' -f4)

        echo -e "  ${GREEN}${BOLD}$NAME${NC}"
        echo -e "    ${DIM}Odoo${NC}: $VER  ${DIM}Projects${NC}: ${PROJS:-none}  ${DIM}Created${NC}: ${CREATED%T*}"
        echo
    done

}

##############################################################################
# Load template - creates a new workspace from a template
##############################################################################

load_workspace_template()
{

    show_header
    echo "Load Workspace Template"
    separator
    echo

    local TPL_DIR
    TPL_DIR="$(template_dir)"

    if [ ! -d "$TPL_DIR" ] || [ -z "$(ls -A "$TPL_DIR"/*.json 2>/dev/null)" ]
    then
        print_warning "No templates saved."
        pause
        return
    fi

    echo "Available templates:"
    echo

    local TPL_FILES=()
    local COUNT=1
    local TPL_FILE

    for TPL_FILE in "$TPL_DIR"/*.json
    do
        local NAME VER
        NAME=$(grep '"template_name"' "$TPL_FILE" | cut -d'"' -f4)
        VER=$(grep '"odoo_version"' "$TPL_FILE" | cut -d'"' -f4)

        TPL_FILES+=("$TPL_FILE")
        printf "  ${GREEN}%s${NC}) %-30s (Odoo %s)\n" "$COUNT" "$NAME" "$VER"
        COUNT=$((COUNT + 1))
    done

    echo
    menu_item "B" "Back"
    echo

    prompt_read CHOICE "Select Template: "

    if [ "$CHOICE" = "B" ] || [ "$CHOICE" = "b" ]
    then
        return
    fi

    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]] || [ "$CHOICE" -lt 1 ] || [ "$CHOICE" -gt ${#TPL_FILES[@]} ]
    then
        invalid_option
        return
    fi

    local SELECTED_TPL="${TPL_FILES[$((CHOICE - 1))]}"

    local TPL_VER
    TPL_VER=$(grep '"odoo_version"' "$SELECTED_TPL" | cut -d'"' -f4)

    echo
    print_info "Loading template: Odoo $TPL_VER workspace"
    echo
    print_info "This will start the workspace wizard with pre-filled settings."
    echo -e "${DIM}The wizard will clone Odoo, create venv, and set up the workspace.${NC}"

    # Pre-set the version for the wizard
    ODOO_VERSION="$TPL_VER"
    export ODOO_VERSION

    echo
    if confirm "Proceed with workspace creation?"
    then
        run_workspace_wizard
    fi

    pause

}

##############################################################################
# Delete a template
##############################################################################

delete_template()
{

    show_header
    echo "Delete Template"
    separator
    echo

    local TPL_DIR
    TPL_DIR="$(template_dir)"

    if [ ! -d "$TPL_DIR" ] || [ -z "$(ls -A "$TPL_DIR"/*.json 2>/dev/null)" ]
    then
        print_warning "No templates to delete."
        pause
        return
    fi

    list_templates

    read -r -p "Template name to delete: " DEL_NAME

    if [ -z "$DEL_NAME" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    local TPL_FILE="$TPL_DIR/${DEL_NAME}.json"

    if [ ! -f "$TPL_FILE" ]
    then
        print_error "Template '$DEL_NAME' not found."
        pause
        return
    fi

    if confirm "Delete template '$DEL_NAME'?"
    then
        rm -f "$TPL_FILE"
        print_success "Template deleted."
    else
        print_info "Cancelled."
    fi

    pause

}

##############################################################################
# Templates menu
##############################################################################

templates_menu()
{

    while true
    do

        show_header

        echo "Environment Templates"
        echo -e "${DIM}Save and restore workspace configurations as reusable templates${NC}"

        separator
        echo

        list_templates

        separator
        echo

        menu_item "S" "Save Current Workspace as Template"
        menu_item "L" "Load Template (create new workspace from template)"
        menu_item "D" "Delete Template"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            S|s) save_workspace_template ;;
            L|l) load_workspace_template ;;
            D|d) delete_template ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}
