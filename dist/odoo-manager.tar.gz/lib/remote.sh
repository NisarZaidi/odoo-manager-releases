#!/bin/bash

##############################################################################
# remote.sh
# Remote / Server Management
# Manage remote Odoo instances via SSH
##############################################################################

remote_config_file()
{
    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}/servers.conf"
}

##############################################################################
# Add a remote server
##############################################################################

add_remote_server()
{

    show_header
    echo "Add Remote Server"
    separator
    echo

    read -r -p "Server name (e.g., staging): " SRV_NAME
    [ -z "$SRV_NAME" ] && { print_warning "Cancelled."; pause; return; }

    SRV_NAME=$(echo "$SRV_NAME" | tr '[:upper:]' '[:lower:]' | tr -d ' ')

    read -r -p "SSH host (e.g., 192.168.1.100 or staging.example.com): " SRV_HOST
    [ -z "$SRV_HOST" ] && { print_warning "Cancelled."; pause; return; }

    read -r -p "SSH user [odoo]: " SRV_USER
    SRV_USER="${SRV_USER:-odoo}"

    read -r -p "SSH port [22]: " SRV_PORT
    SRV_PORT="${SRV_PORT:-22}"

    read -r -p "Remote Odoo directory [/opt/odoo]: " SRV_ODOO_DIR
    SRV_ODOO_DIR="${SRV_ODOO_DIR:-/opt/odoo}"

    read -r -p "Remote config file [/etc/odoo/odoo.conf]: " SRV_CONF
    SRV_CONF="${SRV_CONF:-/etc/odoo/odoo.conf}"

    read -r -p "Remote service name [odoo]: " SRV_SERVICE
    SRV_SERVICE="${SRV_SERVICE:-odoo}"

    local CONF
    CONF="$(remote_config_file)"
    mkdir -p "$(dirname "$CONF")"

    cat >> "$CONF" <<EOF
[$SRV_NAME]
host=$SRV_HOST
user=$SRV_USER
port=$SRV_PORT
odoo_dir=$SRV_ODOO_DIR
config=$SRV_CONF
service=$SRV_SERVICE
EOF

    echo
    print_success "Server '$SRV_NAME' added."
    echo -e "  ${DIM}$SRV_USER@$SRV_HOST:$SRV_PORT${NC}"

    pause

}

##############################################################################
# List remote servers
##############################################################################

list_remote_servers()
{

    local CONF
    CONF="$(remote_config_file)"

    if [ ! -f "$CONF" ] || [ ! -s "$CONF" ]
    then
        echo -e "  ${DIM}No remote servers configured.${NC}"
        return
    fi

    local CURRENT_NAME=""
    while IFS= read -r line
    do
        if [[ "$line" =~ ^\[(.+)\]$ ]]
        then
            CURRENT_NAME="${BASH_REMATCH[1]}"
        elif [[ "$line" =~ ^host= ]]
        then
            local HOST="${line#host=}"
            local USER_LINE
            USER_LINE=$(grep -A1 "^\[$CURRENT_NAME\]" "$CONF" | grep "^user=" | head -1)
            local USER="${USER_LINE#user=}"

            printf "  ${GREEN}%-15s${NC} %s@%s\n" "$CURRENT_NAME" "$USER" "$HOST"
        fi
    done < "$CONF"

}

##############################################################################
# Get server config value
##############################################################################

get_server_config()
{

    local SERVER="$1"
    local KEY="$2"
    local CONF
    CONF="$(remote_config_file)"

    [ -f "$CONF" ] || return 1

    sed -n "/^\[$SERVER\]/,/^\[/p" "$CONF" | grep "^${KEY}=" | head -1 | cut -d'=' -f2-

}

##############################################################################
# Remote: check Odoo status
##############################################################################

remote_status()
{

    local SERVER="$1"
    local HOST USER PORT SERVICE

    HOST=$(get_server_config "$SERVER" "host")
    USER=$(get_server_config "$SERVER" "user")
    PORT=$(get_server_config "$SERVER" "port")
    SERVICE=$(get_server_config "$SERVER" "service")

    if [ -z "$HOST" ]
    then
        print_error "Server '$SERVER' not found."
        return 1
    fi

    print_info "Checking Odoo status on $SERVER ($HOST)..."

    ssh -p "$PORT" -o ConnectTimeout=5 "$USER@$HOST" \
        "systemctl is-active $SERVICE 2>/dev/null || echo 'unknown'" 2>/dev/null

}

##############################################################################
# Remote: start Odoo
##############################################################################

remote_start_odoo()
{

    local SERVER="$1"
    local HOST USER PORT SERVICE

    HOST=$(get_server_config "$SERVER" "host")
    USER=$(get_server_config "$SERVER" "user")
    PORT=$(get_server_config "$SERVER" "port")
    SERVICE=$(get_server_config "$SERVER" "service")

    if [ -z "$HOST" ]
    then
        print_error "Server '$SERVER' not found."
        return 1
    fi

    print_info "Starting Odoo on $SERVER ($HOST)..."

    ssh -p "$PORT" "$USER@$HOST" "sudo systemctl start $SERVICE" 2>/dev/null

    if [ $? -eq 0 ]
    then
        print_success "Odoo started on $SERVER"
    else
        print_error "Failed to start Odoo. Check SSH connection."
    fi

}

##############################################################################
# Remote: stop Odoo
##############################################################################

remote_stop_odoo()
{

    local SERVER="$1"
    local HOST USER PORT SERVICE

    HOST=$(get_server_config "$SERVER" "host")
    USER=$(get_server_config "$SERVER" "user")
    PORT=$(get_server_config "$SERVER" "port")
    SERVICE=$(get_server_config "$SERVER" "service")

    if [ -z "$HOST" ]
    then
        print_error "Server '$SERVER' not found."
        return 1
    fi

    print_info "Stopping Odoo on $SERVER ($HOST)..."

    ssh -p "$PORT" "$USER@$HOST" "sudo systemctl stop $SERVICE" 2>/dev/null

    if [ $? -eq 0 ]
    then
        print_success "Odoo stopped on $SERVER"
    else
        print_error "Failed to stop Odoo."
    fi

}

##############################################################################
# Remote: restart Odoo
##############################################################################

remote_restart_odoo()
{

    local SERVER="$1"
    local HOST USER PORT SERVICE

    HOST=$(get_server_config "$SERVER" "host")
    USER=$(get_server_config "$SERVER" "user")
    PORT=$(get_server_config "$SERVER" "port")
    SERVICE=$(get_server_config "$SERVER" "service")

    if [ -z "$HOST" ]
    then
        print_error "Server '$SERVER' not found."
        return 1
    fi

    print_info "Restarting Odoo on $SERVER ($HOST)..."

    ssh -p "$PORT" "$USER@$HOST" "sudo systemctl restart $SERVICE" 2>/dev/null

    if [ $? -eq 0 ]
    then
        print_success "Odoo restarted on $SERVER"
    else
        print_error "Failed to restart Odoo."
    fi

}

##############################################################################
# Remote: tail logs
##############################################################################

remote_logs()
{

    local SERVER="$1"
    local HOST USER PORT ODOO_DIR

    HOST=$(get_server_config "$SERVER" "host")
    USER=$(get_server_config "$SERVER" "user")
    PORT=$(get_server_config "$SERVER" "port")
    ODOO_DIR=$(get_server_config "$SERVER" "odoo_dir")

    if [ -z "$HOST" ]
    then
        print_error "Server '$SERVER' not found."
        return 1
    fi

    print_info "Tailing logs on $SERVER (Ctrl+C to stop)..."
    echo

    ssh -p "$PORT" "$USER@$HOST" "tail -f $ODOO_DIR/odoo.log 2>/dev/null || journalctl -u $(get_server_config "$SERVER" "service") -f"

}

##############################################################################
# Remote server menu
##############################################################################

remote_server_menu()
{

    while true
    do

        show_header

        echo "Remote Server Management"
        echo -e "${DIM}Manage remote Odoo instances via SSH${NC}"

        separator
        echo

        list_remote_servers

        echo
        separator
        echo

        menu_item "A" "Add Remote Server"
        menu_item "S" "Check Server Status"
        menu_item "1" "Start Remote Odoo"
        menu_item "2" "Stop Remote Odoo"
        menu_item "3" "Restart Remote Odoo"
        menu_item "4" "View Remote Logs"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            A|a) add_remote_server ;;
            S|s|1|2|3|4)
                read -r -p "Server name: " SRV
                [ -z "$SRV" ] && continue
                case "$CHOICE" in
                    S|s) remote_status "$SRV" ;;
                    1) remote_start_odoo "$SRV" ;;
                    2) remote_stop_odoo "$SRV" ;;
                    3) remote_restart_odoo "$SRV" ;;
                    4) remote_logs "$SRV" ;;
                esac
                ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

        pause

    done

}
