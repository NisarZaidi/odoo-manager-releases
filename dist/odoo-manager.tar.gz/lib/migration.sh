#!/bin/bash

##############################################################################
# migration.sh
# Database Migration Helper
# Assists with Odoo version upgrades and database migration tasks
##############################################################################

##############################################################################
# Check module compatibility for a target Odoo version
##############################################################################

check_migration_compatibility()
{

    show_header
    echo "Migration Compatibility Check"
    echo -e "${DIM}Check modules for compatibility with a target Odoo version${NC}"
    separator
    echo

    if [ -z "$PROJECT_PATH" ] || [ -z "$ODOO_PATH" ]
    then
        print_error "No project/workspace selected."
        pause
        return
    fi

    local CURRENT_VER
    CURRENT_VER=$(basename "$ODOO_PATH" | grep -oE '[0-9]+')

    echo -e "  ${WHITE}Current Version${NC} : Odoo $CURRENT_VER"
    echo

    read -r -p "Target Odoo version (e.g., 18): " TARGET_VER

    if [ -z "$TARGET_VER" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    if [ "$TARGET_VER" = "$CURRENT_VER" ]
    then
        print_info "Already on Odoo $TARGET_VER."
        pause
        return
    fi

    echo
    print_info "Checking module compatibility for Odoo $TARGET_VER..."
    echo

    local ADDONS_DIR="$PROJECT_PATH/custom_addons"
    [ ! -d "$ADDONS_DIR" ] && ADDONS_DIR="$PROJECT_PATH"

    local COMPATIBLE=0
    local NEEDS_UPDATE=0
    local UNKNOWN=0

    local m
    for m in "$ADDONS_DIR"/*
    do
        if [ ! -d "$m" ] || [ ! -f "$m/__manifest__.py" ]
        then
            continue
        fi

        local MOD_NAME
        MOD_NAME="$(basename "$m")"

        # Check for deprecated API usage
        local ISSUES=()

        # Check for openerp imports (deprecated since v9)
        if grep -r "from openerp" "$m" --include="*.py" -l >/dev/null 2>&1
        then
            ISSUES+=("Uses deprecated 'openerp' imports")
        fi

        # Check for api.multi (deprecated since v13)
        if grep -r "@api.multi" "$m" --include="*.py" -l >/dev/null 2>&1
        then
            ISSUES+=("Uses deprecated @api.multi decorator")
        fi

        # Check for api.one (deprecated since v13)
        if grep -r "@api.one" "$m" --include="*.py" -l >/dev/null 2>&1
        then
            ISSUES+=("Uses deprecated @api.one decorator")
        fi

        # Check for old-style XML IDs
        if grep -r "ir.model.access" "$m" --include="*.csv" -l >/dev/null 2>&1
        then
            : # This is fine, just checking it exists
        fi

        # Version check in target > 16
        if [ "$TARGET_VER" -ge 17 ] 2>/dev/null
        then
            # Check for old compute methods
            if grep -r "@api.depends.*store=False" "$m" --include="*.py" -l >/dev/null 2>&1
            then
                ISSUES+=("May need compute method updates for v17+")
            fi
        fi

        if [ ${#ISSUES[@]} -eq 0 ]
        then
            echo -e "  ${GREEN}✔${NC} $MOD_NAME - looks compatible"
            COMPATIBLE=$((COMPATIBLE + 1))
        else
            echo -e "  ${YELLOW}⚠${NC} $MOD_NAME - may need updates:"
            local ISSUE
            for ISSUE in "${ISSUES[@]}"
            do
                echo -e "      ${DIM}$ISSUE${NC}"
            done
            NEEDS_UPDATE=$((NEEDS_UPDATE + 1))
        fi
    done

    echo
    separator
    echo

    local TOTAL=$((COMPATIBLE + NEEDS_UPDATE))
    echo -e "  ${WHITE}Total Modules${NC}    : $TOTAL"
    echo -e "  ${GREEN}Compatible${NC}       : $COMPATIBLE"
    echo -e "  ${YELLOW}Needs Updates${NC}    : $NEEDS_UPDATE"

    echo

    if [ "$NEEDS_UPDATE" -gt 0 ]
    then
        print_warning "Some modules may need updates for Odoo $TARGET_VER."
        echo -e "  ${DIM}Review the Odoo migration guide for version-specific changes.${NC}"
    else
        print_success "All modules appear compatible with Odoo $TARGET_VER."
    fi

    echo
    pause

}

##############################################################################
# Generate migration checklist
##############################################################################

generate_migration_checklist()
{

    show_header
    echo "Migration Checklist"
    echo -e "${DIM}Step-by-step migration guide for Odoo version upgrade${NC}"
    separator
    echo

    if [ -z "$ODOO_PATH" ]
    then
        print_error "No workspace selected."
        pause
        return
    fi

    local CURRENT_VER
    CURRENT_VER=$(basename "$ODOO_PATH" | grep -oE '[0-9]+')

    echo -e "  ${WHITE}Current${NC}  : Odoo $CURRENT_VER"
    echo

    read -r -p "Target version: " TARGET_VER
    [ -z "$TARGET_VER" ] && return

    echo
    echo -e "  ${BOLD}Migration Checklist: Odoo $CURRENT_VER → $TARGET_VER${NC}"
    separator
    echo

    echo -e "  ${WHITE}Phase 1: Preparation${NC}"
    echo "  □ Backup all databases"
    echo "  □ Create a new workspace for Odoo $TARGET_VER"
    echo "  □ Check module compatibility (use Compatibility Check)"
    echo "  □ Review Odoo official migration guide"
    echo "  □ List all custom modules and their dependencies"
    echo

    echo -e "  ${WHITE}Phase 2: Code Migration${NC}"
    echo "  □ Update deprecated API calls"
    echo "  □ Update XML view definitions"
    echo "  □ Update security access rules"
    echo "  □ Test each module individually"
    echo "  □ Update __manifest__.py version"
    echo

    echo -e "  ${WHITE}Phase 3: Data Migration${NC}"
    echo "  □ Restore database to new workspace"
    echo "  □ Run Odoo $TARGET_VER database migration"
    echo "  □ Verify data integrity"
    echo "  □ Test critical workflows"
    echo "  □ Check reports and printed documents"
    echo

    echo -e "  ${WHITE}Phase 4: Go-Live${NC}"
    echo "  □ Final data sync"
    echo "  □ User acceptance testing"
    echo "  □ Update production server"
    echo "  □ Monitor for issues (first 48 hours)"
    echo

    pause

}

##############################################################################
# Migration menu
##############################################################################

migration_menu()
{

    while true
    do

        show_header

        echo "Database Migration Helper"
        echo -e "${DIM}Assist with Odoo version upgrades${NC}"

        separator
        echo

        menu_item "C" "Compatibility Check (check modules for target version)"
        menu_item "L" "Migration Checklist (step-by-step guide)"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            C|c) check_migration_compatibility ;;
            L|l) generate_migration_checklist ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}
