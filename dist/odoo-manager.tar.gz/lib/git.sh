#!/bin/bash

##############################################################################
# git.sh
# Per-Project Git Integration
##############################################################################

##############################################################################
# Is Project A Git Repository?
##############################################################################

project_is_git_repo()
{

    local TARGET="${1:-$PROJECT_PATH}"

    [ -n "$TARGET" ] || return 1

    git -C "$TARGET" rev-parse --is-inside-work-tree >/dev/null 2>&1

}

##############################################################################
# Current Branch
##############################################################################

project_git_branch()
{

    local TARGET="${1:-$PROJECT_PATH}"

    git -C "$TARGET" symbolic-ref --short HEAD 2>/dev/null || \
        git -C "$TARGET" rev-parse --short HEAD 2>/dev/null

}

##############################################################################
# Dirty File Count (uncommitted changes, staged + unstaged + untracked)
##############################################################################

project_git_dirty_count()
{

    local TARGET="${1:-$PROJECT_PATH}"

    git -C "$TARGET" status --porcelain 2>/dev/null | wc -l | tr -d ' '

}

##############################################################################
# Ahead / Behind Upstream
##############################################################################

project_git_ahead_behind()
{

    local TARGET="${1:-$PROJECT_PATH}"

    local UPSTREAM
    UPSTREAM=$(git -C "$TARGET" rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>/dev/null)

    if [ -z "$UPSTREAM" ]
    then
        echo "no upstream tracking branch"
        return
    fi

    local COUNTS
    COUNTS=$(git -C "$TARGET" rev-list --left-right --count "HEAD...$UPSTREAM" 2>/dev/null)

    local AHEAD BEHIND
    AHEAD=$(echo "$COUNTS" | awk '{print $1}')
    BEHIND=$(echo "$COUNTS" | awk '{print $2}')

    echo "${AHEAD:-0} ahead, ${BEHIND:-0} behind ($UPSTREAM)"

}

##############################################################################
# Last Commit Summary
##############################################################################

project_git_last_commit()
{

    local TARGET="${1:-$PROJECT_PATH}"

    git -C "$TARGET" log -1 --pretty=format:'%h %s (%cr)' 2>/dev/null

}

##############################################################################
# Short Status Badge (used in project list, e.g. "main ✔" / "main ●3")
# Prints nothing if the project isn't a git repo, so callers can skip
# the line entirely.
##############################################################################

project_git_badge()
{

    local TARGET="${1:-$PROJECT_PATH}"

    project_is_git_repo "$TARGET" || return 1

    local BRANCH DIRTY
    BRANCH=$(project_git_branch "$TARGET")
    DIRTY=$(project_git_dirty_count "$TARGET")

    if [ "$DIRTY" -eq 0 ] 2>/dev/null
    then
        echo -e "${CYAN}${BRANCH:-detached}${NC} ${GREEN}✔${NC}"
    else
        echo -e "${CYAN}${BRANCH:-detached}${NC} ${YELLOW}●${DIRTY}${NC}"
    fi

}

##############################################################################
# Commit & Push
#
# Lets the user stage either ALL changed files or specific file(s),
# commit with a message, then push - offering to set up the upstream
# tracking branch on first push if one isn't configured yet.
##############################################################################

project_git_commit_push()
{

    show_header

    echo "Commit & Push"
    echo "Project  : $PROJECT_NAME"
    echo "Location : $PROJECT_PATH"

    separator

    echo

    if ! project_is_git_repo "$PROJECT_PATH"
    then
        print_warning "This project is not a git repository."
        pause
        return
    fi

    local DIRTY
    DIRTY=$(project_git_dirty_count "$PROJECT_PATH")

    if [ "$DIRTY" -eq 0 ] 2>/dev/null
    then
        print_success "Nothing to commit - working tree is clean."
        pause
        return
    fi

    echo "Changed files:"
    echo

    git -C "$PROJECT_PATH" status --short

    echo

    separator

    echo
    menu_item "1" "Add all changed files"
    menu_item "2" "Add specific file(s)"
    echo
    menu_item "B" "Cancel"
    echo

    prompt_read ADD_CHOICE "Select Option: "

    case "$ADD_CHOICE" in

        1)

            git -C "$PROJECT_PATH" add -A

            ;;

        2)

            echo
            echo "Enter file path(s) relative to the project root."
            echo "Separate multiple files with a space. Leave empty to cancel."
            echo

            read -r -p "File(s): " FILES_INPUT

            if [ -z "$FILES_INPUT" ]
            then
                print_warning "No files entered. Cancelled."
                pause
                return
            fi

            local ADD_FAILED=0
            local F

            for F in $FILES_INPUT
            do

                if ! git -C "$PROJECT_PATH" add -- "$F" 2>/dev/null
                then
                    print_warning "Could not add: $F"
                    ADD_FAILED=1
                fi

            done

            if [ "$ADD_FAILED" -eq 1 ]
            then

                echo

                if ! confirm "Some files could not be added. Continue with the rest?"
                then
                    print_info "Cancelled."
                    pause
                    return
                fi

            fi

            ;;

        B|b)

            print_info "Cancelled."
            pause
            return
            ;;

        *)

            invalid_option
            return
            ;;

    esac

    if git -C "$PROJECT_PATH" diff --cached --quiet
    then
        print_warning "Nothing staged - commit cancelled."
        pause
        return
    fi

    echo
    echo "Staged changes:"
    echo

    git -C "$PROJECT_PATH" diff --cached --stat

    echo

    read -r -p "Commit Message: " COMMIT_MSG

    if [ -z "$COMMIT_MSG" ]
    then
        print_warning "Commit message cannot be empty. Cancelled."
        pause
        return
    fi

    if ! git -C "$PROJECT_PATH" commit -m "$COMMIT_MSG"
    then
        print_error "Commit failed."
        pause
        return
    fi

    print_success "Committed."
    echo

    if ! confirm "Push to remote now?"
    then
        print_info "Skipped push. You can push later from this menu."
        pause
        return
    fi

    local BRANCH
    BRANCH=$(project_git_branch "$PROJECT_PATH")

    local UPSTREAM
    UPSTREAM=$(git -C "$PROJECT_PATH" rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>/dev/null)

    echo

    if [ -n "$UPSTREAM" ]
    then

        if (cd "$PROJECT_PATH" && git push)
        then
            print_success "Pushed to $UPSTREAM."
        else
            print_error "Push failed."
        fi

    else

        print_info "No upstream tracking branch set for '$BRANCH'."

        read -r -p "Remote name [origin]: " REMOTE_NAME

        REMOTE_NAME="${REMOTE_NAME:-origin}"

        if (cd "$PROJECT_PATH" && git push -u "$REMOTE_NAME" "$BRANCH")
        then
            print_success "Pushed and set upstream to $REMOTE_NAME/$BRANCH."
        else
            print_error "Push failed."
        fi

    fi

    pause

}

##############################################################################
# Git Status Screen (interactive)
##############################################################################

project_git_menu()
{

    while true
    do

        show_header

        echo "Git Integration"
        echo "Project  : $PROJECT_NAME"
        echo "Location : $PROJECT_PATH"

        separator

        echo

        if ! project_is_git_repo "$PROJECT_PATH"
        then

            print_warning "This project is not a git repository."

            echo

            menu_item "1" "Initialize git repository here"
            echo
            menu_item "B" "Back"
            echo

            prompt_read CHOICE "Select Option: "

            case "$CHOICE" in

                1)

                    if git -C "$PROJECT_PATH" init >/dev/null 2>&1
                    then
                        print_success "Git repository initialized."
                    else
                        print_error "Failed to initialize repository."
                    fi

                    pause

                    ;;

                B|b)
                    return
                    ;;

                *)
                    invalid_option
                    ;;

            esac

            continue

        fi

        local BRANCH DIRTY AHEAD_BEHIND LAST_COMMIT
        BRANCH=$(project_git_branch "$PROJECT_PATH")
        DIRTY=$(project_git_dirty_count "$PROJECT_PATH")
        AHEAD_BEHIND=$(project_git_ahead_behind "$PROJECT_PATH")
        LAST_COMMIT=$(project_git_last_commit "$PROJECT_PATH")

        echo -e "${WHITE}Branch${NC}      : ${CYAN}${BRANCH:-detached}${NC}"

        if [ "$DIRTY" -eq 0 ] 2>/dev/null
        then
            echo -e "${WHITE}Status${NC}      : ${GREEN}✔ Clean${NC}"
        else
            echo -e "${WHITE}Status${NC}      : ${YELLOW}● ${DIRTY} uncommitted change(s)${NC}"
        fi

        echo -e "${WHITE}Remote${NC}      : ${DIM}${AHEAD_BEHIND}${NC}"
        echo -e "${WHITE}Last Commit${NC} : ${DIM}${LAST_COMMIT:-none yet}${NC}"

        echo

        separator

        echo
        menu_section "Git Actions"
        menu_item "1" "Pull Latest (git pull)"
        menu_item "2" "Full Status (git status)"
        menu_item "3" "Recent Log (last 10 commits)"
        menu_item "4" "Commit & Push"
        menu_item "5" "Stash Changes"
        menu_item "6" "Pop Stash"
        echo

        menu_section "Navigation"
        menu_item "R" "Refresh"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in

            1)

                echo

                # Smart pull: warn if there are uncommitted changes
                local PRE_PULL_DIRTY
                PRE_PULL_DIRTY=$(project_git_dirty_count "$PROJECT_PATH")

                if [ "$PRE_PULL_DIRTY" -gt 0 ] 2>/dev/null
                then
                    print_warning "You have $PRE_PULL_DIRTY uncommitted change(s)."

                    if confirm "Stash changes before pulling?"
                    then
                        git -C "$PROJECT_PATH" stash push -m "auto-stash before pull $(date +%H:%M)"
                        print_success "Changes stashed."
                        echo
                    fi
                fi

                if (cd "$PROJECT_PATH" && git pull)
                then
                    print_success "Pulled latest changes."
                else
                    print_error "Pull failed. Resolve conflicts manually, then try again."
                fi

                pause

                ;;

            2)

                show_header

                echo "Git Status - $PROJECT_NAME"

                separator

                echo

                git -C "$PROJECT_PATH" status

                pause

                ;;

            3)

                show_header

                echo "Recent Commits - $PROJECT_NAME"

                separator

                echo

                git -C "$PROJECT_PATH" log -10 --oneline --decorate

                echo

                pause

                ;;

            4)

                project_git_commit_push

                ;;

            5)

                echo

                local STASH_DIRTY
                STASH_DIRTY=$(project_git_dirty_count "$PROJECT_PATH")

                if [ "$STASH_DIRTY" -eq 0 ] 2>/dev/null
                then
                    print_success "Nothing to stash - working tree is clean."
                else
                    git -C "$PROJECT_PATH" stash push -m "manual stash $(date +%Y-%m-%d_%H:%M)"
                    print_success "Changes stashed ($STASH_DIRTY file(s))."
                fi

                pause

                ;;

            6)

                echo

                local STASH_LIST
                STASH_LIST=$(git -C "$PROJECT_PATH" stash list 2>/dev/null)

                if [ -z "$STASH_LIST" ]
                then
                    print_warning "No stashed changes found."
                else
                    echo "Stash entries:"
                    echo "$STASH_LIST" | head -n 5 | sed 's/^/  /'
                    echo

                    if confirm "Pop the most recent stash?"
                    then
                        if git -C "$PROJECT_PATH" stash pop
                        then
                            print_success "Stash popped."
                        else
                            print_error "Stash pop failed (conflicts?)."
                        fi
                    fi
                fi

                pause

                ;;

            R|r)
                continue
                ;;

            B|b)
                return
                ;;

            *)
                invalid_option
                ;;

        esac

    done

}
