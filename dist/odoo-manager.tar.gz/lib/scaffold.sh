#!/bin/bash

##############################################################################
# scaffold.sh
# Advanced Module Scaffold Generator
# Creates Odoo modules with best-practice boilerplate
##############################################################################

##############################################################################
# Advanced Module Scaffold
##############################################################################

scaffold_advanced_module()
{

    show_header

    echo "Advanced Module Scaffold"
    echo -e "${DIM}Create a new Odoo module with best-practice boilerplate${NC}"

    separator
    echo

    if [ -z "$PROJECT_PATH" ] || [ ! -d "$PROJECT_PATH" ]
    then
        print_error "No project selected."
        pause
        return
    fi

    local ADDONS_DIR="$PROJECT_PATH/custom_addons"

    if [ ! -d "$ADDONS_DIR" ]
    then
        ADDONS_DIR="$PROJECT_PATH"
    fi

    echo -e "  ${WHITE}Target${NC} : $ADDONS_DIR"
    echo

    # Module technical name
    read -r -p "Module technical name (e.g., hospital_management): " MODULE_NAME

    if [ -z "$MODULE_NAME" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    MODULE_NAME=$(echo "$MODULE_NAME" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9_]/_/g')

    if [ -d "$ADDONS_DIR/$MODULE_NAME" ]
    then
        print_error "Module '$MODULE_NAME' already exists."
        pause
        return
    fi

    # Module display name
    local DISPLAY_NAME
    DISPLAY_NAME=$(echo "$MODULE_NAME" | sed 's/_/ /g' | sed 's/\b\(.\)/\u\1/g')
    read -r -p "Display name [$DISPLAY_NAME]: " INPUT_NAME
    DISPLAY_NAME="${INPUT_NAME:-$DISPLAY_NAME}"

    # Module summary
    read -r -p "Short summary: " MODULE_SUMMARY
    MODULE_SUMMARY="${MODULE_SUMMARY:-Custom module for Odoo}"

    # Module type
    echo
    echo "Module type:"
    echo "  1) Standard (models + views)"
    echo "  2) Wizard (transient model + wizard view)"
    echo "  3) Report (QWeb report template)"
    echo "  4) Full (models + views + wizard + report + controllers)"
    echo
    read -r -p "Choice [1]: " MODULE_TYPE
    MODULE_TYPE="${MODULE_TYPE:-1}"

    echo
    print_info "Creating module '$MODULE_NAME'..."

    local MOD_DIR="$ADDONS_DIR/$MODULE_NAME"
    mkdir -p "$MOD_DIR"/{models,views,security,data,wizard,report,controllers,static/description}

    # __init__.py (root)
    cat > "$MOD_DIR/__init__.py" <<PYEOF
# -*- coding: utf-8 -*-

from . import models
PYEOF

    # models/__init__.py
    cat > "$MOD_DIR/models/__init__.py" <<PYEOF
# -*- coding: utf-8 -*-

from . import ${MODULE_NAME}
PYEOF

    # models/main.py
    local MODEL_NAME
    MODEL_NAME=$(echo "$MODULE_NAME" | sed 's/_/./g')

    cat > "$MOD_DIR/models/${MODULE_NAME}.py" <<PYEOF
# -*- coding: utf-8 -*-

import logging
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class ${DISPLAY_NAME// /}(models.Model):
    _name = '${MODEL_NAME}'
    _description = '${DISPLAY_NAME}'
    _inherit = []
    _order = 'id desc'

    name = fields.Char(string='Name', required=True, tracking=True)
    active = fields.Boolean(string='Active', default=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', default='draft', tracking=True, readonly=True)

    @api.depends('name')
    def _compute_display_name(self):
        for record in self:
            record.display_name = record.name or _('New')

    def action_confirm(self):
        self.write({'state': 'confirmed'})
        return True

    def action_done(self):
        self.write({'state': 'done'})
        return True

    def action_cancel(self):
        self.write({'state': 'cancel'})
        return True

    def action_draft(self):
        self.write({'state': 'draft'})
        return True
PYEOF

    # views/main.xml
    cat > "$MOD_DIR/views/${MODULE_NAME}_views.xml" <<XMLEOF
<?xml version="1.0" encoding="utf-8"?>
<odoo>

    <!-- Tree View -->
    <record id="view_${MODULE_NAME}_tree" model="ir.ui.view">
        <field name="name">${MODEL_NAME}.tree</field>
        <field name="model">${MODEL_NAME}</field>
        <field name="arch" type="xml">
            <tree string="${DISPLAY_NAME}">
                <field name="name"/>
                <field name="state" widget="badge"
                       decoration-info="state == 'draft'"
                       decoration-success="state == 'done'"
                       decoration-warning="state == 'confirmed'"/>
            </tree>
        </field>
    </record>

    <!-- Form View -->
    <record id="view_${MODULE_NAME}_form" model="ir.ui.view">
        <field name="name">${MODEL_NAME}.form</field>
        <field name="model">${MODEL_NAME}</field>
        <field name="arch" type="xml">
            <form string="${DISPLAY_NAME}">
                <header>
                    <button name="action_confirm" string="Confirm" type="object"
                            class="btn-primary" states="draft"/>
                    <button name="action_done" string="Done" type="object"
                            class="btn-primary" states="confirmed"/>
                    <button name="action_cancel" string="Cancel" type="object"
                            states="draft,confirmed"/>
                    <button name="action_draft" string="Reset to Draft" type="object"
                            states="cancel"/>
                    <field name="state" widget="statusbar"
                           statusbar_visible="draft,confirmed,done"/>
                </header>
                <sheet>
                    <div class="oe_title">
                        <h1>
                            <field name="name" placeholder="Name..."/>
                        </h1>
                    </div>
                    <group>
                        <group>
                            <field name="active" invisible="1"/>
                        </group>
                    </group>
                </sheet>
                <div class="oe_chatter">
                    <field name="message_follower_ids"/>
                    <field name="activity_ids"/>
                    <field name="message_ids"/>
                </div>
            </form>
        </field>
    </record>

    <!-- Search View -->
    <record id="view_${MODULE_NAME}_search" model="ir.ui.view">
        <field name="name">${MODEL_NAME}.search</field>
        <field name="model">${MODEL_NAME}</field>
        <field name="arch" type="xml">
            <search string="${DISPLAY_NAME}">
                <field name="name"/>
                <filter name="filter_draft" string="Draft"
                        domain="[('state', '=', 'draft')]"/>
                <filter name="filter_done" string="Done"
                        domain="[('state', '=', 'done')]"/>
                <group expand="0" string="Group By">
                    <filter name="group_state" string="Status"
                            context="{'group_by': 'state'}"/>
                </group>
            </search>
        </field>
    </record>

    <!-- Action -->
    <record id="action_${MODULE_NAME}" model="ir.actions.act_window">
        <field name="name">${DISPLAY_NAME}</field>
        <field name="res_model">${MODEL_NAME}</field>
        <field name="view_mode">tree,form</field>
        <field name="help" type="html">
            <p class="o_view_nocontent_smiling_face">
                Create your first ${DISPLAY_NAME}
            </p>
        </field>
    </record>

    <!-- Menu Items -->
    <menuitem id="menu_${MODULE_NAME}_root"
              name="${DISPLAY_NAME}"
              web_icon="${MODULE_NAME},static/description/icon.png"
              sequence="100"/>

    <menuitem id="menu_${MODULE_NAME}_main"
              name="${DISPLAY_NAME}"
              parent="menu_${MODULE_NAME}_root"
              action="action_${MODULE_NAME}"
              sequence="10"/>

</odoo>
XMLEOF

    # security/ir.model.access.csv
    cat > "$MOD_DIR/security/ir.model.access.csv" <<CSVEOF
id,name,model_id:id,group_id:id,perm_read,perm_write,perm_create,perm_unlink
access_${MODULE_NAME}_user,${MODEL_NAME}.user,model_${MODULE_NAME},base.group_user,1,1,1,0
access_${MODULE_NAME}_manager,${MODEL_NAME}.manager,model_${MODULE_NAME},base.group_system,1,1,1,1
CSVEOF

    # security/security.xml
    cat > "$MOD_DIR/security/security.xml" <<XMLEOF
<?xml version="1.0" encoding="utf-8"?>
<odoo>
    <data noupdate="0">

        <record id="module_category_${MODULE_NAME}" model="ir.module.category">
            <field name="name">${DISPLAY_NAME}</field>
            <field name="sequence">100</field>
        </record>

        <record id="group_${MODULE_NAME}_user" model="res.groups">
            <field name="name">User</field>
            <field name="category_id" ref="module_category_${MODULE_NAME}"/>
        </record>

        <record id="group_${MODULE_NAME}_manager" model="res.groups">
            <field name="name">Manager</field>
            <field name="category_id" ref="module_category_${MODULE_NAME}"/>
            <field name="implied_ids" eval="[(4, ref('group_${MODULE_NAME}_user'))]"/>
        </record>

    </data>
</odoo>
XMLEOF

    # __manifest__.py
    cat > "$MOD_DIR/__manifest__.py" <<PYEOF
# -*- coding: utf-8 -*-
{
    'name': '${DISPLAY_NAME}',
    'version': '1.0.0',
    'category': 'Custom',
    'summary': '${MODULE_SUMMARY}',
    'description': """
${DISPLAY_NAME}
$(printf '=%.0s' $(seq 1 ${#DISPLAY_NAME}))

${MODULE_SUMMARY}
    """,
    'author': 'Your Company',
    'website': 'https://yourcompany.com',
    'license': 'LGPL-3',
    'depends': ['base', 'mail'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/${MODULE_NAME}_views.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
PYEOF

    # data/demo.xml
    cat > "$MOD_DIR/data/demo.xml" <<XMLEOF
<?xml version="1.0" encoding="utf-8"?>
<odoo>
    <data noupdate="1">

        <record id="demo_${MODULE_NAME}_1" model="${MODEL_NAME}">
            <field name="name">Demo Record 1</field>
        </record>

    </data>
</odoo>
XMLEOF

    # Wizard scaffold
    if [ "$MODULE_TYPE" = "2" ] || [ "$MODULE_TYPE" = "4" ]
    then

        cat > "$MOD_DIR/wizard/__init__.py" <<PYEOF
# -*- coding: utf-8 -*-

from . import ${MODULE_NAME}_wizard
PYEOF

        cat > "$MOD_DIR/wizard/${MODULE_NAME}_wizard.py" <<PYEOF
# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class ${DISPLAY_NAME// /}Wizard(models.TransientModel):
    _name = '${MODEL_NAME}.wizard'
    _description = '${DISPLAY_NAME} Wizard'

    name = fields.Char(string='Name', required=True)

    def action_apply(self):
        self.ensure_one()
        # Wizard logic here
        return {'type': 'ir.actions.act_window_close'}
PYEOF

        cat > "$MOD_DIR/wizard/${MODULE_NAME}_wizard_views.xml" <<XMLEOF
<?xml version="1.0" encoding="utf-8"?>
<odoo>

    <record id="view_${MODULE_NAME}_wizard_form" model="ir.ui.view">
        <field name="name">${MODEL_NAME}.wizard.form</field>
        <field name="model">${MODEL_NAME}.wizard</field>
        <field name="arch" type="xml">
            <form string="${DISPLAY_NAME} Wizard">
                <group>
                    <field name="name"/>
                </group>
                <footer>
                    <button name="action_apply" string="Apply" type="object" class="btn-primary"/>
                    <button string="Cancel" class="btn-secondary" special="cancel"/>
                </footer>
            </form>
        </field>
    </record>

    <record id="action_${MODULE_NAME}_wizard" model="ir.actions.act_window">
        <field name="name">${DISPLAY_NAME} Wizard</field>
        <field name="res_model">${MODEL_NAME}.wizard</field>
        <field name="view_mode">form</field>
        <field name="target">new</field>
    </record>

</odoo>
XMLEOF

        # Update root __init__.py to include wizard
        cat > "$MOD_DIR/__init__.py" <<PYEOF
# -*- coding: utf-8 -*-

from . import models
from . import wizard
PYEOF

    fi

    # Controller scaffold
    if [ "$MODULE_TYPE" = "4" ]
    then

        cat > "$MOD_DIR/controllers/__init__.py" <<PYEOF
# -*- coding: utf-8 -*-

from . import main
PYEOF

        cat > "$MOD_DIR/controllers/main.py" <<PYEOF
# -*- coding: utf-8 -*-

import json
import logging
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class ${DISPLAY_NAME// /}Controller(http.Controller):

    @http.route('/${MODULE_NAME}', type='http', auth='user', website=True)
    def index(self, **kwargs):
        return request.render('${MODULE_NAME}.${MODULE_NAME}_page', {})

    @http.route('/api/${MODULE_NAME}', type='json', auth='user')
    def api_list(self, **kwargs):
        records = request.env['${MODEL_NAME}'].sudo().search([])
        return [{'id': r.id, 'name': r.name} for r in records]
PYEOF

        # Update root __init__.py to include controllers
        cat > "$MOD_DIR/__init__.py" <<PYEOF
# -*- coding: utf-8 -*-

from . import models
from . import wizard
from . import controllers
PYEOF

    fi

    # Remove empty dirs if not used
    [ -z "$(ls -A "$MOD_DIR/report" 2>/dev/null)" ] && rmdir "$MOD_DIR/report" 2>/dev/null
    [ -z "$(ls -A "$MOD_DIR/static/description" 2>/dev/null)" ] && rmdir "$MOD_DIR/static/description" 2>/dev/null
    rmdir "$MOD_DIR/static" 2>/dev/null

    # Update __manifest__.py data list for wizard
    if [ "$MODULE_TYPE" = "2" ] || [ "$MODULE_TYPE" = "4" ]
    then
        sed -i "s|'views/${MODULE_NAME}_views.xml',|'views/${MODULE_NAME}_views.xml',\n        'wizard/${MODULE_NAME}_wizard_views.xml',|" "$MOD_DIR/__manifest__.py"
    fi

    # Git init if parent is a git repo
    if type project_is_git_repo >/dev/null 2>&1 && project_is_git_repo "$PROJECT_PATH"
    then
        echo
        if confirm "Stage new module files in git?"
        then
            git -C "$PROJECT_PATH" add "$MOD_DIR"
            print_success "Module staged in git."
        fi
    fi

    echo
    print_success "Module '$MODULE_NAME' created successfully!"
    echo
    echo -e "  ${WHITE}Location${NC}   : $MOD_DIR"
    echo -e "  ${WHITE}Model${NC}      : $MODEL_NAME"
    echo -e "  ${WHITE}Display${NC}    : $DISPLAY_NAME"

    local FILE_COUNT
    FILE_COUNT=$(find "$MOD_DIR" -type f | wc -l | tr -d ' ')
    echo -e "  ${WHITE}Files${NC}      : $FILE_COUNT"

    echo
    pause

}
