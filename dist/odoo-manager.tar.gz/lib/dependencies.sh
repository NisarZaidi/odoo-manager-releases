#!/bin/bash

##############################################################################
# dependencies.sh
# Module Dependency Graph
# Shows dependency tree for Odoo modules in the current project
##############################################################################

##############################################################################
# Extract dependencies from __manifest__.py
##############################################################################

module_get_depends()
{

    local MANIFEST="$1"

    [ -f "$MANIFEST" ] || return 1

    # Extract 'depends' list from manifest
    python3 -c "
import ast, sys
try:
    with open('$MANIFEST') as f:
        data = ast.literal_eval(f.read())
    deps = data.get('depends', [])
    for d in deps:
        print(d)
except Exception:
    pass
" 2>/dev/null

}

##############################################################################
# Build dependency tree for all modules in project
##############################################################################

show_dependency_graph()
{

    show_header

    echo "Module Dependency Graph"
    echo -e "${DIM}Shows dependencies between modules in this project${NC}"

    separator
    echo

    if [ -z "$PROJECT_PATH" ] || [ ! -d "$PROJECT_PATH" ]
    then
        print_error "No project selected."
        pause
        return
    fi

    local ADDONS_DIR="$PROJECT_PATH/custom_addons"
    [ ! -d "$ADDONS_DIR" ] && ADDONS_DIR="$PROJECT_PATH"

    # Collect all modules
    local MODULES=()
    local m
    for m in "$ADDONS_DIR"/*
    do
        if [ -d "$m" ] && { [ -f "$m/__manifest__.py" ] || [ -f "$m/__openerp__.py" ]; }
        then
            MODULES+=("$(basename "$m")")
        fi
    done

    if [ ${#MODULES[@]} -eq 0 ]
    then
        print_warning "No modules found in this project."
        pause
        return
    fi

    echo -e "  ${WHITE}Project${NC} : $(basename "$PROJECT_PATH")"
    echo -e "  ${WHITE}Modules${NC} : ${#MODULES[@]}"
    echo
    separator
    echo

    # Show tree for each module
    local MOD_NAME MANIFEST DEPS
    for MOD_NAME in "${MODULES[@]}"
    do
        MANIFEST="$ADDONS_DIR/$MOD_NAME/__manifest__.py"
        [ ! -f "$MANIFEST" ] && MANIFEST="$ADDONS_DIR/$MOD_NAME/__openerp__.py"

        echo -e "  ${CYAN}${BOLD}$MOD_NAME${NC}"

        DEPS=$(module_get_depends "$MANIFEST")

        if [ -z "$DEPS" ]
        then
            echo -e "    ${DIM}└── (no dependencies)${NC}"
        else
            local DEP_COUNT=0
            local TOTAL_DEPS
            TOTAL_DEPS=$(echo "$DEPS" | wc -l | tr -d ' ')

            while IFS= read -r dep
            do
                DEP_COUNT=$((DEP_COUNT + 1))
                local CONNECTOR="├──"
                [ "$DEP_COUNT" -eq "$TOTAL_DEPS" ] && CONNECTOR="└──"

                # Check if dependency is also in project (local) or external
                if [ -d "$ADDONS_DIR/$dep" ]
                then
                    echo -e "    ${DIM}${CONNECTOR}${NC} ${GREEN}$dep${NC} ${DIM}(local)${NC}"
                else
                    echo -e "    ${DIM}${CONNECTOR}${NC} ${WHITE}$dep${NC} ${DIM}(external)${NC}"
                fi
            done <<< "$DEPS"
        fi

        echo
    done

    # Check for circular dependencies
    separator
    echo
    echo -e "  ${WHITE}${BOLD}Circular Dependency Check${NC}"
    echo

    local FOUND_CIRCULAR=0

    for MOD_NAME in "${MODULES[@]}"
    do
        MANIFEST="$ADDONS_DIR/$MOD_NAME/__manifest__.py"
        [ ! -f "$MANIFEST" ] && MANIFEST="$ADDONS_DIR/$MOD_NAME/__openerp__.py"

        local DEPS
        DEPS=$(module_get_depends "$MANIFEST")

        while IFS= read -r dep
        do
            [ -z "$dep" ] && continue
            local DEP_MANIFEST="$ADDONS_DIR/$dep/__manifest__.py"
            [ -f "$DEP_MANIFEST" ] || continue

            local REVERSE_DEPS
            REVERSE_DEPS=$(module_get_depends "$DEP_MANIFEST")

            if echo "$REVERSE_DEPS" | grep -qx "$MOD_NAME"
            then
                print_error "  ⚠ Circular: $MOD_NAME ↔ $dep"
                FOUND_CIRCULAR=1
            fi
        done <<< "$DEPS"
    done

    if [ "$FOUND_CIRCULAR" -eq 0 ]
    then
        print_success "  ✔ No circular dependencies detected"
    fi

    echo
    pause

}

##############################################################################
# Dependency statistics summary
##############################################################################

show_dependency_stats()
{

    show_header
    echo "Dependency Statistics"
    separator
    echo

    if [ -z "$PROJECT_PATH" ] || [ ! -d "$PROJECT_PATH" ]
    then
        print_error "No project selected."
        pause
        return
    fi

    local ADDONS_DIR="$PROJECT_PATH/custom_addons"
    [ ! -d "$ADDONS_DIR" ] && ADDONS_DIR="$PROJECT_PATH"

    declare -A DEP_COUNT

    local m
    for m in "$ADDONS_DIR"/*
    do
        if [ -d "$m" ] && [ -f "$m/__manifest__.py" ]
        then
            local DEPS
            DEPS=$(module_get_depends "$m/__manifest__.py")
            local COUNT=0
            [ -n "$DEPS" ] && COUNT=$(echo "$DEPS" | wc -l | tr -d ' ')
            DEP_COUNT["$(basename "$m")"]=$COUNT
        fi
    done

    # Sort by dependency count (most deps first)
    echo -e "  ${WHITE}Module${NC}                    ${WHITE}Dependencies${NC}"
    separator

    for MOD in "${!DEP_COUNT[@]}"
    do
        printf "  %-30s %s\n" "$MOD" "${DEP_COUNT[$MOD]}"
    done | sort -t' ' -k2 -rn

    echo
    pause

}
