#!/bin/bash

##############################################################################
# wizard.sh
# Odoo Development Manager - Workspace Creation Wizard
##############################################################################


##############################################################################
# Run Workspace Wizard
##############################################################################

run_workspace_wizard()
{

    show_wizard_header


    detect_existing_workspaces


    if [ ${#WORKSPACES[@]} -gt 0 ]
    then

        echo "Existing Workspaces"
        echo

        COUNT=1

        for WS in "${WORKSPACES[@]}"
        do
            echo -e " ${GREEN}${COUNT}${NC}) $(basename "$WS")"
            COUNT=$((COUNT+1))
        done

        echo
        separator
        echo

    fi


    echo "Create New Odoo Development Workspace"
    echo


    select_workspace_version

    VERSION_STATUS=$?


    if [ "$VERSION_STATUS" -ne 0 ]
    then
        return
    fi



    select_workspace_location


    check_existing_workspace


    create_workspace

    clone_odoo

    create_virtual_environment

    create_log_directory

    create_projects_directory

    show_database_connection_check

    if [ $? -eq 1 ]
    then

        echo

        if ! confirm "PostgreSQL is not reachable right now. Continue creating the workspace anyway?"
        then

            print_warning "Workspace creation paused. Fix PostgreSQL access and re-run the wizard."

            pause

            return

        fi

    fi

    create_configuration

    export_workspace


    wizard_progress 7 7 "Create your first project (optional)"

    LAST_CREATED_PROJECT=""
    LAST_CREATED_MODULE=""

    if confirm "Create your first project now? (asks project name, then a starter module)"
    then

        project_generator

    fi


    finish_workspace


    echo

    if confirm "Start Odoo now? (opens your browser straight to the database manager)"
    then

        validate_configuration

        start_odoo

    else

        pause

    fi

}



##############################################################################
# Select Odoo Version
##############################################################################

select_workspace_version()
{

while true
do


echo
echo "Select Odoo Version"
echo

echo "Common versions: 13, 14, 15, 16, 17, 18, 19 ..."
echo "You can enter any Odoo version number."

echo
echo -e " ${GREEN}M${NC}) Main Menu"
echo -e " ${GREEN}Q${NC}) Quit"

echo


read -r -p "Enter Odoo Version Number: " CHOICE



case "$CHOICE" in


M|m)

return 1

;;


Q|q)

    quit_manager

    ;;


*)

if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]
then

invalid_option

continue

fi


if [ "$CHOICE" -lt 1 ]
then

invalid_option

continue

fi


ODOO_VERSION="$CHOICE"

break

;;

esac


done


return 0

}



##############################################################################
# Workspace Location
##############################################################################

select_workspace_location()
{


echo


read -r -p "Workspace Location [$WORKSPACE_ROOT]: " LOCATION


if [ -z "$LOCATION" ]
then

LOCATION="$WORKSPACE_ROOT"

fi



WORKSPACE_ROOT="$LOCATION"


WORKSPACE_PATH="$WORKSPACE_ROOT/odoo$ODOO_VERSION"



export WORKSPACE_ROOT
export WORKSPACE_PATH



}



##############################################################################
# Existing Workspace Check
##############################################################################

check_existing_workspace()
{


if [ -d "$WORKSPACE_PATH" ]
then


echo

print_warning "Workspace already exists:"
echo "$WORKSPACE_PATH"


echo

echo -e " ${GREEN}1${NC}) Open Workspace"
echo -e " ${GREEN}2${NC}) Create Another"
echo -e " ${GREEN}Q${NC}) Exit"


read -r -p "Choice: " EXISTING



case "$EXISTING" in


1)

ODOO_PATH="$WORKSPACE_PATH"

export ODOO_PATH

select_project

exit 0

;;



2)

select_workspace_version

select_workspace_location

check_existing_workspace

;;



Q|q)

quit_manager

;;



*)

invalid_option

;;

esac


fi


}



##############################################################################
# Create Workspace
##############################################################################

create_workspace()
{


wizard_progress 1 7 "Creating workspace folders..."


mkdir -p "$WORKSPACE_PATH"/{odoo,enterprise,projects,logs,backup}



print_success "Workspace folders created."


}



##############################################################################
# Clone Odoo
##############################################################################

clone_odoo()
{


wizard_progress 2 7 "Cloning Odoo Community ($ODOO_VERSION.0)..."


if [ -d "$WORKSPACE_PATH/odoo/.git" ]
then

print_warning "Odoo already cloned."

return

fi


local ODOO_REMOTE="https://github.com/odoo/odoo.git"
local BRANCH="$ODOO_VERSION.0"


if ! git ls-remote --exit-code --heads "$ODOO_REMOTE" "$BRANCH" >/dev/null 2>&1
then

print_warning "Branch '$BRANCH' not found on remote. Searching for a matching branch..."

local FOUND_BRANCH
FOUND_BRANCH=$(git ls-remote --heads "$ODOO_REMOTE" "refs/heads/${ODOO_VERSION}*" 2>/dev/null \
    | awk '{print $2}' \
    | sed 's#refs/heads/##' \
    | sort -V \
    | tail -n1)

if [ -n "$FOUND_BRANCH" ]
then

print_info "Using branch '$FOUND_BRANCH' instead."

BRANCH="$FOUND_BRANCH"

else

die "No branch found on remote matching Odoo version $ODOO_VERSION"

fi

fi


if ! git clone \
--depth 1 \
--branch "$BRANCH" \
"$ODOO_REMOTE" \
"$WORKSPACE_PATH/odoo"
then

die "Odoo clone failed"

fi



print_success "Odoo Community cloned (branch: $BRANCH)."


}



##############################################################################
# Python Environment
##############################################################################

##############################################################################
# Install requirements.txt into the ALREADY-ACTIVATED venv, with real
# success/failure checking (previous version just ran pip and moved on
# regardless of the result, so missing packages like PyPDF2 only showed
# up later as a crash when starting Odoo).
#
# Returns 0 if every package installed, 1 otherwise. Also prints exactly
# which package(s) are still missing on failure.
##############################################################################

_install_requirements_txt()
{

    local REQ_FILE="$1"

    [ -f "$REQ_FILE" ] || return 0

    # Installing the whole file in ONE "pip install -r" call is atomic -
    # if a single legacy/broken package (e.g. one still using the removed
    # use_2to3 flag) fails to build, pip aborts the ENTIRE batch and NONE
    # of the other, perfectly installable packages get installed either.
    # Installing line-by-line means one bad package only costs itself.
    #
    # Each package's name is printed as it starts (some packages, e.g.
    # gevent/Pillow/lxml, compile from source and can take a minute or
    # more with no output - without this, it looks frozen). Each attempt
    # is also bounded by a timeout so one stuck download/compile can
    # never hang the whole install indefinitely.

    local TIMEOUT_CMD=""

    if command_exists timeout
    then
        TIMEOUT_CMD="timeout 180"
    fi

    local TOTAL=0
    local PKG_LINE

    while IFS= read -r PKG_LINE
    do
        PKG_LINE="${PKG_LINE%%#*}"
        PKG_LINE=$(echo "$PKG_LINE" | xargs)
        [ -z "$PKG_LINE" ] && continue
        [[ "$PKG_LINE" == -* ]] && continue
        TOTAL=$((TOTAL+1))
    done < "$REQ_FILE"

    # Derive the Odoo version from the requirements.txt path itself
    # (.../odooNN/odoo/requirements.txt) rather than relying on a global
    # variable, so this works no matter which caller invokes this
    # function (wizard, Workspace Doctor, module scaffold self-heal).
    local ODOO_VER_NUM
    ODOO_VER_NUM=$(echo "$REQ_FILE" | grep -oE '/odoo[0-9]+/' | head -n1 | grep -oE '[0-9]+')

    # Known packages that publish new MAJOR releases which remove/rename
    # APIs older Odoo still depends on directly. When the exact pinned
    # version in requirements.txt fails to install, blindly grabbing
    # "whatever is latest on PyPI" (the old retry behaviour) silently
    # breaks Odoo at runtime instead of at install time - e.g. modern
    # Werkzeug removed werkzeug.contrib (ModuleNotFoundError at startup)
    # and modern lxml split out html.clean (AttributeError at startup).
    # Retry with a known-safe ceiling for these instead of the bare name.
    _pip_retry_spec()
    {

        local NAME="$1"
        local LOWER
        LOWER=$(echo "$NAME" | tr '[:upper:]' '[:lower:]')

        case "$LOWER" in

            lxml)
                echo "lxml<5"
                return
                ;;

            werkzeug)
                if [ -n "$ODOO_VER_NUM" ] && [ "$ODOO_VER_NUM" -le 13 ] 2>/dev/null
                then
                    echo "Werkzeug<1.0"
                elif [ -n "$ODOO_VER_NUM" ] && [ "$ODOO_VER_NUM" -le 16 ] 2>/dev/null
                then
                    echo "Werkzeug<2.1"
                else
                    echo "$NAME"
                fi
                return
                ;;

            markupsafe)
                if [ -n "$ODOO_VER_NUM" ] && [ "$ODOO_VER_NUM" -le 16 ] 2>/dev/null
                then
                    echo "MarkupSafe<2.1"
                else
                    echo "$NAME"
                fi
                return
                ;;

            jinja2)
                if [ -n "$ODOO_VER_NUM" ] && [ "$ODOO_VER_NUM" -le 16 ] 2>/dev/null
                then
                    echo "Jinja2<3.0"
                else
                    echo "$NAME"
                fi
                return
                ;;

            *)
                echo "$NAME"
                return
                ;;

        esac

    }

    local MISSING=()
    local CURRENT=0
    local PKG_NAME

    while IFS= read -r PKG_LINE
    do

        # Strip comments / blank lines / options (-e, -r, --hash, etc.)
        PKG_LINE="${PKG_LINE%%#*}"
        PKG_LINE=$(echo "$PKG_LINE" | xargs)

        [ -z "$PKG_LINE" ] && continue
        [[ "$PKG_LINE" == -* ]] && continue

        PKG_NAME=$(echo "$PKG_LINE" | sed -E 's/[<>=!~; \[].*//')

        [ -z "$PKG_NAME" ] && continue

        CURRENT=$((CURRENT+1))

        # Windows-only packages (guarded by markers in requirements.txt,
        # which pip's own resolver already ignores at the top level but
        # still surfaces here) can never install on Linux - skip instantly
        # instead of burning a timeout finding that out.
        case "$PKG_NAME" in
            pypiwin32|pywin32)
                printf "  ${DIM}[%d/%d] Skipping %s (Windows-only)${NC}\n" "$CURRENT" "$TOTAL" "$PKG_NAME"
                continue
                ;;
        esac

        local LABEL="[$CURRENT/$TOTAL] $PKG_NAME"

        $TIMEOUT_CMD pip install "$PKG_LINE" >/tmp/.odoo-manager-pip-$$.log 2>&1 &
        local PIP_PID=$!

        _pip_spinner "$PIP_PID" "$LABEL"

        wait "$PIP_PID"
        local PIP_RESULT=$?

        if [ "$PIP_RESULT" -eq 0 ]
        then

            printf "\r  ${GREEN}✔${NC} [%d/%d] %s\n" "$CURRENT" "$TOTAL" "$PKG_NAME"

        else

            # Retry with a known-safe version ceiling (see
            # _pip_retry_spec above) instead of blindly grabbing
            # whatever is newest on PyPI, which can be a breaking
            # major version for older Odoo.
            local RETRY_SPEC
            RETRY_SPEC="$(_pip_retry_spec "$PKG_NAME")"

            $TIMEOUT_CMD pip install "$RETRY_SPEC" >/tmp/.odoo-manager-pip-$$.log 2>&1 &
            PIP_PID=$!

            _pip_spinner "$PIP_PID" "$LABEL (retrying)"

            wait "$PIP_PID"
            PIP_RESULT=$?

            if [ "$PIP_RESULT" -eq 0 ]
            then
                printf "\r  ${GREEN}✔${NC} [%d/%d] %s\n" "$CURRENT" "$TOTAL" "$PKG_NAME"
            else
                printf "\r  ${RED}✘${NC} [%d/%d] %s - skipped\n" "$CURRENT" "$TOTAL" "$PKG_NAME"
                MISSING+=("$PKG_NAME")
            fi

        fi

        rm -f "/tmp/.odoo-manager-pip-$$.log"

    done < "$REQ_FILE"

    if [ ${#MISSING[@]} -gt 0 ]
    then
        print_warning "Could not install: ${MISSING[*]}"
        return 1
    fi

    return 0

}

##############################################################################
# Animated Spinner For A Background pip install
# Prints a rotating character + label on the SAME line (via \r) so the
# terminal never looks frozen while a package compiles from source.
##############################################################################

_pip_spinner()
{

    local PID="$1"
    local LABEL="$2"

    local SPIN='|/-\'
    local i=0
    local ELAPSED=0

    while kill -0 "$PID" 2>/dev/null
    do

        i=$(( (i + 1) % 4 ))

        printf "\r  ${CYAN}%s${NC} %s%s" "${SPIN:$i:1}" "$LABEL" "$(printf '.%.0s' $(seq 1 $((ELAPSED % 4 + 1))))    "

        sleep 0.2

        ELAPSED=$((ELAPSED + 1))

    done

}

create_virtual_environment()
{


wizard_progress 3 7 "Creating Python virtual environment..."


if ! create_odoo_venv "$WORKSPACE_PATH" "$ODOO_VERSION"
then

die "Python virtual environment failed"

fi



source "$WORKSPACE_PATH/env/bin/activate"



pip install --upgrade pip "setuptools<58" wheel



local REQ_FILE="$WORKSPACE_PATH/odoo/requirements.txt"
local REQ_OK=1

if [ -f "$REQ_FILE" ]
then

    if _install_requirements_txt "$REQ_FILE"
    then

        REQ_OK=1

    else

        REQ_OK=0

        print_warning "Some Python packages failed to install - retrying..."
        echo

        # Most common cause: missing system build headers needed to
        # compile packages like psycopg2 / lxml / Pillow from source.
        if command_exists apt-get && require_sudo
        then

            print_info "Installing system build dependencies (python3-dev, libpq-dev, build-essential) and retrying..."
            echo

            sudo apt-get update -y >/dev/null 2>&1
            sudo apt-get install -y python3-dev libpq-dev build-essential libxml2-dev libxslt1-dev zlib1g-dev libjpeg-dev libsasl2-dev libldap2-dev >/dev/null 2>&1

        fi

        if _install_requirements_txt "$REQ_FILE"
        then
            REQ_OK=1
        fi

    fi

fi



# Modern lxml (5.x+) split lxml.html.clean out into a separate PyPI
# package (lxml_html_clean) - but that standalone package's API doesn't
# match what older Odoo (13-16 range) expects ("clean.defs.safe_attrs"
# AttributeError). The reliable fix is keeping lxml itself BELOW 5.0,
# where html.clean (with .defs) is still bundled in - not installing
# the separate package at all.
pip uninstall -y lxml_html_clean >/dev/null 2>&1
pip install "lxml<5" >/dev/null 2>&1



deactivate



if [ "$REQ_OK" -eq 1 ]
then

    print_success "Python environment ready - all required packages installed."

else

    print_error "Some Python packages could not be installed automatically."
    echo
    echo "Odoo may fail to start (ModuleNotFoundError) until these are fixed."
    echo "Fix manually with:"
    echo
    echo "  source \"$WORKSPACE_PATH/env/bin/activate\""
    echo "  pip install -r \"$REQ_FILE\""
    echo "  deactivate"
    echo

    log_error "requirements.txt install incomplete for $WORKSPACE_PATH - see above for missing packages"

fi


}



##############################################################################
# Logs
##############################################################################

create_log_directory()
{


wizard_progress 4 7 "Setting up logs..."

mkdir -p "$WORKSPACE_PATH/logs"


touch "$WORKSPACE_PATH/logs/odoo.log"



print_success "Logs configured."


}



##############################################################################
# Projects
##############################################################################

create_projects_directory()
{


wizard_progress 5 7 "Setting up projects directory..."

mkdir -p "$WORKSPACE_PATH/projects"


print_success "Projects directory ready."


}


##############################################################################
# Detect PostgreSQL Superuser + Password
#
# Instead of always hardcoding db_user=odoo (a role that may not even
# exist locally), this tries to find a REAL superuser role that's
# actually usable on this machine:
#
#   1. The current OS user - Postgres peer-auth commonly grants the
#      Linux user's own name superuser rights (e.g. after `sudo -u
#      postgres createuser -s $(whoami)`), so this is the most likely
#      to work without a password.
#   2. The default 'postgres' role.
#   3. Fallback to 'odoo' if psql isn't available or neither is found.
#
# Password is left as False UNLESS one can be genuinely discovered
# (PGPASSWORD env var, or a matching entry in ~/.pgpass) - never
# invented/guessed, since a wrong password is worse than none.
##############################################################################
 
detect_db_user_and_password()
{
 
    DB_USER=""
    DB_PASSWORD="False"
 
    if command_exists psql
    then
 
        local WHOAMI
        WHOAMI="$(whoami)"
 
        if psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$WHOAMI' AND rolsuper = true" postgres >/dev/null 2>&1
        then
 
            DB_USER="$WHOAMI"
 
        elif psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='postgres' AND rolsuper = true" postgres >/dev/null 2>&1
        then
 
            DB_USER="postgres"
 
        fi
 
    fi
 
    if [ -z "$DB_USER" ]
    then
        DB_USER="odoo"
    fi
 
    # Look for a real, already-known password - never fabricate one.
    if [ -n "$PGPASSWORD" ]
    then
 
        DB_PASSWORD="$PGPASSWORD"
 
    elif [ -f "$HOME/.pgpass" ]
    then
 
        local PGPASS_LINE
        PGPASS_LINE=$(grep -E "^(\*|localhost|127\.0\.0\.1):(\*|[0-9]+):(\*|[^:]+):${DB_USER}:" "$HOME/.pgpass" 2>/dev/null | head -n1)
 
        if [ -n "$PGPASS_LINE" ]
        then
            DB_PASSWORD=$(echo "$PGPASS_LINE" | awk -F: '{print $5}')
        fi
 
    fi
 
    export DB_USER
    export DB_PASSWORD
 
}
 
##############################################################################
# Odoo Configuration
##############################################################################
 
create_configuration()
{
 
 
wizard_progress 6 6 "Generating odoo.conf..."
 
 
 
CONFIG="$WORKSPACE_PATH/odoo/debian/odoo.conf"
 
 
 
mkdir -p "$(dirname "$CONFIG")"
 
 
 
# admin_passwd is still a sane hardcoded default (change it later from
# Development Menu -> Configuration). db_user/db_password are no longer
# hardcoded - they're auto-detected from a real local Postgres role.
ADMIN_PASSWD="admin@123"
 
detect_db_user_and_password
 
export ADMIN_PASSWD
 
 
 
# Each Odoo version gets its own HTTP/Longpolling ports so multiple
# workspaces (e.g. odoo17, odoo18, odoo19) can run at the same time
# without clashing on the default 8069 / 8072 ports.
HTTP_PORT=$((8069 + (ODOO_VERSION * 10)))
LONGPOLLING_PORT=$((HTTP_PORT + 3))
 
if is_port_in_use "$HTTP_PORT"
then
 
    echo
    print_warning "Port $HTTP_PORT (the default for Odoo $ODOO_VERSION) is already in use."
    echo
 
    read -r -p "Enter a different HTTP port [Enter to keep $HTTP_PORT anyway]: " CUSTOM_PORT
 
    if [ -n "$CUSTOM_PORT" ] && [[ "$CUSTOM_PORT" =~ ^[0-9]+$ ]]
    then
        HTTP_PORT="$CUSTOM_PORT"
        LONGPOLLING_PORT=$((HTTP_PORT + 3))
    fi
 
fi
 
export HTTP_PORT
export LONGPOLLING_PORT
 
 
 
cat > "$CONFIG" <<EOF
[options]
 
 
admin_passwd = $ADMIN_PASSWD
 
 
; db_user was auto-detected from a real local PostgreSQL superuser role
; (falls back to 'odoo' if none could be detected). db_password is only
; ever filled in when a real one was found (PGPASSWORD / ~/.pgpass) -
; otherwise it stays False, same as before.
; Change these from the Development Menu -> Configuration (C), or
; by editing this file directly, before using this workspace in production.
db_host = False
db_port = False
db_user = $DB_USER
db_password = $DB_PASSWORD
 
 
; Only the core Odoo addons root is stored statically here.
; Enterprise and the currently selected project are appended dynamically
; at runtime by build_addons_path() in config.sh, but only when they
; contain real addon modules. This keeps older Odoo versions from
; rejecting empty workspace folders as invalid addons directories.
addons_path = $WORKSPACE_PATH/odoo/addons
 
 
http_port = $HTTP_PORT
longpolling_port = $LONGPOLLING_PORT
 
 
logfile = $WORKSPACE_PATH/logs/odoo.log
 
 
server_wide_modules = base,web
 
 
proxy_mode = True
 
EOF
 
 
 
print_success "odoo.conf created."
 
 
}


##############################################################################
# Export Workspace
##############################################################################

export_workspace()
{


ODOO_PATH="$WORKSPACE_PATH"

export ODOO_PATH



}



##############################################################################
# Finish
##############################################################################

finish_workspace()
{


echo

separator


echo -e "${GREEN}${BOLD}✔ Workspace Created Successfully${NC}"


echo


echo -e "${WHITE}Odoo Version${NC} : $ODOO_VERSION"

echo -e "${WHITE}Location${NC}     : $WORKSPACE_PATH"

echo -e "${WHITE}Admin Passwd${NC} : $ADMIN_PASSWD ${DIM}(also saved in odoo.conf)${NC}"
echo -e "${WHITE}DB User${NC}      : $DB_USER ${DIM}(change from Configuration menu if needed)${NC}"

echo -e "${WHITE}HTTP Port${NC}    : $HTTP_PORT"
echo -e "${WHITE}Longpolling${NC}  : $LONGPOLLING_PORT"


echo

echo -e "${WHITE}Structure${NC}"

echo


echo -e "${CYAN}odoo$ODOO_VERSION/${NC}"
echo "├── odoo"
echo "│   └── debian"
echo "│       └── odoo.conf"
echo "├── enterprise      (empty - add Enterprise addons here manually)"
echo "├── env"
echo "├── logs"
echo "│   └── odoo.log"
echo "├── backup"

if [ -n "$LAST_CREATED_PROJECT" ]
then

    echo "└── projects"
    echo "    └── $LAST_CREATED_PROJECT"

    if [ -n "$LAST_CREATED_MODULE" ]
    then
        echo "        └── $LAST_CREATED_MODULE   (starter module)"
    else
        echo "        (empty - no starter module was created)"
    fi

else

    echo "└── projects        (empty - create a project to add modules)"

fi


echo

separator

echo

if [ -n "$LAST_CREATED_PROJECT" ]
then
    echo "Next: start Odoo from the Development Menu."
else
    echo "Next: create a project, then start Odoo from the Development Menu."
fi

echo


}
