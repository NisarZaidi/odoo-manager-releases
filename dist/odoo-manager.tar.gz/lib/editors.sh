#!/bin/bash

##############################################################################
# editors.sh
# Editor Detection + One-Click Linux Install (VS Code / Cursor / PyCharm)
##############################################################################

EDITORS_INSTALL_DIR="$HOME/.local/share/odoo-manager/editors"
EDITORS_BIN_DIR="$HOME/.local/bin"

##############################################################################
# Detect A Given Editor's Launch Command (empty string if not found)
##############################################################################

detect_vscode_cmd()
{
    command_exists code && echo "code"
}

detect_cursor_cmd()
{

    if command_exists cursor
    then
        echo "cursor"
        return
    fi

    if [ -x "$EDITORS_BIN_DIR/cursor" ]
    then
        echo "$EDITORS_BIN_DIR/cursor"
    fi

}

detect_pycharm_cmd()
{

    if command_exists charm
    then
        echo "charm"
        return
    fi

    if command_exists pycharm
    then
        echo "pycharm"
        return
    fi

    if command_exists pycharm.sh
    then
        echo "pycharm.sh"
        return
    fi

    if command_exists snap && snap list 2>/dev/null | grep -q '^pycharm-community\b'
    then
        echo "snap run pycharm-community"
    fi

}

##############################################################################
# Editor Status Line (used by the menu so users see what's installed)
##############################################################################

editor_status_badge()
{

    local CMD="$1"

    if [ -n "$CMD" ]
    then
        echo -e "${GREEN}✔ Installed${NC}"
    else
        echo -e "${DIM}✘ Not installed${NC}"
    fi

}

##############################################################################
# Install VS Code (official Microsoft apt repository)
##############################################################################

install_vscode()
{

    show_header

    echo "Install Visual Studio Code"

    separator
    echo

    if [ -n "$(detect_vscode_cmd)" ]
    then
        print_success "VS Code is already installed."
        pause
        return 0
    fi

    if ! command_exists apt-get
    then
        print_warning "Automatic install only supports apt-get (Debian/Ubuntu)."
        echo "Download manually from: https://code.visualstudio.com/download"
        pause
        return 1
    fi

    if ! command_exists curl && ! command_exists wget
    then
        print_error "Neither curl nor wget found. Install one of them first."
        pause
        return 1
    fi

    if ! require_sudo
    then
        pause
        return 1
    fi

    print_info "Adding the official Microsoft repository..."
    echo

    sudo apt-get update -y
    sudo apt-get install -y wget gpg apt-transport-https >/dev/null

    local KEYRING="/usr/share/keyrings/packages.microsoft.gpg"

    if [ ! -f "$KEYRING" ]
    then

        wget -qO- https://packages.microsoft.com/keys/microsoft.asc \
            | gpg --dearmor \
            | sudo tee "$KEYRING" >/dev/null

    fi

    echo "deb [arch=amd64,arm64,armhf signed-by=$KEYRING] https://packages.microsoft.com/repos/code stable main" \
        | sudo tee /etc/apt/sources.list.d/vscode.list >/dev/null

    sudo apt-get update -y

    if sudo apt-get install -y code
    then
        print_success "VS Code installed successfully."
    else
        print_error "VS Code installation failed."
        pause
        return 1
    fi

    pause
    return 0

}

##############################################################################
# Install Cursor (official Linux AppImage - no apt/snap package exists)
##############################################################################

install_cursor()
{

    show_header

    echo "Install Cursor"

    separator
    echo

    if [ -n "$(detect_cursor_cmd)" ]
    then
        print_success "Cursor is already installed."
        pause
        return 0
    fi

    if ! command_exists curl
    then
        print_error "curl is required to download Cursor. Install it first (sudo apt-get install curl)."
        pause
        return 1
    fi

    mkdir -p "$EDITORS_INSTALL_DIR" "$EDITORS_BIN_DIR"

    local APPIMAGE="$EDITORS_INSTALL_DIR/cursor.AppImage"
    local DOWNLOAD_URL="https://downloader.cursor.sh/linux/appImage/x64"

    # This URL is maintained by Cursor, not us, and has changed before.
    # Check it actually resolves before spending time on a full download.
    if ! curl -fsIL --max-time 10 "$DOWNLOAD_URL" >/dev/null 2>&1
    then

        print_error "Cursor's download link isn't responding right now."
        echo "It may have moved. Please install manually from: https://cursor.com/download"
        pause
        return 1

    fi

    print_info "Downloading the latest Cursor AppImage..."
    echo

    if ! curl -fL --max-time 300 "$DOWNLOAD_URL" -o "$APPIMAGE"
    then
        print_error "Download failed."
        echo "You can download it manually from: https://cursor.com/download"
        pause
        return 1
    fi

    # Sanity check: a real AppImage is an ELF binary, usually 80MB+. If
    # the URL silently started returning an HTML redirect/error page
    # instead of the binary, this catches it before we "install" junk.
    if [ "$(head -c4 "$APPIMAGE" 2>/dev/null | tr -d '\0')" != $'\x7fELF' ]
    then

        print_error "The downloaded file doesn't look like a valid AppImage."
        echo "Cursor's download link may have changed format."
        echo "Please install manually from: https://cursor.com/download"

        rm -f "$APPIMAGE"

        pause
        return 1

    fi

    chmod +x "$APPIMAGE"

    # Extract a small icon-less launcher on PATH
    cat > "$EDITORS_BIN_DIR/cursor" <<EOF
#!/bin/bash
exec "$APPIMAGE" --no-sandbox "\$@"
EOF

    chmod +x "$EDITORS_BIN_DIR/cursor"

    # Desktop entry so it also shows up in the applications menu
    mkdir -p "$HOME/.local/share/applications"

    cat > "$HOME/.local/share/applications/cursor.desktop" <<EOF
[Desktop Entry]
Name=Cursor
Comment=AI-powered code editor
Exec=$EDITORS_BIN_DIR/cursor %F
Icon=cursor
Terminal=false
Type=Application
Categories=Development;IDE;
EOF

    if [[ ":$PATH:" != *":$EDITORS_BIN_DIR:"* ]]
    then
        print_warning "$EDITORS_BIN_DIR is not on your PATH yet - restart your terminal (or run: export PATH=\"$EDITORS_BIN_DIR:\$PATH\")."
    fi

    print_success "Cursor installed successfully."
    pause
    return 0

}

##############################################################################
# Install PyCharm (Community Edition via snap, fallback to JetBrains tar.gz)
##############################################################################

install_pycharm()
{

    show_header

    echo "Install PyCharm Community"

    separator
    echo

    if [ -n "$(detect_pycharm_cmd)" ]
    then
        print_success "PyCharm is already installed."
        pause
        return 0
    fi

    if command_exists snap && require_sudo
    then

        print_info "Installing PyCharm Community via snap..."
        echo

        if sudo snap install pycharm-community --classic
        then
            print_success "PyCharm Community installed successfully."
            pause
            return 0
        else
            print_warning "Snap install failed, falling back to manual tarball install..."
            echo
        fi

    else

        print_warning "snap install unavailable here - installing via JetBrains tarball instead."
        echo

    fi

    if ! command_exists curl
    then
        print_error "curl is required to download PyCharm. Install it first (sudo apt-get install curl)."
        pause
        return 1
    fi

    mkdir -p "$EDITORS_INSTALL_DIR"

    print_info "Downloading the latest PyCharm Community tarball..."
    echo

    local TARBALL="$EDITORS_INSTALL_DIR/pycharm.tar.gz"
    local DOWNLOAD_URL="https://data.services.jetbrains.com/products/download?platform=linux&code=PCC"

    if ! curl -fL "$DOWNLOAD_URL" -o "$TARBALL"
    then
        print_error "Download failed."
        echo "You can download it manually from: https://www.jetbrains.com/pycharm/download/#section=linux"
        pause
        return 1
    fi

    local EXTRACT_DIR="$EDITORS_INSTALL_DIR/pycharm"

    rm -rf "$EXTRACT_DIR"
    mkdir -p "$EXTRACT_DIR"

    tar -xzf "$TARBALL" -C "$EXTRACT_DIR" --strip-components=1

    mkdir -p "$EDITORS_BIN_DIR"

    ln -sf "$EXTRACT_DIR/bin/pycharm.sh" "$EDITORS_BIN_DIR/charm"

    if [[ ":$PATH:" != *":$EDITORS_BIN_DIR:"* ]]
    then
        print_warning "$EDITORS_BIN_DIR is not on your PATH yet - restart your terminal (or run: export PATH=\"$EDITORS_BIN_DIR:\$PATH\")."
    fi

    print_success "PyCharm Community installed successfully."
    pause
    return 0

}

##############################################################################
# Development Tools Menu (install / reinstall / update editors)
##############################################################################

editors_menu()
{

    while true
    do

        show_header

        echo "Install Development Tools"
        echo -e "${DIM}Editors are downloaded from their official sources and installed for this Linux user.${NC}"

        separator
        echo

        local VSCODE_CMD CURSOR_CMD PYCHARM_CMD
        VSCODE_CMD=$(detect_vscode_cmd)
        CURSOR_CMD=$(detect_cursor_cmd)
        PYCHARM_CMD=$(detect_pycharm_cmd)

        printf "  ${GREEN}1${NC}) %-20s %b\n" "VS Code" "$(editor_status_badge "$VSCODE_CMD")"
        printf "  ${GREEN}2${NC}) %-20s %b\n" "Cursor" "$(editor_status_badge "$CURSOR_CMD")"
        printf "  ${GREEN}3${NC}) %-20s %b\n" "PyCharm Community" "$(editor_status_badge "$PYCHARM_CMD")"

        echo
        menu_section "Bulk Actions"
        menu_item "A" "Install All Missing"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in

            1) install_vscode ;;
            2) install_cursor ;;
            3) install_pycharm ;;

            A|a)

                [ -z "$VSCODE_CMD" ]  && install_vscode
                [ -z "$CURSOR_CMD" ]  && install_cursor
                [ -z "$PYCHARM_CMD" ] && install_pycharm

                ;;

            B|b)
                return
                ;;

            *)
                invalid_option
                ;;

        esac

    done

}
