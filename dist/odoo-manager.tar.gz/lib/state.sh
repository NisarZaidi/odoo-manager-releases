#!/bin/bash

##############################################################################
# state.sh
# Lightweight persistent state for recents, favorites, and support assets
##############################################################################

state_root_dir()
{

    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}"

}

state_dir()
{

    echo "$(state_root_dir)/state"

}

state_file()
{

    local NAME="$1"

    echo "$(state_dir)/${NAME}.txt"

}

ensure_state_storage()
{

    mkdir -p "$(state_dir)"

    touch "$(state_file recent_workspaces)"
    touch "$(state_file recent_projects)"
    touch "$(state_file favorite_workspaces)"
    touch "$(state_file favorite_projects)"

}

state_has_line()
{

    local FILE="$1"
    local VALUE="$2"

    [ -f "$FILE" ] || return 1

    grep -Fxq -- "$VALUE" "$FILE"

}

state_prepend_unique_line()
{

    local FILE="$1"
    local VALUE="$2"
    local LIMIT="${3:-10}"

    ensure_state_storage

    local TMP
    TMP=$(mktemp)

    printf '%s\n' "$VALUE" > "$TMP"

    if [ -f "$FILE" ]
    then
        grep -Fxv -- "$VALUE" "$FILE" | head -n $((LIMIT - 1)) >> "$TMP"
    fi

    mv "$TMP" "$FILE"

}

state_toggle_line()
{

    local FILE="$1"
    local VALUE="$2"

    ensure_state_storage

    local TMP
    TMP=$(mktemp)

    if state_has_line "$FILE" "$VALUE"
    then
        grep -Fxv -- "$VALUE" "$FILE" > "$TMP" || true
        mv "$TMP" "$FILE"
        return 1
    fi

    printf '%s\n' "$VALUE" > "$TMP"

    if [ -f "$FILE" ]
    then
        cat "$FILE" >> "$TMP"
    fi

    mv "$TMP" "$FILE"
    return 0

}

state_read_lines()
{

    local FILE="$1"

    [ -f "$FILE" ] || return 0

    cat "$FILE"

}

record_recent_workspace()
{

    local WS_PATH="$1"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    state_prepend_unique_line "$(state_file recent_workspaces)" "$WS_NAME" 8

}

record_recent_project()
{

    local WS_PATH="$1"
    local PROJECT_PATH_VALUE="$2"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local PROJECT_NAME_VALUE
    PROJECT_NAME_VALUE=$(basename "$PROJECT_PATH_VALUE")

    state_prepend_unique_line "$(state_file recent_projects)" "${WS_NAME}|${PROJECT_NAME_VALUE}" 16

}

is_workspace_favorite()
{

    local WS_PATH_OR_NAME="$1"
    local WS_NAME="${WS_PATH_OR_NAME##*/}"

    state_has_line "$(state_file favorite_workspaces)" "$WS_NAME"

}

toggle_workspace_favorite()
{

    local WS_PATH_OR_NAME="$1"
    local WS_NAME="${WS_PATH_OR_NAME##*/}"

    state_toggle_line "$(state_file favorite_workspaces)" "$WS_NAME"

}

is_project_favorite()
{

    local WS_PATH="$1"
    local PROJECT_PATH_VALUE="$2"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local PROJECT_NAME_VALUE
    PROJECT_NAME_VALUE=$(basename "$PROJECT_PATH_VALUE")

    state_has_line "$(state_file favorite_projects)" "${WS_NAME}|${PROJECT_NAME_VALUE}"

}

toggle_project_favorite()
{

    local WS_PATH="$1"
    local PROJECT_PATH_VALUE="$2"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local PROJECT_NAME_VALUE
    PROJECT_NAME_VALUE=$(basename "$PROJECT_PATH_VALUE")

    state_toggle_line "$(state_file favorite_projects)" "${WS_NAME}|${PROJECT_NAME_VALUE}"

}

is_workspace_recent()
{

    local WS_PATH_OR_NAME="$1"
    local WS_NAME="${WS_PATH_OR_NAME##*/}"

    state_has_line "$(state_file recent_workspaces)" "$WS_NAME"

}

is_project_recent()
{

    local WS_PATH="$1"
    local PROJECT_PATH_VALUE="$2"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local PROJECT_NAME_VALUE
    PROJECT_NAME_VALUE=$(basename "$PROJECT_PATH_VALUE")

    state_has_line "$(state_file recent_projects)" "${WS_NAME}|${PROJECT_NAME_VALUE}"

}

##############################################################################
# Workspace / Project Notes
#
# Simple file-based notes stored per workspace (or workspace|project).
# Each note is a plain-text file in the state dir under notes/.
##############################################################################

notes_dir()
{

    echo "$(state_root_dir)/notes"

}

note_file()
{

    local KEY="$1"

    echo "$(notes_dir)/${KEY}.txt"

}

save_workspace_note()
{

    local WS_PATH="$1"
    local NOTE_TEXT="$2"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    mkdir -p "$(notes_dir)"

    printf '%s\n' "$NOTE_TEXT" > "$(note_file "ws_${WS_NAME}")"

}

read_workspace_note()
{

    local WS_PATH="$1"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local NF
    NF="$(note_file "ws_${WS_NAME}")"

    [ -f "$NF" ] && cat "$NF"

}

delete_workspace_note()
{

    local WS_PATH="$1"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    rm -f "$(note_file "ws_${WS_NAME}")"

}

save_project_note()
{

    local WS_PATH="$1"
    local PROJECT_PATH_VALUE="$2"
    local NOTE_TEXT="$3"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local PROJECT_NAME_VALUE
    PROJECT_NAME_VALUE=$(basename "$PROJECT_PATH_VALUE")

    mkdir -p "$(notes_dir)"

    printf '%s\n' "$NOTE_TEXT" > "$(note_file "proj_${WS_NAME}_${PROJECT_NAME_VALUE}")"

}

read_project_note()
{

    local WS_PATH="$1"
    local PROJECT_PATH_VALUE="$2"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local PROJECT_NAME_VALUE
    PROJECT_NAME_VALUE=$(basename "$PROJECT_PATH_VALUE")

    local NF
    NF="$(note_file "proj_${WS_NAME}_${PROJECT_NAME_VALUE}")"

    [ -f "$NF" ] && cat "$NF"

}

delete_project_note()
{

    local WS_PATH="$1"
    local PROJECT_PATH_VALUE="$2"
    local WS_NAME
    WS_NAME=$(basename "$WS_PATH")

    local PROJECT_NAME_VALUE
    PROJECT_NAME_VALUE=$(basename "$PROJECT_PATH_VALUE")

    rm -f "$(note_file "proj_${WS_NAME}_${PROJECT_NAME_VALUE}")"

}

##############################################################################
# Plugin System
#
# Sources any .sh files found in the plugins/ directory, allowing users
# to extend the manager with custom commands or menu items.
##############################################################################

load_plugins()
{

    local PLUGIN_DIR="$ROOT_DIR/plugins"

    [ -d "$PLUGIN_DIR" ] || return 0

    local PLUGIN_FILE
    for PLUGIN_FILE in "$PLUGIN_DIR"/*.sh
    do
        [ -f "$PLUGIN_FILE" ] || continue

        # shellcheck disable=SC1090 # plugins are user-provided extension scripts
        source "$PLUGIN_FILE"
    done

}
