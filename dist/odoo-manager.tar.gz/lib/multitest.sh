#!/bin/bash

##############################################################################
# multitest.sh
# Multi-Database Testing
# Test a module against multiple databases
##############################################################################

multitest_config_dir()
{
    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}/multitest"
}

##############################################################################
# Add a test database
##############################################################################

add_test_database()
{

    show_header
    echo "Add Test Database"
    separator
    echo

    read -r -p "Database name: " DB_NAME
    [ -z "$DB_NAME" ] && { print_warning "Cancelled."; pause; return; }

    read -r -p "Description (e.g., 'Production copy Q3'): " DB_DESC

    # Verify database exists
    if ! psql -lqt 2>/dev/null | awk -F'|' '{print $1}' | grep -qw "$DB_NAME"
    then
        print_warning "Database '$DB_NAME' not found in PostgreSQL. Add anyway?"
        if ! confirm "Continue?"
        then
            return
        fi
    fi

    local CONF_DIR
    CONF_DIR="$(multitest_config_dir)"
    mkdir -p "$CONF_DIR"

    echo "$DB_NAME|$DB_DESC|$(date -Iseconds)" >> "$CONF_DIR/databases.conf"

    echo
    print_success "Test database added: $DB_NAME"

    pause

}

##############################################################################
# List test databases
##############################################################################

list_test_databases()
{

    local CONF_FILE
    CONF_FILE="$(multitest_config_dir)/databases.conf"

    if [ ! -f "$CONF_FILE" ] || [ ! -s "$CONF_FILE" ]
    then
        echo -e "  ${DIM}No test databases configured.${NC}"
        return
    fi

    while IFS='|' read -r db_name db_desc db_added
    do
        [ -z "$db_name" ] && continue

        local STATUS=""
        if psql -lqt 2>/dev/null | awk -F'|' '{print $1}' | grep -qw "$db_name"
        then
            STATUS="${GREEN}●${NC}"
        else
            STATUS="${RED}○${NC}"
        fi

        printf "  $STATUS ${GREEN}%-20s${NC} %s\n" "$db_name" "${db_desc:-}"
    done < "$CONF_FILE"

}

##############################################################################
# Test a module against all test databases
##############################################################################

run_multitest()
{

    show_header
    echo "Multi-Database Module Test"
    echo -e "${DIM}Test a module upgrade against multiple databases${NC}"
    separator
    echo

    local CONF_FILE
    CONF_FILE="$(multitest_config_dir)/databases.conf"

    if [ ! -f "$CONF_FILE" ] || [ ! -s "$CONF_FILE" ]
    then
        print_warning "No test databases configured. Add some first."
        pause
        return
    fi

    if [ -z "$ODOO_PATH" ] || [ ! -d "$ODOO_PATH" ]
    then
        print_error "No workspace selected."
        pause
        return
    fi

    read -r -p "Module to test: " TEST_MODULE
    [ -z "$TEST_MODULE" ] && { print_warning "Cancelled."; pause; return; }

    echo
    echo "Test databases:"
    list_test_databases
    echo

    if ! confirm "Run module test against all databases above?"
    then
        print_info "Cancelled."
        pause
        return
    fi

    local ODOO_BIN="$ODOO_PATH/odoo/odoo-bin"
    local VENV_PYTHON="$ODOO_PATH/env/bin/python3"
    local ADDONS_PATH="$ODOO_PATH/odoo/addons,$ODOO_PATH/enterprise"

    if [ -d "$ODOO_PATH/projects" ]
    then
        local p
        for p in "$ODOO_PATH/projects"/*/custom_addons
        do
            [ -d "$p" ] && ADDONS_PATH="$ADDONS_PATH,$p"
        done
    fi

    echo
    print_info "Running module tests..."
    echo

    local RESULTS_FILE
    RESULTS_FILE="$(multitest_config_dir)/last_results.log"
    > "$RESULTS_FILE"

    local PASS=0
    local FAIL=0

    while IFS='|' read -r db_name db_desc db_added
    do
        [ -z "$db_name" ] && continue

        echo -n "  Testing $db_name... "

        # Run module init (dry-run test)
        local OUTPUT
        OUTPUT=$(timeout 60 "$VENV_PYTHON" "$ODOO_BIN" \
            -d "$db_name" \
            --addons-path="$ADDONS_PATH" \
            -i "$TEST_MODULE" \
            --stop-after-init \
            --no-http \
            2>&1)

        if [ $? -eq 0 ]
        then
            echo -e "${GREEN}PASS${NC}"
            echo "$db_name|PASS|$(date '+%Y-%m-%d %H:%M:%S')" >> "$RESULTS_FILE"
            PASS=$((PASS + 1))
        else
            echo -e "${RED}FAIL${NC}"
            echo "$db_name|FAIL|$(date '+%Y-%m-%d %H:%M:%S')" >> "$RESULTS_FILE"
            FAIL=$((FAIL + 1))

            # Show error snippet
            local ERROR_LINE
            ERROR_LINE=$(echo "$OUTPUT" | grep -i "error\|exception\|traceback" | head -1)
            if [ -n "$ERROR_LINE" ]
            then
                echo -e "    ${DIM}${ERROR_LINE:0:80}${NC}"
            fi
        fi

    done < "$CONF_FILE"

    echo
    separator
    echo

    local TOTAL=$((PASS + FAIL))
    echo -e "  ${WHITE}Results${NC} : $TOTAL tested, ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
    echo

    if [ "$FAIL" -eq 0 ]
    then
        print_success "All tests passed!"
    else
        print_warning "$FAIL test(s) failed. Check the output above."
    fi

    echo
    pause

}

##############################################################################
# Remove a test database
##############################################################################

remove_test_database()
{

    show_header
    echo "Remove Test Database"
    separator
    echo

    list_test_databases
    echo

    read -r -p "Database name to remove: " DEL_NAME
    [ -z "$DEL_NAME" ] && return

    local CONF_FILE
    CONF_FILE="$(multitest_config_dir)/databases.conf"

    if [ -f "$CONF_FILE" ] && grep -q "^${DEL_NAME}|" "$CONF_FILE"
    then
        sed -i "/^${DEL_NAME}|/d" "$CONF_FILE"
        print_success "Removed: $DEL_NAME"
    else
        print_error "Not found: $DEL_NAME"
    fi

    pause

}

##############################################################################
# Multi-test menu
##############################################################################

multitest_menu()
{

    while true
    do

        show_header

        echo "Multi-Database Testing"
        echo -e "${DIM}Test modules against multiple databases${NC}"

        separator
        echo

        list_test_databases

        echo
        separator
        echo

        menu_item "A" "Add Test Database"
        menu_item "R" "Remove Test Database"
        menu_item "T" "Run Module Test (all databases)"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            A|a) add_test_database ;;
            R|r) remove_test_database ;;
            T|t) run_multitest ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}
