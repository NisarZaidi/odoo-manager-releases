#!/bin/bash

##############################################################################
# quality.sh
# Module Quality Checker
# Checks Odoo modules for common issues and gives a quality score
##############################################################################

##############################################################################
# Run quality check on a single module
##############################################################################

check_module_quality()
{

    local MODULE_DIR="$1"
    local MODULE_NAME
    MODULE_NAME="$(basename "$MODULE_DIR")"

    local SCORE=10
    local ISSUES=()
    local WARNINGS=()

    local MANIFEST="$MODULE_DIR/__manifest__.py"
    local OPENERP="$MODULE_DIR/__openerp__.py"

    [ -f "$MANIFEST" ] || MANIFEST="$OPENERP"

    # Check 1: __manifest__.py exists
    if [ ! -f "$MANIFEST" ]
    then
        ISSUES+=("Missing __manifest__.py")
        SCORE=$((SCORE - 2))
    else
        # Check manifest fields
        if ! grep -q "'name'" "$MANIFEST" 2>/dev/null
        then
            WARNINGS+=("Manifest missing 'name' field")
            SCORE=$((SCORE - 1))
        fi

        if ! grep -q "'description'" "$MANIFEST" 2>/dev/null
        then
            WARNINGS+=("Manifest missing 'description' field")
            SCORE=$((SCORE - 1))
        fi

        if ! grep -q "'license'" "$MANIFEST" 2>/dev/null
        then
            WARNINGS+=("Manifest missing 'license' field")
            SCORE=$((SCORE - 1))
        fi

        if ! grep -q "'author'" "$MANIFEST" 2>/dev/null
        then
            WARNINGS+=("Manifest missing 'author' field")
            SCORE=$((SCORE - 1))
        fi

        if grep -q "'auto_install': True" "$MANIFEST" 2>/dev/null
        then
            WARNINGS+=("auto_install is True - module installs automatically with dependencies")
        fi
    fi

    # Check 2: security/ir.model.access.csv exists
    if [ ! -f "$MODULE_DIR/security/ir.model.access.csv" ]
    then
        WARNINGS+=("Missing security/ir.model.access.csv")
        SCORE=$((SCORE - 1))
    fi

    # Check 3: __init__.py exists
    if [ ! -f "$MODULE_DIR/__init__.py" ]
    then
        ISSUES+=("Missing __init__.py")
        SCORE=$((SCORE - 2))
    fi

    # Check 4: Python files - common issues
    local PY_FILES
    PY_FILES=$(find "$MODULE_DIR" -name "*.py" -not -path "*/__pycache__/*" -not -path "*/.git/*" 2>/dev/null)

    if [ -n "$PY_FILES" ]
    then
        # Check for print() statements
        local PRINT_COUNT
        PRINT_COUNT=$(echo "$PY_FILES" | xargs grep -l "print(" 2>/dev/null | wc -l | tr -d ' ')
        if [ "$PRINT_COUNT" -gt 0 ]
        then
            WARNINGS+=("$PRINT_COUNT file(s) use print() - should use logging instead")
            SCORE=$((SCORE - 1))
        fi

        # Check for missing -*- coding: utf-8 -*-
        local NO_CODING=0
        while IFS= read -r pyfile
        do
            [ -z "$pyfile" ] && continue
            if ! head -n 2 "$pyfile" | grep -q "coding" 2>/dev/null
            then
                NO_CODING=$((NO_CODING + 1))
            fi
        done <<< "$PY_FILES"

        if [ "$NO_CODING" -gt 0 ]
        then
            WARNINGS+=("$NO_CODING Python file(s) missing '# -*- coding: utf-8 -*-' header")
        fi

        # Check for except: (bare except)
        local BARE_EXCEPT
        BARE_EXCEPT=$(echo "$PY_FILES" | xargs grep -c "except:" 2>/dev/null | awk -F: '{sum+=$2} END{print sum+0}')
        if [ "$BARE_EXCEPT" -gt 0 ]
        then
            WARNINGS+=("$BARE_EXCEPT bare 'except:' found - should catch specific exceptions")
            SCORE=$((SCORE - 1))
        fi
    fi

    # Check 5: XML files
    local XML_FILES
    XML_FILES=$(find "$MODULE_DIR" -name "*.xml" -not -path "*/.git/*" 2>/dev/null)

    if [ -n "$XML_FILES" ]
    then
        # Check for hardcoded IDs (e.g., id="1" instead of using refs)
        local HARDCODED_IDS
        HARDCODED_IDS=$(echo "$XML_FILES" | xargs grep -c 'ref="[0-9]' 2>/dev/null | awk -F: '{sum+=$2} END{print sum+0}')
        if [ "$HARDCODED_IDS" -gt 0 ]
        then
            WARNINGS+=("$HARDCODED_IDS hardcoded ID reference(s) in XML - use named refs instead")
        fi
    fi

    # Ensure score is between 0-10
    [ "$SCORE" -lt 0 ] && SCORE=0
    [ "$SCORE" -gt 10 ] && SCORE=10

    # Return results
    echo "MODULE:$MODULE_NAME"
    echo "SCORE:$SCORE"

    local ISSUE
    for ISSUE in "${ISSUES[@]}"
    do
        echo "ISSUE:$ISSUE"
    done

    local WARNING
    for WARNING in "${WARNINGS[@]}"
    do
        echo "WARNING:$WARNING"
    done

}

##############################################################################
# Quality check menu - check all modules in project
##############################################################################

module_quality_menu()
{

    show_header

    echo "Module Quality Checker"
    echo -e "${DIM}Checks modules for common issues and gives a quality score${NC}"

    separator
    echo

    if [ -z "$PROJECT_PATH" ] || [ ! -d "$PROJECT_PATH" ]
    then
        print_error "No project selected."
        pause
        return
    fi

    local ADDONS_DIR="$PROJECT_PATH/custom_addons"
    [ ! -d "$ADDONS_DIR" ] && ADDONS_DIR="$PROJECT_PATH"

    local MODULES=()
    local m
    for m in "$ADDONS_DIR"/*
    do
        if [ -d "$m" ] && { [ -f "$m/__manifest__.py" ] || [ -f "$m/__openerp__.py" ]; }
        then
            MODULES+=("$m")
        fi
    done

    if [ ${#MODULES[@]} -eq 0 ]
    then
        print_warning "No modules found in this project."
        pause
        return
    fi

    echo -e "  ${WHITE}Project${NC} : $(basename "$PROJECT_PATH")"
    echo -e "  ${WHITE}Modules${NC} : ${#MODULES[@]}"
    echo
    separator
    echo

    local TOTAL_SCORE=0
    local MOD_DIR

    for MOD_DIR in "${MODULES[@]}"
    do
        local RESULT
        RESULT=$(check_module_quality "$MOD_DIR")

        local MOD_NAME
        MOD_NAME=$(echo "$RESULT" | grep "^MODULE:" | cut -d: -f2)
        local SCORE
        SCORE=$(echo "$RESULT" | grep "^SCORE:" | cut -d: -f2)

        TOTAL_SCORE=$((TOTAL_SCORE + SCORE))

        # Color based on score
        local SCORE_COLOR="$RED"
        if [ "$SCORE" -ge 8 ]
        then
            SCORE_COLOR="$GREEN"
        elif [ "$SCORE" -ge 5 ]
        then
            SCORE_COLOR="$YELLOW"
        fi

        printf "  ${BOLD}%-30s${NC} ${SCORE_COLOR}%s/10${NC}\n" "$MOD_NAME" "$SCORE"

        # Show issues
        echo "$RESULT" | grep "^ISSUE:" | while IFS= read -r line
        do
            echo -e "    ${RED}✘${NC} $(echo "$line" | cut -d: -f2-)"
        done

        echo "$RESULT" | grep "^WARNING:" | while IFS= read -r line
        do
            echo -e "    ${YELLOW}!${NC} $(echo "$line" | cut -d: -f2-)"
        done

        if ! echo "$RESULT" | grep -q "^ISSUE:\|^WARNING:"
        then
            echo -e "    ${GREEN}✔ No issues found${NC}"
        fi

        echo
    done

    # Summary
    separator
    echo

    local AVG_SCORE=$((TOTAL_SCORE / ${#MODULES[@]}))
    local AVG_COLOR="$RED"
    [ "$AVG_SCORE" -ge 8 ] && AVG_COLOR="$GREEN"
    [ "$AVG_SCORE" -ge 5 ] && [ "$AVG_SCORE" -lt 8 ] && AVG_COLOR="$YELLOW"

    echo -e "  ${WHITE}${BOLD}Average Quality Score${NC}: ${AVG_COLOR}${BOLD}${AVG_SCORE}/10${NC}"
    echo

    if [ "$AVG_SCORE" -ge 8 ]
    then
        print_success "  Great quality! Your modules follow Odoo best practices."
    elif [ "$AVG_SCORE" -ge 5 ]
    then
        print_warning "  Good start, but there are areas for improvement."
    else
        print_error "  Several issues found. Review the suggestions above."
    fi

    echo
    pause

}
