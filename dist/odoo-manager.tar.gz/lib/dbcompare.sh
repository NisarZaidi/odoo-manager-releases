#!/bin/bash

##############################################################################
# dbcompare.sh
# DB Snapshot & Compare
# Take database schema snapshots and compare between versions
##############################################################################

dbcompare_dir()
{
    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}/dbcompare"
}

##############################################################################
# Take a database schema snapshot
##############################################################################

take_db_snapshot()
{

    show_header
    echo "Take Database Schema Snapshot"
    separator
    echo

    if ! command_exists psql
    then
        print_error "PostgreSQL client (psql) not found."
        pause
        return
    fi

    local DB_NAME="${1:-}"

    if [ -z "$DB_NAME" ]
    then
        # Auto-detect from config
        if [ -f "$CONFIG_FILE" ]
        then
            DB_NAME=$(grep "^db_name" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
        fi

        if [ -n "$DB_NAME" ]
        then
            echo -e "  ${WHITE}Detected DB${NC}: $DB_NAME"
            echo
            if ! confirm "Use this database?"
            then
                DB_NAME=""
            fi
        fi

        if [ -z "$DB_NAME" ]
        then
            read -r -p "Database name: " DB_NAME
        fi
    fi

    if [ -z "$DB_NAME" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    # Verify database exists
    if ! psql -lqt 2>/dev/null | awk -F'|' '{print $1}' | grep -qw "$DB_NAME"
    then
        print_error "Database '$DB_NAME' not found."
        pause
        return
    fi

    # Create snapshot
    local SNAP_DIR
    SNAP_DIR="$(dbcompare_dir)/$DB_NAME"
    mkdir -p "$SNAP_DIR"

    local TIMESTAMP
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    local SNAP_FILE="$SNAP_DIR/schema_${TIMESTAMP}.sql"

    print_info "Taking schema snapshot of '$DB_NAME'..."

    # Dump schema only (table structures, indexes, constraints)
    pg_dump -s --no-owner --no-privileges "$DB_NAME" > "$SNAP_FILE" 2>/dev/null

    if [ $? -eq 0 ] && [ -f "$SNAP_FILE" ]
    then
        local SIZE
        SIZE=$(du -h "$SNAP_FILE" | cut -f1)

        # Also save table list
        psql -d "$DB_NAME" -t -c "
            SELECT tablename FROM pg_tables
            WHERE schemaname = 'public'
            ORDER BY tablename;
        " 2>/dev/null | xargs > "$SNAP_DIR/tables_${TIMESTAMP}.txt"

        local TABLE_COUNT
        TABLE_COUNT=$(wc -l < "$SNAP_DIR/tables_${TIMESTAMP}.txt" | tr -d ' ')

        echo
        print_success "Schema snapshot saved."
        echo -e "  ${WHITE}File${NC}    : schema_${TIMESTAMP}.sql ($SIZE)"
        echo -e "  ${WHITE}Tables${NC}  : $TABLE_COUNT"
        echo -e "  ${WHITE}Location${NC}: $SNAP_DIR"
    else
        print_error "Failed to take snapshot."
    fi

    pause

}

##############################################################################
# Compare two snapshots
##############################################################################

compare_db_snapshots()
{

    show_header
    echo "Compare Database Snapshots"
    separator
    echo

    local SNAP_DIR
    SNAP_DIR="$(dbcompare_dir)"

    if [ ! -d "$SNAP_DIR" ]
    then
        print_warning "No snapshots saved. Take a snapshot first."
        pause
        return
    fi

    # Find all snapshot files
    local SNAP_FILES=()
    local SNAP_FILE

    while IFS= read -r -d '' SNAP_FILE
    do
        SNAP_FILES+=("$SNAP_FILE")
    done < <(find "$SNAP_DIR" -name "schema_*.sql" -print0 2>/dev/null | sort -z)

    if [ ${#SNAP_FILES[@]} -lt 2 ]
    then
        print_warning "Need at least 2 snapshots to compare. Take more snapshots first."
        pause
        return
    fi

    echo "Available snapshots:"
    echo

    local COUNT=1
    for SNAP_FILE in "${SNAP_FILES[@]}"
    do
        local DB_DIR
        DB_DIR=$(basename "$(dirname "$SNAP_FILE")")
        local FNAME
        FNAME=$(basename "$SNAP_FILE")
        local FDATE
        FDATE=$(echo "$FNAME" | sed 's/schema_//;s/\.sql//' | sed 's/_/ /;s/\([0-9]\{4\}\)\([0-9]\{2\}\)\([0-9]\{2\}\)/\1-\2-\3/')

        printf "  ${GREEN}%s${NC}) %-20s %s\n" "$COUNT" "$DB_DIR" "$FDATE"
        COUNT=$((COUNT + 1))
    done

    echo

    read -r -p "First snapshot (number): " FIRST
    read -r -p "Second snapshot (number): " SECOND

    if ! [[ "$FIRST" =~ ^[0-9]+$ ]] || ! [[ "$SECOND" =~ ^[0-9]+$ ]]
    then
        invalid_option
        pause
        return
    fi

    if [ "$FIRST" -lt 1 ] || [ "$FIRST" -gt ${#SNAP_FILES[@]} ] || [ "$SECOND" -lt 1 ] || [ "$SECOND" -gt ${#SNAP_FILES[@]} ]
    then
        invalid_option
        pause
        return
    fi

    local FILE1="${SNAP_FILES[$((FIRST - 1))]}"
    local FILE2="${SNAP_FILES[$((SECOND - 1))]}"

    echo
    print_info "Comparing snapshots..."
    echo

    # Compare table lists
    local DIR1
    DIR1=$(dirname "$FILE1")
    local DIR2
    DIR2=$(dirname "$FILE2")
    local TBL1
    TBL1=$(ls "$DIR1"/tables_*.txt 2>/dev/null | tail -1)
    local TBL2
    TBL2=$(ls "$DIR2"/tables_*.txt 2>/dev/null | tail -1)

    if [ -f "$TBL1" ] && [ -f "$TBL2" ]
    then
        local ONLY_IN_1
        ONLY_IN_1=$(comm -23 <(sort "$TBL1") <(sort "$TBL2"))
        local ONLY_IN_2
        ONLY_IN_2=$(comm -13 <(sort "$TBL1") <(sort "$TBL2"))

        if [ -n "$ONLY_IN_1" ]
        then
            echo -e "  ${RED}Tables only in snapshot 1${NC}:"
            echo "$ONLY_IN_1" | while read -r tbl
            do
                echo -e "    ${RED}- $tbl${NC}"
            done
            echo
        fi

        if [ -n "$ONLY_IN_2" ]
        then
            echo -e "  ${GREEN}Tables only in snapshot 2 (new)${NC}:"
            echo "$ONLY_IN_2" | while read -r tbl
            do
                echo -e "    ${GREEN}+ $tbl${NC}"
            done
            echo
        fi

        if [ -z "$ONLY_IN_1" ] && [ -z "$ONLY_IN_2" ]
        then
            print_success "  Same tables in both snapshots."
        fi
    fi

    echo
    separator
    echo

    # Schema diff
    local DIFF_LINES
    DIFF_LINES=$(diff "$FILE1" "$FILE2" | wc -l | tr -d ' ')

    if [ "$DIFF_LINES" -eq 0 ]
    then
        print_success "Schemas are identical."
    else
        echo -e "  ${YELLOW}$DIFF_LINES schema differences found.${NC}"
        echo

        if confirm "Show detailed diff? (may be long)"
        then
            echo
            diff --color=auto "$FILE1" "$FILE2" | head -200
            echo
            if [ "$DIFF_LINES" -gt 200 ]
            then
                echo -e "  ${DIM}... (showing first 200 lines)${NC}"
            fi
        fi
    fi

    echo
    pause

}

##############################################################################
# List all snapshots
##############################################################################

list_db_snapshots()
{

    local SNAP_DIR
    SNAP_DIR="$(dbcompare_dir)"

    if [ ! -d "$SNAP_DIR" ] || [ -z "$(find "$SNAP_DIR" -name "schema_*.sql" 2>/dev/null)" ]
    then
        echo -e "  ${DIM}No snapshots saved.${NC}"
        return
    fi

    local SNAP_FILE
    while IFS= read -r -d '' SNAP_FILE
    do
        local DB_DIR
        DB_DIR=$(basename "$(dirname "$SNAP_FILE")")
        local FNAME
        FNAME=$(basename "$SNAP_FILE" .sql)
        local FSIZE
        FSIZE=$(du -h "$SNAP_FILE" | cut -f1)

        echo -e "  ${GREEN}$DB_DIR${NC} - $FNAME ($FSIZE)"
    done < <(find "$SNAP_DIR" -name "schema_*.sql" -print0 2>/dev/null | sort -z)

}

##############################################################################
# DB Compare menu
##############################################################################

dbcompare_menu()
{

    while true
    do

        show_header

        echo "DB Snapshot & Compare"
        echo -e "${DIM}Take database schema snapshots and compare between versions${NC}"

        separator
        echo

        list_db_snapshots

        echo
        separator
        echo

        menu_item "S" "Take Schema Snapshot"
        menu_item "C" "Compare Snapshots"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            S|s) take_db_snapshot ;;
            C|c) compare_db_snapshots ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}
