#!/bin/bash

##############################################################################
# project.sh
# Project Management
##############################################################################

PROJECTS=()

##############################################################################
# Detect Projects
##############################################################################

detect_projects()
{

    PROJECTS=()

    local PROJECTS_DIR="$ODOO_PATH/projects"

    if [ ! -d "$PROJECTS_DIR" ]
    then
        mkdir -p "$PROJECTS_DIR"
    fi

    for project in "$PROJECTS_DIR"/*
    do

        if [ -d "$project" ]
        then
            PROJECTS+=("$project")
        fi

    done

    # Legacy workspaces stored modules directly in custom_addons/
    # instead of per-project folders under projects/. Expose that folder
    # as a selectable project so older workspaces remain usable.
    local LEGACY_DIR="$ODOO_PATH/custom_addons"

    if type directory_has_odoo_modules >/dev/null 2>&1 && directory_has_odoo_modules "$LEGACY_DIR"
    then
        PROJECTS+=("$LEGACY_DIR")
    fi

}

sort_projects_for_menu()
{

    ensure_state_storage

    local SORTED=()
    local KEY
    local PROJECT
    local WS_NAME
    WS_NAME=$(basename "$ODOO_PATH")

    while IFS= read -r KEY
    do

        [ -n "$KEY" ] || continue

        for PROJECT in "${PROJECTS[@]}"
        do

            if [ "${WS_NAME}|$(basename "$PROJECT")" = "$KEY" ]
            then
                SORTED+=("$PROJECT")
            fi

        done

    done < <(state_read_lines "$(state_file favorite_projects)")

    while IFS= read -r KEY
    do

        [ -n "$KEY" ] || continue

        for PROJECT in "${PROJECTS[@]}"
        do

            if [ "${WS_NAME}|$(basename "$PROJECT")" = "$KEY" ]
            then
                local EXISTS=0
                local ADDED

                for ADDED in "${SORTED[@]}"
                do
                    [ "$ADDED" = "$PROJECT" ] && EXISTS=1
                done

                [ "$EXISTS" -eq 0 ] && SORTED+=("$PROJECT")
            fi

        done

    done < <(state_read_lines "$(state_file recent_projects)")

    for PROJECT in "${PROJECTS[@]}"
    do

        local EXISTS=0
        local ADDED

        for ADDED in "${SORTED[@]}"
        do
            [ "$ADDED" = "$PROJECT" ] && EXISTS=1
        done

        [ "$EXISTS" -eq 0 ] && SORTED+=("$PROJECT")

    done

    PROJECTS=("${SORTED[@]}")

}

##############################################################################
# Select Project
##############################################################################

select_project()
{

    while true
    do

        detect_projects
        sort_projects_for_menu

        show_project_menu

        prompt_read CHOICE "Select Project: "


        # Quit
        if [[ "$CHOICE" == "q" || "$CHOICE" == "Q" ]]
        then
            quit_manager
        fi


        # Back
        if [[ "$CHOICE" == "b" || "$CHOICE" == "B" ]]
        then
            change_workspace
            return
        fi


        # Refresh
        if [[ "$CHOICE" == "r" || "$CHOICE" == "R" ]]
        then
            continue
        fi


        # Project Generator
        if [[ "$CHOICE" == "n" || "$CHOICE" == "N" ]]
        then
            project_generator
            continue
        fi


        # Time Tracker
        if [[ "$CHOICE" == "t" || "$CHOICE" == "T" ]]
        then
            timetrack_menu
            continue
        fi


        # Project Metadata
        if [[ "$CHOICE" == "d" || "$CHOICE" == "D" ]]
        then
            view_all_metadata
            continue
        fi


        # Team Sync
        if [[ "$CHOICE" == "s" || "$CHOICE" == "S" ]]
        then
            if [ -n "$ODOO_PATH" ]
            then
                export_team_config
            fi
            continue
        fi



        # Empty Projects check
        if [ ${#PROJECTS[@]} -eq 0 ]
        then

            show_header

            echo
            print_warning "No projects found."
            echo

            echo "Projects Directory"
            echo "$ODOO_PATH/projects"
            echo

            if [ -d "$ODOO_PATH/custom_addons" ]
            then
                echo "Legacy Addons Directory"
                echo "$ODOO_PATH/custom_addons"
                echo
            fi

            echo "Create a project inside the above directory."
            echo

            pause

            change_workspace

            return

        fi



        # Number validation
        if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]
        then
            invalid_option
            continue
        fi



        INDEX=$((CHOICE-1))


        if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#PROJECTS[@]}" ]
        then
            invalid_option
            continue
        fi



        PROJECT_PATH="${PROJECTS[$INDEX]}"
        PROJECT_NAME=$(basename "$PROJECT_PATH")


        export PROJECT_PATH
        export PROJECT_NAME

        record_recent_project "$ODOO_PATH" "$PROJECT_PATH"


        validate_project

        main_menu

        return


    done

}

##############################################################################
# Validate Project
##############################################################################

validate_project()
{

    if [ ! -d "$PROJECT_PATH" ]
    then
        die "Project not found."
    fi

}

##############################################################################
# Favorites
##############################################################################

toggle_workspace_favorite_screen()
{

    if toggle_workspace_favorite "$ODOO_PATH"
    then
        print_success "Workspace '$(basename "$ODOO_PATH")' added to favorites."
    else
        print_warning "Workspace '$(basename "$ODOO_PATH")' removed from favorites."
    fi

    pause

}

toggle_project_favorite_screen()
{

    if toggle_project_favorite "$ODOO_PATH" "$PROJECT_PATH"
    then
        print_success "Project '$PROJECT_NAME' added to favorites."
    else
        print_warning "Project '$PROJECT_NAME' removed from favorites."
    fi

    pause

}

##############################################################################
# Shell Shortcuts Menu
#
# Quick access to the most common shells developers need:
#   - Odoo interactive shell
#   - psql (PostgreSQL shell)
#   - Python virtual environment shell
##############################################################################

shell_shortcuts_menu()
{

    while true
    do

        show_header

        echo "Shell Shortcuts"
        echo "Workspace : $(basename "$ODOO_PATH")"
        echo "Project   : $PROJECT_NAME"

        separator
        echo

        menu_section "Shells"
        menu_item "1" "Odoo Shell (python3 odoo-bin shell)"
        menu_item "2" "psql Shell (PostgreSQL)"
        menu_item "3" "Python Venv Shell (source env/bin/activate)"
        menu_item "4" "Regular Bash Shell (in project dir)"
        echo

        separator
        echo
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in

            1)
                open_odoo_shell
                ;;

            2)
                if ! command_exists psql
                then
                    print_warning "psql is not installed."
                    pause
                    continue
                fi

                local DB_LIST
                DB_LIST=$(psql -lqt 2>/dev/null | awk -F'|' 'NR>1 && $1 !~ /^template/ && $1 ~ /^[a-zA-Z]/ {gsub(/^ +| +$/,"",$1); print $1}')

                if [ -z "$DB_LIST" ]
                then
                    print_warning "No databases found."
                    pause
                    continue
                fi

                echo
                echo "Available databases:"
                echo "$DB_LIST" | sed 's/^/  /'
                echo

                read -r -p "Database name: " SHELL_DB

                if [ -n "$SHELL_DB" ]
                then
                    psql "$SHELL_DB"
                else
                    print_info "Cancelled."
                fi
                ;;

            3)
                if [ -f "$ODOO_PATH/env/bin/activate" ]
                then
                    echo "Entering Python venv shell. Type 'deactivate' or 'exit' to return."
                    echo
                    bash --rcfile <(echo "source '$ODOO_PATH/env/bin/activate'; PS1='(venv) \u@\h:\w\$ '")
                else
                    print_warning "Virtual environment not found at $ODOO_PATH/env"
                    pause
                fi
                ;;

            4)
                local SHELL_DIR="${PROJECT_PATH:-$ODOO_PATH}"
                echo "Opening shell in: $SHELL_DIR"
                echo "Type 'exit' to return to the manager."
                echo
                (cd "$SHELL_DIR" && bash)
                ;;

            B|b)
                return
                ;;

            *)
                invalid_option
                ;;

        esac

    done

}

##############################################################################
# Manifest Inspector
#
# Reads and displays the __manifest__.py of every module found in the
# current project: version, depends, data files, auto_install flag,
# and an overall installability summary.
##############################################################################

manifest_inspector_screen()
{

    show_header

    echo "Manifest Inspector"
    echo "Project : $PROJECT_NAME"
    echo "Path    : $PROJECT_PATH"

    separator
    echo

    local MODULE_COUNT=0
    local ISSUES=0
    local MANIFEST

    for MANIFEST in "$PROJECT_PATH"/*/__manifest__.py "$PROJECT_PATH"/*/__openerp__.py
    do

        [ -f "$MANIFEST" ] || continue

        local MODULE_DIR
        MODULE_DIR=$(dirname "$MANIFEST")
        local MODULE_NAME
        MODULE_NAME=$(basename "$MODULE_DIR")

        MODULE_COUNT=$((MODULE_COUNT+1))

        echo -e "${BOLD}${WHITE}$MODULE_NAME${NC}"
        echo "  File: $MANIFEST"

        # Parse manifest using Python (safe, handles all formats)
        python3 - "$MANIFEST" <<'PY' 2>&1 | sed 's/^/  /'
import ast
import sys

path = sys.argv[1]
try:
    with open(path, encoding="utf-8") as f:
        data = ast.literal_eval(f.read())
except Exception as e:
    print(f"ERROR: invalid manifest - {e}")
    sys.exit(1)

print(f"Name       : {data.get('name', 'N/A')}")
print(f"Version    : {data.get('version', 'N/A')}")
print(f"Summary    : {data.get('summary', data.get('description', '')[:80])}")
print(f"Category   : {data.get('category', 'N/A')}")
print(f"Author     : {data.get('author', 'N/A')}")
print(f"Website    : {data.get('website', 'N/A')}")
print(f"License    : {data.get('license', 'N/A')}")
print(f"Installable: {data.get('installable', True)}")
print(f"Auto Install: {data.get('auto_install', False)}")
print(f"Application: {data.get('application', False)}")

deps = data.get('depends', [])
print(f"Depends ({len(deps)}): {', '.join(deps) if deps else 'none'}")

data_files = data.get('data', [])
print(f"Data files ({len(data_files)}):")
for df in data_files:
    print(f"  - {df}")

demo_files = data.get('demo', [])
if demo_files:
    print(f"Demo files ({len(demo_files)}): {', '.join(demo_files)}")
PY

        [ $? -ne 0 ] && ISSUES=$((ISSUES+1))

        echo

    done

    separator
    echo

    if [ "$MODULE_COUNT" -eq 0 ]
    then
        print_warning "No modules found in this project."
    elif [ "$ISSUES" -eq 0 ]
    then
        print_success "$MODULE_COUNT module(s) inspected. All manifests are valid."
    else
        print_warning "$MODULE_COUNT module(s) inspected, $ISSUES with issues."
    fi

    pause

}

##############################################################################
# Interactive Log Search
#
# Grep the Odoo log by keyword or filter by log level
# (ERROR / WARNING / INFO), instead of just tailing.
##############################################################################

log_search_screen()
{

    show_header

    echo "Log Search"
    echo "Log File : $LOG_FILE"

    separator
    echo

    if [ ! -f "$LOG_FILE" ]
    then
        print_warning "Log file not found."
        pause
        return
    fi

    menu_section "Search Mode"
    menu_item "1" "Grep by keyword"
    menu_item "2" "Filter by level: ERROR only"
    menu_item "3" "Filter by level: WARNING + ERROR"
    menu_item "4" "Show last N lines"
    menu_item "5" "Find last traceback / exception"
    echo
    menu_item "B" "Back"
    echo

    prompt_read CHOICE "Select Option: "

    case "$CHOICE" in

        1)
            echo
            read -r -p "Keyword: " KEYWORD

            if [ -z "$KEYWORD" ]
            then
                print_warning "Empty keyword."
                pause
                return
            fi

            echo
            grep -n --color=always -i "$KEYWORD" "$LOG_FILE" | tail -n 100
            echo
            echo "Showing last 100 matches for '$KEYWORD'."
            ;;

        2)
            echo
            grep -n --color=always -E "ERROR|CRITICAL" "$LOG_FILE" | tail -n 100
            echo
            echo "Last 100 ERROR/CRITICAL entries."
            ;;

        3)
            echo
            grep -n --color=always -E "WARNING|ERROR|CRITICAL" "$LOG_FILE" | tail -n 100
            echo
            echo "Last 100 WARNING/ERROR/CRITICAL entries."
            ;;

        4)
            echo
            read -r -p "How many lines? [50]: " N_LINES
            N_LINES="${N_LINES:-50}"
            echo
            tail -n "$N_LINES" "$LOG_FILE"
            ;;

        5)
            echo
            echo "Last traceback/exception:"
            echo
            grep -n -B2 -A15 --color=always "Traceback\|Exception\|Error:" "$LOG_FILE" | tail -n 60
            ;;

        B|b)
            return
            ;;

        *)
            invalid_option
            ;;

    esac

    pause

}

##############################################################################
# One-Click DB Clone + Run
#
# Duplicates an existing database and immediately starts Odoo pointing
# to the cloned DB — perfect for testing or demo environments.
##############################################################################

clone_and_run_screen()
{

    show_header

    echo "Clone Database & Run Odoo"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    if ! command_exists createdb
    then
        print_warning "createdb command not found."
        pause
        return
    fi

    local SOURCE_DB
    SOURCE_DB="$(select_database)"

    if [ -z "$SOURCE_DB" ]
    then
        print_warning "Source database required."
        pause
        return
    fi

    local DEFAULT_NAME="${SOURCE_DB}_clone_$(date +%m%d_%H%M)"

    read -r -p "New Database Name [$DEFAULT_NAME]: " NEW_DB
    NEW_DB="${NEW_DB:-$DEFAULT_NAME}"

    echo
    print_info "Cloning '$SOURCE_DB' → '$NEW_DB'..."
    echo

    if ! createdb -T "$SOURCE_DB" "$NEW_DB"
    then
        print_error "Clone failed. Make sure '$SOURCE_DB' has no active connections."
        pause
        return
    fi

    print_success "Database cloned as '$NEW_DB'."
    echo

    if confirm "Start Odoo on this new database now?"
    then

        validate_configuration

        if is_odoo_running
        then
            print_warning "Odoo is already running. Stop it first to restart on the new DB."
        else

            source "$ODOO_PATH/env/bin/activate"
            build_addons_path

            cd "$ODOO_PATH/odoo" || {
                print_error "Unable to open Odoo directory."
                deactivate
                pause
                return
            }

            local CHECK_PORT
            CHECK_PORT="$(get_configured_port)"

            nohup setsid python3 odoo-bin \
                 -c "$CONFIG_FILE" \
                 --addons-path="$ADDONS_PATH" \
                 -d "$NEW_DB" \
                 >>"$LOG_FILE" 2>&1 \
                 </dev/null &

            ODOO_PID=$!
            disown "$ODOO_PID" 2>/dev/null

            echo "$ODOO_PID" > "$(get_pid_file)"

            deactivate

            print_success "Odoo started on database '$NEW_DB' (PID: $ODOO_PID, port: $CHECK_PORT)."

            open_odoo_browser "$CHECK_PORT"
        fi

    fi

    pause

}

##############################################################################
# Workspace Notes Screen
##############################################################################

workspace_notes_screen()
{

    show_header

    echo "Workspace Notes"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    local CURRENT_NOTE
    CURRENT_NOTE=$(read_workspace_note "$ODOO_PATH")

    if [ -n "$CURRENT_NOTE" ]
    then
        echo -e "${WHITE}Current Notes:${NC}"
        echo "$CURRENT_NOTE"
    else
        echo -e "${DIM}No notes saved yet.${NC}"
    fi

    echo
    separator
    echo

    menu_item "1" "Edit / Save Notes"
    menu_item "2" "Clear Notes"
    echo
    menu_item "B" "Back"
    echo

    prompt_read CHOICE "Select Option: "

    case "$CHOICE" in

        1)
            echo
            echo "Enter your notes (press ENTER twice to finish, or Ctrl+D):"
            echo

            local NOTE_INPUT=""
            local LINE
            while IFS= read -r LINE
            do
                NOTE_INPUT="${NOTE_INPUT}${LINE}
"
            done

            if [ -n "$NOTE_INPUT" ]
            then
                save_workspace_note "$ODOO_PATH" "$NOTE_INPUT"
                print_success "Notes saved."
            else
                print_info "Empty input - notes unchanged."
            fi
            ;;

        2)
            if confirm "Delete all workspace notes?"
            then
                delete_workspace_note "$ODOO_PATH"
                print_success "Notes cleared."
            fi
            ;;

        B|b)
            return
            ;;

        *)
            invalid_option
            ;;

    esac

    pause

}

##############################################################################
# Project Notes Screen
##############################################################################

project_notes_screen()
{

    show_header

    echo "Project Notes"
    echo "Project : $PROJECT_NAME"

    separator
    echo

    local CURRENT_NOTE
    CURRENT_NOTE=$(read_project_note "$ODOO_PATH" "$PROJECT_PATH")

    if [ -n "$CURRENT_NOTE" ]
    then
        echo -e "${WHITE}Current Notes:${NC}"
        echo "$CURRENT_NOTE"
    else
        echo -e "${DIM}No notes saved yet.${NC}"
    fi

    echo
    separator
    echo

    menu_item "1" "Edit / Save Notes"
    menu_item "2" "Clear Notes"
    echo
    menu_item "B" "Back"
    echo

    prompt_read CHOICE "Select Option: "

    case "$CHOICE" in

        1)
            echo
            echo "Enter your notes (press ENTER twice to finish, or Ctrl+D):"
            echo

            local NOTE_INPUT=""
            local LINE
            while IFS= read -r LINE
            do
                NOTE_INPUT="${NOTE_INPUT}${LINE}
"
            done

            if [ -n "$NOTE_INPUT" ]
            then
                save_project_note "$ODOO_PATH" "$PROJECT_PATH" "$NOTE_INPUT"
                print_success "Notes saved."
            else
                print_info "Empty input - notes unchanged."
            fi
            ;;

        2)
            if confirm "Delete all project notes?"
            then
                delete_project_note "$ODOO_PATH" "$PROJECT_PATH"
                print_success "Notes cleared."
            fi
            ;;

        B|b)
            return
            ;;

        *)
            invalid_option
            ;;

    esac

    pause

}

##############################################################################
# Environment Export / Import
#
# Exports workspace metadata (odoo.conf, state files, favorites, notes)
# as a zip archive that can be restored on another machine.
##############################################################################

environment_export_screen()
{

    show_header

    echo "Environment Export"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    local EXPORT_DIR="$ODOO_PATH/support"
    mkdir -p "$EXPORT_DIR"

    local STAGE_DIR
    STAGE_DIR=$(mktemp -d)

    local TIMESTAMP
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)

    # odoo.conf
    [ -f "$CONFIG_FILE" ] && cp "$CONFIG_FILE" "$STAGE_DIR/odoo.conf"

    # .env (secrets)
    [ -f "$ODOO_PATH/.env" ] && cp "$ODOO_PATH/.env" "$STAGE_DIR/workspace.env"

    # State files
    if [ -d "$(state_dir)" ]
    then
        mkdir -p "$STAGE_DIR/state"
        cp "$(state_file recent_workspaces)" "$STAGE_DIR/state/" 2>/dev/null || true
        cp "$(state_file recent_projects)" "$STAGE_DIR/state/" 2>/dev/null || true
        cp "$(state_file favorite_workspaces)" "$STAGE_DIR/state/" 2>/dev/null || true
        cp "$(state_file favorite_projects)" "$STAGE_DIR/state/" 2>/dev/null || true
    fi

    # Notes
    if [ -d "$(notes_dir)" ]
    then
        mkdir -p "$STAGE_DIR/notes"
        cp "$(notes_dir)"/* "$STAGE_DIR/notes/" 2>/dev/null || true
    fi

    # Doctor JSON
    if type workspace_doctor_json_report >/dev/null 2>&1
    then
        workspace_doctor_json_report "$(basename "$ODOO_PATH")" > "$STAGE_DIR/doctor.json"
    fi

    # Workspace metadata
    {
        echo "workspace=$(basename "$ODOO_PATH")"
        echo "exported_at=$(date '+%Y-%m-%d %H:%M:%S')"
        echo "version=$VERSION"
        echo "hostname=$(hostname 2>/dev/null)"
    } > "$STAGE_DIR/env_meta.txt"

    local OUTPUT="$EXPORT_DIR/$(basename "$ODOO_PATH")_env_${TIMESTAMP}.tar.gz"

    if tar -czf "$OUTPUT" -C "$STAGE_DIR" .
    then
        print_success "Environment exported:"
        echo "  $OUTPUT"
    else
        print_error "Export failed."
        rm -f "$OUTPUT"
    fi

    rm -rf "$STAGE_DIR"

    pause

}

environment_import_screen()
{

    show_header

    echo "Environment Import"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    local IMPORT_DIR="$ODOO_PATH/support"

    if [ ! -d "$IMPORT_DIR" ]
    then
        print_warning "No export files found in $IMPORT_DIR"
        pause
        return
    fi

    local ARCHIVES=()
    for f in "$IMPORT_DIR"/*_env_*.tar.gz
    do
        [ -f "$f" ] && ARCHIVES+=("$f")
    done

    if [ ${#ARCHIVES[@]} -eq 0 ]
    then
        print_warning "No environment archives found."
        pause
        return
    fi

    echo "Available Exports:"
    echo

    local COUNT=1
    for A in "${ARCHIVES[@]}"
    do
        menu_item "$COUNT" "$(basename "$A")"
        COUNT=$((COUNT+1))
    done

    echo
    menu_item "B" "Back"
    echo

    prompt_read CHOICE "Select Archive: "

    if [[ "$CHOICE" == "b" || "$CHOICE" == "B" ]]; then return; fi

    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]; then invalid_option; return; fi

    local INDEX=$((CHOICE-1))
    if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#ARCHIVES[@]}" ]; then invalid_option; return; fi

    local SELECTED="${ARCHIVES[$INDEX]}"
    local STAGE_DIR
    STAGE_DIR=$(mktemp -d)

    if ! tar -xzf "$SELECTED" -C "$STAGE_DIR"
    then
        print_error "Failed to extract archive."
        rm -rf "$STAGE_DIR"
        pause
        return
    fi

    echo
    print_warning "This will import config and state from the selected archive."
    echo

    # Restore odoo.conf
    if [ -f "$STAGE_DIR/odoo.conf" ] && confirm "Restore odoo.conf?"
    then
        cp "$STAGE_DIR/odoo.conf" "$ODOO_PATH/odoo/debian/odoo.conf"
        print_success "odoo.conf restored."
    fi

    # Restore .env
    if [ -f "$STAGE_DIR/workspace.env" ] && confirm "Restore .env secrets?"
    then
        cp "$STAGE_DIR/workspace.env" "$ODOO_PATH/.env"
        print_success ".env restored."
    fi

    # Restore state
    if [ -d "$STAGE_DIR/state" ] && confirm "Restore state (favorites, recents)?"
    then
        mkdir -p "$(state_dir)"
        cp "$STAGE_DIR/state/"* "$(state_dir)/" 2>/dev/null || true
        print_success "State restored."
    fi

    # Restore notes
    if [ -d "$STAGE_DIR/notes" ] && confirm "Restore workspace/project notes?"
    then
        mkdir -p "$(notes_dir)"
        cp "$STAGE_DIR/notes/"* "$(notes_dir)/" 2>/dev/null || true
        print_success "Notes restored."
    fi

    rm -rf "$STAGE_DIR"

    pause

}

##############################################################################
# System Resource Warnings
#
# Checks disk space, memory, and port conflicts and shows warnings
# if any resource is running low.
##############################################################################

system_resource_check_screen()
{

    show_header

    echo "System Resource Check"

    separator
    echo

    local ISSUES=0

    # Disk space
    if command_exists df
    then
        local DISK_USAGE
        DISK_USAGE=$(df "$ODOO_PATH" 2>/dev/null | awk 'NR==2 {print $5}' | tr -d '%')

        if [ -n "$DISK_USAGE" ]
        then
            if [ "$DISK_USAGE" -ge 90 ]
            then
                print_error "✘ DISK CRITICAL: ${DISK_USAGE}% used on $(df "$ODOO_PATH" | awk 'NR==2 {print $6}')"
                ISSUES=$((ISSUES+1))
            elif [ "$DISK_USAGE" -ge 80 ]
            then
                print_warning "⚠ DISK WARNING: ${DISK_USAGE}% used"
                ISSUES=$((ISSUES+1))
            else
                print_success "✔ Disk: ${DISK_USAGE}% used"
            fi
        fi
    fi

    echo

    # Memory
    if command_exists free
    then
        local TOTAL_MEM USED_MEM AVAIL_MEM
        TOTAL_MEM=$(free -m | awk '/^Mem:/{print $2}')
        USED_MEM=$(free -m | awk '/^Mem:/{print $3}')
        AVAIL_MEM=$(free -m | awk '/^Mem:/{print $7}')

        if [ -n "$TOTAL_MEM" ] && [ "$TOTAL_MEM" -gt 0 ]
        then
            local MEM_PCT=$((USED_MEM * 100 / TOTAL_MEM))

            if [ "$MEM_PCT" -ge 90 ]
            then
                print_error "✘ MEMORY CRITICAL: ${MEM_PCT}% used (${AVAIL_MEM}MB available)"
                ISSUES=$((ISSUES+1))
            elif [ "$MEM_PCT" -ge 80 ]
            then
                print_warning "⚠ MEMORY WARNING: ${MEM_PCT}% used (${AVAIL_MEM}MB available)"
                ISSUES=$((ISSUES+1))
            else
                print_success "✔ Memory: ${MEM_PCT}% used (${AVAIL_MEM}MB available)"
            fi
        fi
    fi

    echo

    # Port conflicts for current workspace
    if [ -f "$CONFIG_FILE" ]
    then
        local WS_PORT
        WS_PORT=$(grep "^http_port" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)

        if [ -n "$WS_PORT" ]
        then
            if type is_workspace_running >/dev/null 2>&1 && is_workspace_running "$ODOO_PATH" >/dev/null 2>&1
            then
                print_success "✔ Port $WS_PORT: in use by this workspace"
            elif type is_port_in_use >/dev/null 2>&1 && is_port_in_use "$WS_PORT"
            then
                print_error "✘ PORT CONFLICT: $WS_PORT is busy by another process"
                ISSUES=$((ISSUES+1))
            else
                print_success "✔ Port $WS_PORT: free"
            fi
        fi
    fi

    echo

    # Check all workspace ports
    if type detect_existing_workspaces >/dev/null 2>&1
    then
        echo -e "${WHITE}All Workspace Ports:${NC}"
        local WS
        for WS in "${WORKSPACES[@]}"
        do
            local WS_CONF="$WS/odoo/debian/odoo.conf"
            [ -f "$WS_CONF" ] || continue
            local WP
            WP=$(grep "^http_port" "$WS_CONF" 2>/dev/null | cut -d '=' -f2- | xargs)
            [ -z "$WP" ] && continue

            local WS_NAME
            WS_NAME=$(basename "$WS")

            if type is_workspace_running >/dev/null 2>&1 && is_workspace_running "$WS" >/dev/null 2>&1
            then
                echo -e "  ${GREEN}●${NC} $WS_NAME → port $WP ${GREEN}(running)${NC}"
            elif type is_port_in_use >/dev/null 2>&1 && is_port_in_use "$WP"
            then
                echo -e "  ${RED}✘${NC} $WS_NAME → port $WP ${RED}(conflict!)${NC}"
                ISSUES=$((ISSUES+1))
            else
                echo -e "  ${DIM}○${NC} $WS_NAME → port $WP ${DIM}(free)${NC}"
            fi
        done
    fi

    echo
    separator
    echo

    if [ "$ISSUES" -eq 0 ]
    then
        print_success "All system resources look healthy."
    else
        print_warning "$ISSUES resource issue(s) detected."
    fi

    pause

}

##############################################################################
# License Info Screen
##############################################################################

license_info_screen()
{

    show_header

    echo "License Information"

    separator
    echo

    local LICENSE_FILE="$ROOT_DIR/licenses/issued.tsv"
    local LICENSE_STATE
    LICENSE_STATE=$(state_file license_key 2>/dev/null || echo "")
    local ACTIVE_LICENSE_KEY=""

    if [ -n "$ODOO_MANAGER_LICENSE" ]
    then

        ACTIVE_LICENSE_KEY="$ODOO_MANAGER_LICENSE"
        print_success "License key is loaded."
        echo "  Source: environment variable ODOO_MANAGER_LICENSE"
        echo

        if type validate_license_key >/dev/null 2>&1
        then
            local CUSTOMER
            CUSTOMER=$(validate_license_key "$ODOO_MANAGER_LICENSE")

            if [ -n "$CUSTOMER" ]
            then
                print_success "✔ License is VALID."
                echo "  Issued to: $CUSTOMER"
            else
                print_error "✘ License verification FAILED."
            fi
        fi

    elif [ -f "$LICENSE_STATE" ]
    then

        local STORED_KEY
        STORED_KEY=$(cat "$LICENSE_STATE" 2>/dev/null)

        if [ -n "$STORED_KEY" ]
        then
            ACTIVE_LICENSE_KEY="$STORED_KEY"
            print_success "License key found in state file."
            echo

            if type validate_license_key >/dev/null 2>&1
            then
                local CUSTOMER
                CUSTOMER=$(validate_license_key "$STORED_KEY")

                if [ -n "$CUSTOMER" ]
                then
                    print_success "✔ License is VALID."
                    echo "  Issued to: $CUSTOMER"
                else
                    print_error "✘ License verification FAILED."
                fi
            fi
        else
            print_warning "No license key found."
        fi

    else

        print_warning "No license key detected."
        echo
        echo "  Set ODOO_MANAGER_LICENSE environment variable, or"
        echo "  run the license activation from the installer."

    fi

    # Only show issued licenses list to the admin (seller).
    # Admin is identified by having keys/private.pem (never shipped to customers).
    local IS_ADMIN=0
    if [ -f "$ROOT_DIR/keys/private.pem" ]
    then
        IS_ADMIN=1
    fi

    if [ -f "$LICENSE_FILE" ]
    then

        if [ "$IS_ADMIN" -eq 1 ]
        then

            echo
            echo -e "${WHITE}All Issued Licenses (admin view):${NC}"
            echo

            local TOTAL_LICENSES
            TOTAL_LICENSES=$(grep -c '.' "$LICENSE_FILE" 2>/dev/null || echo 0)
            echo -e "  Total: ${BOLD}${TOTAL_LICENSES}${NC}"
            echo

            # Header
            printf "  ${DIM}%-20s %-16s %-30s %s${NC}\n" "Date" "Name" "Contact" "Customer ID"
            printf "  ${DIM}%s${NC}\n" "$(printf '─%.0s' $(seq 1 80))"

            while IFS=$'\t' read -r L_DATE L_NAME L_CONTACT L_CID _L_KEY
            do
                [ -n "$L_DATE" ] || continue
                printf "  %-20s %-16s %-30s %s\n" "$L_DATE" "$L_NAME" "$L_CONTACT" "$L_CID"
            done < "$LICENSE_FILE"

        elif [ -n "$ACTIVE_LICENSE_KEY" ]
        then

            # Regular user - show only their own license entry
            local MY_ENTRY
            MY_ENTRY=$(grep -F "$ACTIVE_LICENSE_KEY" "$LICENSE_FILE" 2>/dev/null | head -n1)

            if [ -n "$MY_ENTRY" ]
            then
                echo
                echo -e "${WHITE}Your License Record:${NC}"
                echo

                local MY_DATE MY_NAME MY_CONTACT MY_CID
                MY_DATE=$(echo "$MY_ENTRY" | cut -f1)
                MY_NAME=$(echo "$MY_ENTRY" | cut -f2)
                MY_CONTACT=$(echo "$MY_ENTRY" | cut -f3)
                MY_CID=$(echo "$MY_ENTRY" | cut -f4)

                printf "  ${WHITE}%-16s${NC} : %s\n" "Issued On" "$MY_DATE"
                printf "  ${WHITE}%-16s${NC} : %s\n" "Name" "$MY_NAME"
                printf "  ${WHITE}%-16s${NC} : %s\n" "Contact" "$MY_CONTACT"
                printf "  ${WHITE}%-16s${NC} : %s\n" "Customer ID" "$MY_CID"
            fi

        fi

    fi

    echo
    echo "Manager Version : v$VERSION"
    echo "Install Root    : $ROOT_DIR"

    pause

}

##############################################################################
# Config Profiles
#
# Save/load workspace configuration presets for dev, staging, or
# production-like environments.
##############################################################################

CONFIG_PROFILES_DIR=""

config_profiles_dir()
{

    echo "$ODOO_PATH/config_profiles"

}

config_profiles_list()
{

    local DIR
    DIR=$(config_profiles_dir)

    [ -d "$DIR" ] || return 1

    local COUNT=0
    for f in "$DIR"/*.conf
    do
        [ -f "$f" ] && COUNT=$((COUNT+1))
    done

    [ "$COUNT" -gt 0 ]

}

config_profile_save_screen()
{

    show_header

    echo "Save Config Profile"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    read -r -p "Profile name (e.g. dev, staging, prod): " PROFILE_NAME

    if [ -z "$PROFILE_NAME" ] || ! [[ "$PROFILE_NAME" =~ ^[a-zA-Z0-9_-]+$ ]]
    then
        print_warning "Invalid profile name."
        pause
        return
    fi

    local DIR
    DIR=$(config_profiles_dir)
    mkdir -p "$DIR"

    if [ -f "$CONFIG_FILE" ]
    then
        cp "$CONFIG_FILE" "$DIR/${PROFILE_NAME}.conf"

        # Also save .env if present
        [ -f "$ODOO_PATH/.env" ] && cp "$ODOO_PATH/.env" "$DIR/${PROFILE_NAME}.env"

        print_success "Profile '$PROFILE_NAME' saved."
    else
        print_error "Config file not found."
    fi

    pause

}

config_profile_load_screen()
{

    show_header

    echo "Load Config Profile"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    local DIR
    DIR=$(config_profiles_dir)

    if [ ! -d "$DIR" ]
    then
        print_warning "No profiles saved yet."
        pause
        return
    fi

    local PROFILES=()
    for f in "$DIR"/*.conf
    do
        [ -f "$f" ] && PROFILES+=("$f")
    done

    if [ ${#PROFILES[@]} -eq 0 ]
    then
        print_warning "No profiles found."
        pause
        return
    fi

    echo "Available Profiles:"
    echo

    local COUNT=1
    for P in "${PROFILES[@]}"
    do
        local PNAME
        PNAME=$(basename "$P" .conf)
        menu_item "$COUNT" "$PNAME"
        COUNT=$((COUNT+1))
    done

    echo
    menu_item "B" "Back"
    echo

    prompt_read CHOICE "Select Profile: "

    if [[ "$CHOICE" == "b" || "$CHOICE" == "B" ]]; then return; fi
    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]; then invalid_option; return; fi

    local INDEX=$((CHOICE-1))
    if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#PROFILES[@]}" ]; then invalid_option; return; fi

    local SELECTED="${PROFILES[$INDEX]}"
    local PNAME
    PNAME=$(basename "$SELECTED" .conf)

    echo

    if confirm "Apply profile '$PNAME' to odoo.conf?"
    then

        # Backup current config first
        [ -f "$CONFIG_FILE" ] && cp "$CONFIG_FILE" "${CONFIG_FILE}.pre_profile_backup"

        cp "$SELECTED" "$CONFIG_FILE"

        # Restore .env if profile has one
        [ -f "$DIR/${PNAME}.env" ] && cp "$DIR/${PNAME}.env" "$ODOO_PATH/.env"

        print_success "Profile '$PNAME' applied."
        echo "Previous config backed up as $(basename "${CONFIG_FILE}").pre_profile_backup"
    else
        print_info "Cancelled."
    fi

    pause

}

config_profiles_menu()
{

    while true
    do

        show_header

        echo "Config Profiles"
        echo "Workspace : $(basename "$ODOO_PATH")"

        separator
        echo

        menu_item "1" "Save Current Config as Profile"
        menu_item "2" "Load a Profile"
        echo
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            1) config_profile_save_screen ;;
            2) config_profile_load_screen ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}

##############################################################################
# Dashboard Screen
#
# Unified overview showing all workspaces, their running status,
# ports, health indicators, and system resources at a glance.
##############################################################################

dashboard_screen()
{

    show_header

    echo -e "${BOLD}${WHITE}═══════════════════════════════════════════${NC}"
    echo -e "${BOLD}${WHITE}         DASHBOARD OVERVIEW${NC}"
    echo -e "${BOLD}${WHITE}═══════════════════════════════════════════${NC}"
    echo

    detect_existing_workspaces

    local RUNNING_COUNT=0
    local TOTAL_PROJECTS=0
    local TOTAL_MODULES=0

    for WS in "${WORKSPACES[@]}"
    do

        local WS_NAME
        WS_NAME=$(basename "$WS")

        local WS_CONF="$WS/odoo/debian/odoo.conf"
        local WS_PORT=""
        [ -f "$WS_CONF" ] && WS_PORT=$(grep "^http_port" "$WS_CONF" 2>/dev/null | cut -d '=' -f2- | xargs)

        local STATUS_DOT STATUS_TEXT
        if type is_workspace_running >/dev/null 2>&1 && is_workspace_running "$WS" >/dev/null 2>&1
        then
            STATUS_DOT="${GREEN}●${NC}"
            STATUS_TEXT="${GREEN}Running${NC}"
            RUNNING_COUNT=$((RUNNING_COUNT+1))
        else
            STATUS_DOT="${DIM}○${NC}"
            STATUS_TEXT="${DIM}Stopped${NC}"
        fi

        # Port badge
        local PORT_BADGE=""
        if [ -n "$WS_PORT" ]
        then
            if type is_port_in_use >/dev/null 2>&1 && is_port_in_use "$WS_PORT" && ! (type is_workspace_running >/dev/null 2>&1 && is_workspace_running "$WS" >/dev/null 2>&1)
            then
                PORT_BADGE=" ${RED}[port $WS_PORT - CONFLICT]${NC}"
            else
                PORT_BADGE=" ${CYAN}[port $WS_PORT]${NC}"
            fi
        fi

        # Project count
        local WS_PROJECTS=0
        if [ -d "$WS/projects" ]
        then
            WS_PROJECTS=$(find "$WS/projects" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')
        fi
        TOTAL_PROJECTS=$((TOTAL_PROJECTS + WS_PROJECTS))

        # Module count (enterprise + custom_addons + projects)
        local WS_MODULES=0
        if type count_odoo_modules_in_dir >/dev/null 2>&1
        then
            local EC PC
            EC=$(count_odoo_modules_in_dir "$WS/enterprise")
            PC=$(count_odoo_modules_in_dir "$WS/custom_addons")
            WS_MODULES=$((EC + PC))
        fi
        TOTAL_MODULES=$((TOTAL_MODULES + WS_MODULES))

        # Health badge
        local HEALTH_BADGE=""
        if [ -d "$WS/odoo/.git" ] && [ -f "$WS/env/bin/activate" ] && [ -f "$WS_CONF" ]
        then
            HEALTH_BADGE=" ${GREEN}✔ healthy${NC}"
        elif [ -f "$WS_CONF" ]
        then
            HEALTH_BADGE=" ${YELLOW}⚠ partial${NC}"
        else
            HEALTH_BADGE=" ${RED}✘ broken${NC}"
        fi

        # Favorite/recent
        local MARKERS=""
        if type is_workspace_favorite >/dev/null 2>&1 && is_workspace_favorite "$WS"
        then
            MARKERS=" ${YELLOW}★${NC}"
        fi

        printf "  %b ${BOLD}%-12s${NC}%b%b%b\n" "$STATUS_DOT" "$WS_NAME" "$MARKERS" "$PORT_BADGE" "$HEALTH_BADGE"
        echo -e "    ${DIM}Projects${NC}: $WS_PROJECTS  ${DIM}Modules${NC}: $WS_MODULES"
        echo

    done

    separator
    echo

    # Summary stats
    echo -e "${WHITE}Total Workspaces${NC}  : ${#WORKSPACES[@]}"
    echo -e "${WHITE}Running${NC}           : $RUNNING_COUNT"
    echo -e "${WHITE}Total Projects${NC}    : $TOTAL_PROJECTS"
    echo -e "${WHITE}Total Modules${NC}     : $TOTAL_MODULES"

    # PostgreSQL status
    echo
    if type check_database_connection >/dev/null 2>&1
    then
        check_database_connection
        case $? in
            0) echo -e "${WHITE}PostgreSQL${NC}        : ${GREEN}✔ Reachable${NC}" ;;
            1) echo -e "${WHITE}PostgreSQL${NC}        : ${YELLOW}⚠ Not reachable${NC}" ;;
            2) echo -e "${WHITE}PostgreSQL${NC}        : ${RED}✘ Client not found${NC}" ;;
        esac
    fi

    # Quick disk check
    if command_exists df
    then
        local DISK_PCT
        DISK_PCT=$(df "$WORKSPACE_ROOT" 2>/dev/null | awk 'NR==2 {print $5}' | tr -d '%')
        local DISK_AVAIL
        DISK_AVAIL=$(df -h "$WORKSPACE_ROOT" 2>/dev/null | awk 'NR==2 {print $4}')

        if [ -n "$DISK_PCT" ] && [ "$DISK_PCT" -ge 85 ]
        then
            echo -e "${WHITE}Disk${NC}              : ${RED}⚠ ${DISK_PCT}% used (${DISK_AVAIL} free)${NC}"
        else
            echo -e "${WHITE}Disk${NC}              : ${GREEN}✔ ${DISK_PCT:-?}% used (${DISK_AVAIL:-?} free)${NC}"
        fi
    fi

    echo

    pause

}

##############################################################################
# Main Menu
##############################################################################

main_menu()
{

    while true
    do

        show_main_menu

        prompt_read OPTION "Select Option: "

        case "$OPTION" in

            S|s)

                echo
                echo -e "  ${WHITE}1${NC}) Normal Start"
                echo -e "  ${WHITE}2${NC}) Start with Hot Reload (auto-restart on file changes)"
                echo
                prompt_read START_MODE "Select (1/2): "

                if [ "$START_MODE" = "2" ]
                then
                    if check_feature_access "watcher"; then
                        start_odoo_with_watch
                    fi
                else
                    start_odoo
                fi

                ;;

            R|r)

                restart_odoo
                ;;

            K|k)

                stop_odoo
                ;;

            L|l)

                view_logs
                ;;

            U|u)

                upgrade_module_menu
                ;;

            M|m)

                create_new_module
                ;;

            D|d)

                database_menu
                ;;

            O|o)

                update_odoo
                ;;

            H|h)

                workspace_doctor
                ;;

            E|e)

                export_support_bundle_screen
                ;;

            V|v)

                open_in_editor
                ;;

            G|g)

                project_git_menu
                ;;

            A|a)

                workspace_backup_menu
                ;;

            C|c)

                show_configuration
                ;;

            T|t)

                project_quality_checks_menu
                ;;

            X|x)

                shell_shortcuts_menu
                ;;

            Z|z)

                log_search_screen
                ;;

            I|i)

                manifest_inspector_screen
                ;;

            N|n)

                workspace_notes_screen
                ;;

            1)

                dashboard_screen
                ;;

            2)

                config_profiles_menu
                ;;

            3)

                system_resource_check_screen
                ;;

            4)

                license_info_screen
                ;;

            5)

                environment_export_screen
                ;;

            6)

                environment_import_screen
                ;;

            F|f)

                toggle_workspace_favorite_screen
                ;;

            J|j)

                toggle_project_favorite_screen
                ;;

            B|b)

                select_project
                return
                ;;

            Q|q)

                quit_manager
                ;;

            7)
                if check_feature_access "scaffold"; then
                    scaffold_advanced_module
                fi
                ;;

            8)
                if check_feature_access "deps"; then
                    show_dependency_graph
                fi
                ;;

            9)
                if check_feature_access "quality"; then
                    module_quality_menu
                fi
                ;;

            M|m)
                if check_feature_access "migration"; then
                    migration_menu
                fi
                ;;

            W|w)
                if check_feature_access "dbcompare"; then
                    dbcompare_menu
                fi
                ;;

            P|p)
                if check_feature_access "multitest"; then
                    multitest_menu
                fi
                ;;

            *)

                invalid_option
                ;;

        esac

    done

}

##############################################################################
# Refresh Projects
##############################################################################

refresh_projects()
{

    detect_projects

}

##############################################################################
# Create Project
##############################################################################

create_project()
{

    read -r -p "Project Name: " NAME

    if [ -z "$NAME" ]
    then
        return
    fi

    mkdir -p "$ODOO_PATH/projects/$NAME"

    print_success "Project created."

}

##############################################################################
# Project Generator
#
# A guided flow for creating a brand new project: validates the name,
# creates the folder under projects/, optionally initializes it as a
# git repository, and optionally scaffolds a first module right away
# (reuses the same odoo-bin scaffold logic as "Create New Module").
##############################################################################

project_generator()
{

    LAST_CREATED_PROJECT=""
    LAST_CREATED_MODULE=""
    export LAST_CREATED_PROJECT LAST_CREATED_MODULE

    show_header

    echo "Project Generator"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator

    echo
    read -r -p "New Project Name: " NEW_PROJECT

    if [ -z "$NEW_PROJECT" ]
    then
        print_warning "Project name cannot be empty."
        pause
        return
    fi

    if ! [[ "$NEW_PROJECT" =~ ^[a-zA-Z0-9_-]+$ ]]
    then
        print_warning "Use letters, numbers, underscores or hyphens only."
        pause
        return
    fi

    local NEW_PROJECT_DIR="$ODOO_PATH/projects/$NEW_PROJECT"

    if [ -d "$NEW_PROJECT_DIR" ]
    then
        print_warning "A project named '$NEW_PROJECT' already exists."
        pause
        return
    fi

    if ! mkdir -p "$NEW_PROJECT_DIR"
    then
        print_error "Failed to create project folder."
        pause
        return
    fi

    print_success "Project folder created."
    echo "  $NEW_PROJECT_DIR"
    echo

    if confirm "Initialize this project as a git repository?"
    then

        if git -C "$NEW_PROJECT_DIR" init -q
        then
            print_success "Git repository initialized."
        else
            print_warning "Could not initialize git repository."
        fi

        echo

    fi

    local FIRST_MODULE=""

    if confirm "Scaffold a first module now?"
    then

        read -r -p "Module Name: " FIRST_MODULE

        if [ -n "$FIRST_MODULE" ] && [[ "$FIRST_MODULE" =~ ^[a-z][a-z0-9_]*$ ]]
        then

            loading "Scaffolding module '$FIRST_MODULE'..."

            source "$ODOO_PATH/env/bin/activate"

            cd "$ODOO_PATH/odoo" || {
                print_error "Unable to open Odoo directory."
                deactivate
                FIRST_MODULE=""
            }

            if [ -n "$FIRST_MODULE" ]
            then

                python3 odoo-bin scaffold "$FIRST_MODULE" "$NEW_PROJECT_DIR"
                local SCAFFOLD_STATUS=$?

                deactivate

                # Safety net: some odoo-bin scaffold versions create the
                # module relative to the CURRENT directory instead of the
                # destination argument. If that happened, relocate it into
                # the project folder so it never ends up sitting outside
                # the project by mistake.
                if [ ! -d "$NEW_PROJECT_DIR/$FIRST_MODULE" ]
                then

                    local _CANDIDATE
                    for _CANDIDATE in \
                        "$ODOO_PATH/odoo/$FIRST_MODULE" \
                        "$ODOO_PATH/$FIRST_MODULE" \
                        "$ROOT_DIR/$FIRST_MODULE" \
                        "$PWD/$FIRST_MODULE"
                    do

                        if [ -d "$_CANDIDATE" ] && [ "$_CANDIDATE" != "$NEW_PROJECT_DIR/$FIRST_MODULE" ]
                        then
                            mkdir -p "$NEW_PROJECT_DIR"
                            mv "$_CANDIDATE" "$NEW_PROJECT_DIR/$FIRST_MODULE"
                            break
                        fi

                    done

                fi

                # A crash DURING scaffold (e.g. missing lxml_html_clean on
                # older Odoo) can leave an empty half-created module folder
                # behind - directory exists, but no __manifest__.py inside.
                # Detect that, try a one-time self-heal, and clean up any
                # empty leftover so it never looks "created" when it isn't.
                local MODULE_DIR="$NEW_PROJECT_DIR/$FIRST_MODULE"
                local MODULE_OK=0

                if [ -f "$MODULE_DIR/__manifest__.py" ] || [ -f "$MODULE_DIR/__openerp__.py" ]
                then
                    MODULE_OK=1
                elif [ -d "$MODULE_DIR" ]
                then

                    print_warning "Module folder was created but looks empty - environment issue detected, attempting to fix and retry..."

                    rm -rf "$MODULE_DIR"

                    source "$ODOO_PATH/env/bin/activate"
                    pip uninstall -y lxml_html_clean >/dev/null 2>&1
                    pip install "lxml<5" >/dev/null 2>&1

                    cd "$ODOO_PATH/odoo" 2>/dev/null

                    python3 odoo-bin scaffold "$FIRST_MODULE" "$NEW_PROJECT_DIR"

                    deactivate

                    if [ -f "$MODULE_DIR/__manifest__.py" ] || [ -f "$MODULE_DIR/__openerp__.py" ]
                    then
                        MODULE_OK=1
                    else
                        rm -rf "$MODULE_DIR"
                    fi

                fi

                if [ "$MODULE_OK" -eq 1 ]
                then
                    print_success "Module '$FIRST_MODULE' created."
                else
                    print_warning "Module scaffolding failed - the project itself is still ready to use."
                    print_warning "Run Workspace Doctor (H) to check/repair the Python environment, then try again."
                    FIRST_MODULE=""
                fi

            fi

        else

            print_warning "Invalid or empty module name - skipped module scaffolding."
            FIRST_MODULE=""

        fi

        echo

    fi

    if [ -d "$NEW_PROJECT_DIR/.git" ] && [ -n "$FIRST_MODULE" ]
    then

        if confirm "Commit the scaffolded module to git now?"
        then
            git -C "$NEW_PROJECT_DIR" add -A
            git -C "$NEW_PROJECT_DIR" commit -qm "Initial scaffold: $FIRST_MODULE"
            print_success "Committed initial module."
        fi

        echo

    fi

    separator
    echo
    print_success "✔ Project '$NEW_PROJECT' is ready."
    echo
    echo "Location : $NEW_PROJECT_DIR"
    [ -n "$FIRST_MODULE" ] && echo "Module   : $FIRST_MODULE"
    echo

    LAST_CREATED_PROJECT="$NEW_PROJECT"
    LAST_CREATED_MODULE="$FIRST_MODULE"
    export LAST_CREATED_PROJECT LAST_CREATED_MODULE

    pause

}

##############################################################################
# Delete Project
##############################################################################

delete_project()
{

    read -r -p "Project Name: " NAME

    if [ -z "$NAME" ]
    then
        return
    fi

    local TARGET="$ODOO_PATH/projects/$NAME"

    if [ ! -d "$TARGET" ]
    then
        print_warning "Project '$NAME' not found."
        return
    fi

    print_warning "This will PERMANENTLY delete '$TARGET' and all its modules."

    if confirm "Are you absolutely sure?"
    then

        rm -rf "$TARGET"

        print_success "Project deleted."

    else

        print_info "Cancelled."

    fi

}

##############################################################################
# Project Information
##############################################################################

project_info()
{

    show_header

    echo "Project"
    echo "-------"

    echo
    echo "Name"
    echo "$PROJECT_NAME"

    echo
    echo "Location"
    echo "$PROJECT_PATH"

    echo
    echo "Modules Location"
    echo "$PROJECT_PATH"

    echo

    pause

}

##############################################################################
# Module Upgrade Menu
##############################################################################

upgrade_module_menu()
{

    local ADDONS_DIR="$PROJECT_PATH"

    if [ ! -d "$ADDONS_DIR" ]
    then

        print_warning "Project directory not found."

        pause

        return

    fi

    while true
    do

        local MODULES=()

        for module in "$ADDONS_DIR"/*
        do
            if [ -d "$module" ] && { [ -f "$module/__manifest__.py" ] || [ -f "$module/__openerp__.py" ]; }
            then
                MODULES+=("$(basename "$module")")
            fi
        done

        show_header

        echo "Project   : $PROJECT_NAME"
        echo "Modules   : $ADDONS_DIR"

        separator

        echo
        menu_section "Modules"

        if [ ${#MODULES[@]} -eq 0 ]
        then

            print_warning "No modules found in this project."

            pause

            return

        fi

        local COUNT=1

        for MODULE in "${MODULES[@]}"
        do
            echo -e " ${GREEN}${COUNT}${NC}) $MODULE"
            COUNT=$((COUNT+1))
        done

        echo
        separator
        echo
        menu_section "Navigation"
        menu_item "R" "Refresh"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Module: "

        case "$CHOICE" in

            B|b)
                return
                ;;

            R|r)
                continue
                ;;

            *)

                if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]
                then
                    invalid_option
                    continue
                fi

                local INDEX=$((CHOICE-1))

                if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#MODULES[@]}" ]
                then
                    invalid_option
                    continue
                fi

                local SELECTED_MODULE="${MODULES[$INDEX]}"

                local DB_NAME
                DB_NAME="$(select_database)"

                if [ -z "$DB_NAME" ]
                then
                    print_warning "Database name is required to upgrade a module."
                    pause
                    return
                fi

                echo
                if confirm "Upgrade module '$SELECTED_MODULE' on database '$DB_NAME'?"
                then

                    show_header

                    echo "Upgrading module: $SELECTED_MODULE"
                    echo "Database        : $DB_NAME"
                    echo

                    upgrade_module "$SELECTED_MODULE" "$DB_NAME"

                fi

                pause

                return
                ;;

        esac

    done

}

##############################################################################
# Select Database
##############################################################################

select_database()
{

    local DATABASES=()

    if command_exists psql
    then

        while IFS= read -r DB
        do

            DB=$(echo "$DB" | xargs)

            if [ -n "$DB" ] && [ "$DB" != "template0" ] && [ "$DB" != "template1" ] && [ "$DB" != "postgres" ]
            then
                DATABASES+=("$DB")
            fi

        done < <(psql -lqt 2>/dev/null | cut -d '|' -f1)

    fi

    if [ ${#DATABASES[@]} -gt 0 ]
    then

        echo >&2
        echo "Available Databases" >&2
        echo >&2

        local COUNT=1

        for DB in "${DATABASES[@]}"
        do
            echo -e " ${GREEN}${COUNT}${NC}) $DB" >&2
            COUNT=$((COUNT+1))
        done

        echo >&2

    fi

    read -r -p "Database Name (or number): " INPUT >&2

    if [[ "$INPUT" =~ ^[0-9]+$ ]] && [ ${#DATABASES[@]} -gt 0 ]
    then

        local INDEX=$((INPUT-1))

        if [ "$INDEX" -ge 0 ] && [ "$INDEX" -lt "${#DATABASES[@]}" ]
        then
            echo "${DATABASES[$INDEX]}"
            return
        fi

    fi

    echo "$INPUT"

}

##############################################################################
# Create New Module (Scaffold)
##############################################################################

create_new_module()
{

    show_header

    echo "Create New Module"
    echo
    echo "Project  : $PROJECT_NAME"
    echo "Location : $PROJECT_PATH"

    separator

    echo
    read -r -p "Module Name: " MODULE_NAME

    if [ -z "$MODULE_NAME" ]
    then

        print_warning "Module name cannot be empty."

        pause

        return

    fi

    # Odoo module names: lowercase letters, numbers, underscores, must start with a letter
    if ! [[ "$MODULE_NAME" =~ ^[a-z][a-z0-9_]*$ ]]
    then

        print_warning "Invalid module name. Use lowercase letters, numbers and underscores only (must start with a letter)."

        pause

        return

    fi

    if [ -d "$PROJECT_PATH/$MODULE_NAME" ]
    then

        print_warning "Module '$MODULE_NAME' already exists in this project."

        pause

        return

    fi

    loading "Scaffolding module '$MODULE_NAME'..."

    source "$ODOO_PATH/env/bin/activate"

    cd "$ODOO_PATH/odoo" || {
        print_error "Unable to open Odoo directory."
        deactivate
        pause
        return
    }

    python3 odoo-bin scaffold "$MODULE_NAME" "$PROJECT_PATH"

    SCAFFOLD_STATUS=$?

    deactivate

    # Safety net: relocate the module into the project folder if
    # odoo-bin scaffold placed it somewhere else instead.
    if [ ! -d "$PROJECT_PATH/$MODULE_NAME" ]
    then

        CANDIDATE_PATHS=(
            "$ODOO_PATH/odoo/$MODULE_NAME"
            "$ODOO_PATH/$MODULE_NAME"
            "$ROOT_DIR/$MODULE_NAME"
            "$PWD/$MODULE_NAME"
        )

        for CANDIDATE in "${CANDIDATE_PATHS[@]}"
        do

            if [ -d "$CANDIDATE" ] && [ "$CANDIDATE" != "$PROJECT_PATH/$MODULE_NAME" ]
            then
                mkdir -p "$PROJECT_PATH"
                mv "$CANDIDATE" "$PROJECT_PATH/$MODULE_NAME"
                break
            fi

        done

    fi

    local TARGET_MODULE_DIR="$PROJECT_PATH/$MODULE_NAME"
    local MODULE_OK=0

    if [ -f "$TARGET_MODULE_DIR/__manifest__.py" ] || [ -f "$TARGET_MODULE_DIR/__openerp__.py" ]
    then
        MODULE_OK=1
    elif [ -d "$TARGET_MODULE_DIR" ]
    then

        # Directory exists but is empty/incomplete - almost always means
        # odoo-bin crashed mid-scaffold (e.g. missing lxml_html_clean on
        # older Odoo). Try a one-time self-heal and retry.
        print_warning "Module folder was created but looks empty - environment issue detected, attempting to fix and retry..."

        rm -rf "$TARGET_MODULE_DIR"

        source "$ODOO_PATH/env/bin/activate"
        pip uninstall -y lxml_html_clean >/dev/null 2>&1
        pip install "lxml<5" >/dev/null 2>&1

        cd "$ODOO_PATH/odoo" 2>/dev/null

        python3 odoo-bin scaffold "$MODULE_NAME" "$PROJECT_PATH"

        deactivate

        if [ -f "$TARGET_MODULE_DIR/__manifest__.py" ] || [ -f "$TARGET_MODULE_DIR/__openerp__.py" ]
        then
            MODULE_OK=1
        else
            rm -rf "$TARGET_MODULE_DIR"
        fi

    fi

    if [ "$MODULE_OK" -eq 1 ]
    then

        print_success "Module '$MODULE_NAME' created successfully."
        echo
        echo "Location: $TARGET_MODULE_DIR"

    else

        print_error "Module scaffolding failed."
        echo "Run Workspace Doctor (H) to check/repair the Python environment, then try again."

    fi

    pause

}

##############################################################################
# Database Manager
##############################################################################

database_menu()
{

    while true
    do

        show_header

        echo "Database Manager"
        echo "Project : $PROJECT_NAME"

        separator

        echo
        menu_section "Inspect"
        menu_item "1" "List Databases"
        echo

        menu_section "Create / Clone"
        menu_item "2" "Create Database"
        menu_item "3" "Duplicate Database"
        echo

        menu_section "Backup & Restore"
        menu_item "4" "Backup Database"
        menu_item "5" "Restore Database"
        echo

        menu_section "Danger Zone"
        menu_item "6" "Drop Database"
        echo

        menu_section "Quick Actions"
        menu_item "7" "Clone Database & Run (one-click)"
        echo

        separator
        echo
        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in

            1) list_databases_screen ;;
            2) create_database_screen ;;
            3) duplicate_database_screen ;;
            4) backup_database_screen ;;
            5) restore_database_screen ;;
            6) drop_database_screen ;;
            7) clone_and_run_screen ;;

            B|b)
                return
                ;;

            *)
                invalid_option
                ;;

        esac

    done

}

##############################################################################
# List Databases
##############################################################################

list_databases_screen()
{

    show_header

    echo "Databases"

    separator
    echo

    if ! command_exists psql
    then
        print_warning "psql not found."
        pause
        return
    fi

    local FOUND=0

    while IFS= read -r DB
    do

        DB=$(echo "$DB" | xargs)

        if [ -n "$DB" ] && [ "$DB" != "template0" ] && [ "$DB" != "template1" ] && [ "$DB" != "postgres" ]
        then
            echo " • $DB"
            FOUND=1
        fi

    done < <(psql -lqt 2>/dev/null | cut -d '|' -f1)

    if [ "$FOUND" -eq 0 ]
    then
        print_warning "No databases found."
    fi

    pause

}

##############################################################################
# Create Database
##############################################################################

create_database_screen()
{

    show_header

    echo "Create Database"

    separator
    echo

    if ! command_exists createdb
    then
        print_warning "createdb command not found."
        pause
        return
    fi

    read -r -p "New Database Name: " DB_NAME

    if [ -z "$DB_NAME" ]
    then
        print_warning "Database name required."
        pause
        return
    fi

    echo

    if createdb "$DB_NAME"
    then
        print_success "Database '$DB_NAME' created."
    else
        print_error "Failed to create database '$DB_NAME'."
    fi

    pause

}

##############################################################################
# Duplicate Database
##############################################################################

duplicate_database_screen()
{

    show_header

    echo "Duplicate Database"

    separator
    echo

    if ! command_exists createdb
    then
        print_warning "createdb command not found."
        pause
        return
    fi

    local SOURCE_DB
    SOURCE_DB="$(select_database)"

    if [ -z "$SOURCE_DB" ]
    then
        print_warning "Source database required."
        pause
        return
    fi

    read -r -p "New Database Name: " NEW_DB

    if [ -z "$NEW_DB" ]
    then
        print_warning "New database name required."
        pause
        return
    fi

    echo
    print_info "Duplicating '$SOURCE_DB' into '$NEW_DB'..."
    echo

    if createdb -T "$SOURCE_DB" "$NEW_DB"
    then
        print_success "Database duplicated successfully."
    else
        print_error "Failed to duplicate database. Make sure '$SOURCE_DB' has no active connections."
    fi

    pause

}

##############################################################################
# Backup Database
##############################################################################

backup_database_screen()
{

    show_header

    echo "Backup Database"

    separator
    echo

    if ! command_exists pg_dump
    then
        print_warning "pg_dump command not found."
        pause
        return
    fi

    local DB_NAME
    DB_NAME="$(select_database)"

    if [ -z "$DB_NAME" ]
    then
        print_warning "Database name required."
        pause
        return
    fi

    local BACKUP_DIR="$ODOO_PATH/backup"

    mkdir -p "$BACKUP_DIR"

    local TIMESTAMP
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)

    local BACKUP_FILE="$BACKUP_DIR/${DB_NAME}_${TIMESTAMP}.dump"

    echo
    print_info "Backing up '$DB_NAME'..."
    echo

    if pg_dump -Fc "$DB_NAME" -f "$BACKUP_FILE"
    then
        print_success "Backup created:"
        echo "$BACKUP_FILE"
    else
        print_error "Backup failed."
        rm -f "$BACKUP_FILE"
    fi

    pause

}

##############################################################################
# Restore Database
##############################################################################

restore_database_screen()
{

    show_header

    echo "Restore Database"

    separator
    echo

    if ! command_exists pg_restore
    then
        print_warning "pg_restore command not found."
        pause
        return
    fi

    local BACKUP_DIR="$ODOO_PATH/backup"

    if [ ! -d "$BACKUP_DIR" ]
    then
        print_warning "No backups found in $BACKUP_DIR"
        pause
        return
    fi

    local BACKUPS=()

    for f in "$BACKUP_DIR"/*.dump
    do
        [ -f "$f" ] && BACKUPS+=("$f")
    done

    if [ ${#BACKUPS[@]} -eq 0 ]
    then
        print_warning "No backup files found in $BACKUP_DIR"
        pause
        return
    fi

    echo "Available Backups"
    echo

    local COUNT=1

    for B in "${BACKUPS[@]}"
    do
        menu_item "$COUNT" "$(basename "$B")"
        COUNT=$((COUNT+1))
    done

    echo

    read -r -p "Select Backup: " CHOICE

    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]
    then
        invalid_option
        return
    fi

    local INDEX=$((CHOICE-1))

    if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#BACKUPS[@]}" ]
    then
        invalid_option
        return
    fi

    local SELECTED_BACKUP="${BACKUPS[$INDEX]}"

    read -r -p "Restore Into Database Name: " DB_NAME

    if [ -z "$DB_NAME" ]
    then
        print_warning "Database name required."
        pause
        return
    fi

    if ! createdb "$DB_NAME" 2>/dev/null
    then
        print_warning "Database '$DB_NAME' may already exist. Continuing restore into it."
    fi

    echo
    print_info "Restoring '$(basename "$SELECTED_BACKUP")' into '$DB_NAME'..."
    echo

    if pg_restore -d "$DB_NAME" --clean --if-exists "$SELECTED_BACKUP"
    then
        print_success "Restore completed."
    else
        print_warning "Restore finished with warnings (pg_restore commonly reports harmless notices)."
    fi

    pause

}

##############################################################################
# Drop Database
##############################################################################

drop_database_screen()
{

    show_header

    echo "Drop Database"

    separator
    echo

    if ! command_exists dropdb
    then
        print_warning "dropdb command not found."
        pause
        return
    fi

    local DB_NAME
    DB_NAME="$(select_database)"

    if [ -z "$DB_NAME" ]
    then
        print_warning "Database name required."
        pause
        return
    fi

    echo
    print_warning "This will PERMANENTLY delete database '$DB_NAME'."
    echo

    # ── Pre-drop safety: offer an automatic backup before deletion ──
    if command_exists pg_dump
    then

        local BACKUP_DIR="$ODOO_PATH/backup"
        mkdir -p "$BACKUP_DIR"

        local TIMESTAMP
        TIMESTAMP=$(date +%Y%m%d_%H%M%S)

        local PRE_DROP_FILE="$BACKUP_DIR/${DB_NAME}_predrop_${TIMESTAMP}.dump"

        if confirm "Create a safety backup of '$DB_NAME' before dropping? (recommended)"
        then

            print_info "Creating pre-drop backup..."
            echo

            if pg_dump -Fc "$DB_NAME" -f "$PRE_DROP_FILE" 2>/dev/null
            then
                print_success "Safety backup created:"
                echo "  $PRE_DROP_FILE"
                echo
            else
                print_warning "Pre-drop backup failed."
                rm -f "$PRE_DROP_FILE"
                echo

                if ! confirm "Continue dropping '$DB_NAME' WITHOUT a backup?"
                then
                    print_info "Cancelled - database is safe."
                    pause
                    return
                fi
            fi

        else

            print_warning "Skipping backup. Data will be unrecoverable after drop."
            echo

        fi

    fi

    if confirm "Are you absolutely sure you want to DROP '$DB_NAME'?"
    then

        if dropdb "$DB_NAME"
        then
            print_success "Database '$DB_NAME' dropped."
        else
            print_error "Failed to drop database (it may be in use)."
        fi

    else

        print_info "Cancelled."

    fi

    pause

}

##############################################################################
# Open Project (or a single Module) In Editor
##############################################################################

open_in_editor()
{

    show_header

    echo "Open in Editor"
    echo "Project  : $PROJECT_NAME"
    echo "Location : $PROJECT_PATH"

    separator

    echo
    menu_item "1" "Whole Project"
    menu_item "2" "A Specific Module"
    echo
    menu_item "B" "Back"
    echo

    read -r -p "What do you want to open? " SCOPE_CHOICE

    local TARGET_PATH="$PROJECT_PATH"
    local TARGET_LABEL="$PROJECT_NAME"

    case "$SCOPE_CHOICE" in

        1)
            : # TARGET_PATH already set to the whole project
            ;;

        2)

            local MODULES=()

            for module in "$PROJECT_PATH"/*
            do
                if [ -d "$module" ] && { [ -f "$module/__manifest__.py" ] || [ -f "$module/__openerp__.py" ]; }
                then
                    MODULES+=("$(basename "$module")")
                fi
            done

            if [ ${#MODULES[@]} -eq 0 ]
            then
                print_warning "No modules found in this project."
                pause
                return
            fi

            show_header

            echo "Select a Module to Open"
            echo "Project : $PROJECT_NAME"

            separator
            echo

            local COUNT=1
            for MOD in "${MODULES[@]}"
            do
                echo -e " ${GREEN}${COUNT}${NC}) $MOD"
                COUNT=$((COUNT+1))
            done

            echo
            read -r -p "Select Module: " MOD_CHOICE

            if ! [[ "$MOD_CHOICE" =~ ^[0-9]+$ ]]
            then
                invalid_option
                return
            fi

            local MOD_INDEX=$((MOD_CHOICE-1))

            if [ "$MOD_INDEX" -lt 0 ] || [ "$MOD_INDEX" -ge "${#MODULES[@]}" ]
            then
                invalid_option
                return
            fi

            TARGET_LABEL="${MODULES[$MOD_INDEX]}"
            TARGET_PATH="$PROJECT_PATH/$TARGET_LABEL"

            ;;

        B|b)
            return
            ;;

        *)
            invalid_option
            return
            ;;

    esac

    show_header

    echo "Open in Editor"
    echo "Opening  : $TARGET_LABEL"
    echo "Location : $TARGET_PATH"

    separator

    echo
    menu_item "1" "VS Code"
    menu_item "2" "Cursor"
    menu_item "3" "PyCharm"
    echo
    menu_item "B" "Back"
    echo

    read -r -p "Which editor do you want to open it with? " CHOICE

    case "$CHOICE" in

        1)

            local VSCODE_CMD
            VSCODE_CMD=$(detect_vscode_cmd)

            if [ -n "$VSCODE_CMD" ]
            then

                print_info "Opening '$TARGET_LABEL' in VS Code..."

                "$VSCODE_CMD" "$TARGET_PATH"

            else

                print_warning "VS Code is not installed."
                echo

                if confirm "Install VS Code now?"
                then
                    install_vscode
                    VSCODE_CMD=$(detect_vscode_cmd)
                    [ -n "$VSCODE_CMD" ] && "$VSCODE_CMD" "$TARGET_PATH"
                fi

            fi

            ;;

        2)

            local CURSOR_CMD
            CURSOR_CMD=$(detect_cursor_cmd)

            if [ -n "$CURSOR_CMD" ]
            then

                print_info "Opening '$TARGET_LABEL' in Cursor..."

                "$CURSOR_CMD" "$TARGET_PATH" >/dev/null 2>&1 &
                disown 2>/dev/null

            else

                print_warning "Cursor is not installed."
                echo

                if confirm "Install Cursor now?"
                then
                    install_cursor
                    CURSOR_CMD=$(detect_cursor_cmd)
                    if [ -n "$CURSOR_CMD" ]
                    then
                        "$CURSOR_CMD" "$TARGET_PATH" >/dev/null 2>&1 &
                        disown 2>/dev/null
                    fi
                fi

            fi

            ;;

        3)

            local PYCHARM_CMD
            PYCHARM_CMD=$(detect_pycharm_cmd)

            if [ -n "$PYCHARM_CMD" ]
            then

                print_info "Opening '$TARGET_LABEL' in PyCharm..."

                $PYCHARM_CMD "$TARGET_PATH" >/dev/null 2>&1 &
                disown 2>/dev/null

            else

                print_warning "PyCharm is not installed."
                echo

                if confirm "Install PyCharm Community now?"
                then
                    install_pycharm
                    PYCHARM_CMD=$(detect_pycharm_cmd)
                    if [ -n "$PYCHARM_CMD" ]
                    then
                        $PYCHARM_CMD "$TARGET_PATH" >/dev/null 2>&1 &
                        disown 2>/dev/null
                    fi
                fi

            fi

            ;;

        B|b)

            return
            ;;

        *)

            invalid_option

            return
            ;;

    esac

    pause

}

##############################################################################
# Project Quality Checks
##############################################################################

run_project_manifest_check()
{

    local FAILURES=0
    local MANIFEST

    for MANIFEST in "$PROJECT_PATH"/*/__manifest__.py "$PROJECT_PATH"/*/__openerp__.py
    do

        [ -f "$MANIFEST" ] || continue

        if python3 - <<'PY' "$MANIFEST" >/dev/null 2>&1
import ast
import pathlib
import sys

content = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
ast.literal_eval(content)
PY
        then
            print_success "Manifest OK: $(basename "$(dirname "$MANIFEST")")"
        else
            print_error "Manifest invalid: $MANIFEST"
            FAILURES=$((FAILURES+1))
        fi

    done

    if [ "$FAILURES" -eq 0 ]
    then
        print_success "All manifests look valid."
        return 0
    fi

    return 1

}

run_project_python_syntax_check()
{

    local FAILURES=0
    local FILE

    while IFS= read -r FILE
    do

        if python3 -m py_compile "$FILE" 2>/dev/null
        then
            :
        else
            print_error "Python syntax error: $FILE"
            FAILURES=$((FAILURES+1))
        fi

    done < <(find "$PROJECT_PATH" -type f -name "*.py" 2>/dev/null | sort)

    if [ "$FAILURES" -eq 0 ]
    then
        print_success "Python syntax check passed."
        return 0
    fi

    return 1

}

run_project_xml_syntax_check()
{

    local FAILURES=0
    local FILE

    while IFS= read -r FILE
    do

        if python3 - <<'PY' "$FILE" >/dev/null 2>&1
import sys
import xml.etree.ElementTree as ET

ET.parse(sys.argv[1])
PY
        then
            :
        else
            print_error "XML parse error: $FILE"
            FAILURES=$((FAILURES+1))
        fi

    done < <(find "$PROJECT_PATH" -type f -name "*.xml" 2>/dev/null | sort)

    if [ "$FAILURES" -eq 0 ]
    then
        print_success "XML syntax check passed."
        return 0
    fi

    return 1

}

run_all_project_quality_checks()
{

    local FAILURES=0

    echo
    print_info "Running manifest validation..."
    run_project_manifest_check || FAILURES=$((FAILURES+1))

    echo
    print_info "Running Python syntax validation..."
    run_project_python_syntax_check || FAILURES=$((FAILURES+1))

    echo
    print_info "Running XML syntax validation..."
    run_project_xml_syntax_check || FAILURES=$((FAILURES+1))

    echo
    if [ "$FAILURES" -eq 0 ]
    then
        print_success "All project quality checks passed."
        return 0
    fi

    print_warning "$FAILURES quality check group(s) reported issues."
    return 1

}

##############################################################################
# Test Runner & Lint Helpers
#
# Runs tests or lint tools against the current project. Uses the
# workspace's Python venv when available so project-local packages
# (pytest, flake8, etc.) are found automatically.
##############################################################################

_project_python()
{

    if [ -f "$ODOO_PATH/env/bin/python3" ]
    then
        echo "$ODOO_PATH/env/bin/python3"
    else
        echo "python3"
    fi

}

_project_pip_bin()
{

    if [ -f "$ODOO_PATH/env/bin/pip" ]
    then
        echo "$ODOO_PATH/env/bin/pip"
    else
        echo "pip3"
    fi

}

run_project_tests_screen()
{

    show_header

    echo "Run Project Tests"
    echo "Project : $PROJECT_NAME"
    echo "Path    : $PROJECT_PATH"

    separator
    echo

    local PYTHON
    PYTHON=$(_project_python)

    local TEST_METHOD=""

    echo "Test Method:"
    menu_item "1" "pytest (if installed)"
    menu_item "2" "Python unittest discover"
    menu_item "3" "Odoo --test-enable (selected modules)"
    echo
    menu_item "B" "Back"
    echo

    prompt_read T_CHOICE "Select Method: "

    case "$T_CHOICE" in

        1)
            if "$PYTHON" -m pytest --version >/dev/null 2>&1
            then
                TEST_METHOD="pytest"
            else
                print_warning "pytest not installed in the workspace venv."

                if confirm "Install pytest now?"
                then
                    $(_project_pip_bin) install pytest >/dev/null 2>&1
                    TEST_METHOD="pytest"
                else
                    print_info "Cancelled."
                    pause
                    return
                fi
            fi
            ;;

        2)
            TEST_METHOD="unittest"
            ;;

        3)
            TEST_METHOD="odoo"
            ;;

        B|b)
            return
            ;;

        *)
            invalid_option
            return
            ;;

    esac

    echo

    case "$TEST_METHOD" in

        pytest)
            print_info "Running pytest on $PROJECT_PATH ..."
            echo
            "$PYTHON" -m pytest "$PROJECT_PATH" -v --tb=short 2>&1
            ;;

        unittest)
            print_info "Running unittest discover on $PROJECT_PATH ..."
            echo
            "$PYTHON" -m unittest discover -s "$PROJECT_PATH" -v 2>&1
            ;;

        odoo)
            local MODULES=()
            for mod in "$PROJECT_PATH"/*
            do
                if [ -d "$mod" ] && { [ -f "$mod/__manifest__.py" ] || [ -f "$mod/__openerp__.py" ]; }
                then
                    MODULES+=("$(basename "$mod")")
                fi
            done

            if [ ${#MODULES[@]} -eq 0 ]
            then
                print_warning "No Odoo modules found in this project."
                pause
                return
            fi

            local MODULE_LIST
            MODULE_LIST=$(IFS=,; echo "${MODULES[*]}")

            print_info "Running Odoo tests for modules: $MODULE_LIST"
            echo

            if [ -f "$ODOO_PATH/odoo/odoo-bin" ]
            then
                source "$ODOO_PATH/env/bin/activate"
                cd "$ODOO_PATH/odoo" || return
                python3 odoo-bin -c "$CONFIG_FILE" -d "${ODOO_TEST_DB:-odoo_test}" \
                    -i "$MODULE_LIST" --test-enable --stop-after-init --no-http 2>&1
                deactivate
                cd - >/dev/null 2>&1
            else
                print_error "odoo-bin not found at $ODOO_PATH/odoo/odoo-bin"
            fi
            ;;

    esac

    echo
    separator
    echo
    pause

}

run_project_lint_screen()
{

    show_header

    echo "Lint Check"
    echo "Project : $PROJECT_NAME"
    echo "Path    : $PROJECT_PATH"

    separator
    echo

    local PYTHON
    PYTHON=$(_project_python)

    local HAS_ISSUES=0

    # flake8
    print_info "flake8 (Python lint)"

    if "$PYTHON" -m flake8 --version >/dev/null 2>&1
    then

        echo

        "$PYTHON" -m flake8 "$PROJECT_PATH" \
            --max-line-length=120 \
            --exclude=__pycache__,.git,migrations \
            --count \
            --statistics 2>&1

        [ $? -ne 0 ] && HAS_ISSUES=1

    else

        print_warning "flake8 not installed."

        if confirm "Install flake8 now?"
        then
            $(_project_pip_bin) install flake8 >/dev/null 2>&1
            echo
            "$PYTHON" -m flake8 "$PROJECT_PATH" \
                --max-line-length=120 \
                --exclude=__pycache__,.git,migrations \
                --count \
                --statistics 2>&1
            [ $? -ne 0 ] && HAS_ISSUES=1
        fi

    fi

    echo
    separator

    # pylint (optional)
    echo
    print_info "pylint (deep analysis)"

    if "$PYTHON" -m pylint --version >/dev/null 2>&1
    then

        echo

        "$PYTHON" -m pylint "$PROJECT_PATH" \
            --disable=C0114,C0115,C0116,R0903 \
            --max-line-length=120 \
            --score=y 2>&1 || HAS_ISSUES=1

    else

        print_warning "pylint not installed - skipped."

    fi

    echo
    separator
    echo

    if [ "$HAS_ISSUES" -eq 0 ]
    then
        print_success "All lint checks passed."
    else
        print_warning "Some lint issues found - see above."
    fi

    pause

}

project_quality_checks_menu()
{

    while true
    do

        show_header

        echo "Project Quality Checks"
        echo "Project : $PROJECT_NAME"
        echo "Path    : $PROJECT_PATH"

        separator
        echo

        menu_section "Validation"
        menu_item "1" "Validate Manifests"
        menu_item "2" "Check Python Syntax"
        menu_item "3" "Check XML Syntax"
        menu_item "4" "Run All Checks"
        echo

        menu_section "Tests & Lint"
        menu_item "5" "Run Tests (pytest / unittest / Odoo)"
        menu_item "6" "Lint Check (flake8 / pylint)"
        echo

        separator
        echo
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            1)
                show_header
                echo "Manifest Validation"
                separator
                run_project_manifest_check
                pause
                ;;
            2)
                show_header
                echo "Python Syntax Validation"
                separator
                run_project_python_syntax_check
                pause
                ;;
            3)
                show_header
                echo "XML Syntax Validation"
                separator
                run_project_xml_syntax_check
                pause
                ;;
            4)
                show_header
                echo "Project Quality Checks"
                separator
                run_all_project_quality_checks
                pause
                ;;
            5)
                run_project_tests_screen
                ;;
            6)
                run_project_lint_screen
                ;;
            B|b)
                return
                ;;
            *)
                invalid_option
                ;;
        esac

    done

}

##############################################################################
# Support Bundle
##############################################################################

build_support_bundle_contents()
{

    local STAGE_DIR="$1"

    mkdir -p "$STAGE_DIR"

    if [ -f "$CONFIG_FILE" ]
    then
        cp "$CONFIG_FILE" "$STAGE_DIR/odoo.conf"
    fi

    if [ -f "$LOG_FILE" ]
    then
        tail -n 300 "$LOG_FILE" > "$STAGE_DIR/odoo.log.tail" 2>/dev/null || true
    fi

    if type workspace_doctor_json_report >/dev/null 2>&1
    then
        workspace_doctor_json_report "$(basename "$ODOO_PATH")" > "$STAGE_DIR/workspace_doctor.json"
    fi

    {
        echo "generated_at=$(date '+%Y-%m-%d %H:%M:%S')"
        echo "manager_version=$VERSION"
        echo "workspace=$(basename "$ODOO_PATH")"
        echo "workspace_path=$ODOO_PATH"
        echo "project=$PROJECT_NAME"
        echo "project_path=$PROJECT_PATH"
        echo "user=$(whoami 2>/dev/null)"
        echo "hostname=$(hostname 2>/dev/null)"
        echo "kernel=$(uname -srmo 2>/dev/null)"
        echo "python3=$(python3 --version 2>/dev/null)"
        echo "git=$(git --version 2>/dev/null)"
        echo "psql=$(psql --version 2>/dev/null)"
    } > "$STAGE_DIR/system_info.txt"

    if command_exists df
    then
        df -h "$ODOO_PATH" > "$STAGE_DIR/disk_usage.txt" 2>/dev/null || true
    fi

    if command_exists free
    then
        free -h > "$STAGE_DIR/memory.txt" 2>/dev/null || true
    fi

    if [ -d "$PROJECT_PATH/.git" ]
    then
        git -C "$PROJECT_PATH" status --short > "$STAGE_DIR/project_git_status.txt" 2>/dev/null || true
        git -C "$PROJECT_PATH" log -n 10 --oneline > "$STAGE_DIR/project_git_log.txt" 2>/dev/null || true
    fi

    if [ -d "$(state_dir)" ]
    then
        mkdir -p "$STAGE_DIR/state"
        cp "$(state_file recent_workspaces)" "$STAGE_DIR/state/" 2>/dev/null || true
        cp "$(state_file recent_projects)" "$STAGE_DIR/state/" 2>/dev/null || true
        cp "$(state_file favorite_workspaces)" "$STAGE_DIR/state/" 2>/dev/null || true
        cp "$(state_file favorite_projects)" "$STAGE_DIR/state/" 2>/dev/null || true
    fi

}

export_support_bundle_screen()
{

    show_header

    echo "Export Support Bundle"
    echo "Workspace : $(basename "$ODOO_PATH")"
    echo "Project   : $PROJECT_NAME"

    separator
    echo
    echo "This collects:"
    echo "  - odoo.conf"
    echo "  - recent Odoo log tail"
    echo "  - workspace doctor JSON report"
    echo "  - system and disk info"
    echo "  - project git status/log (if available)"
    echo

    if ! confirm "Create support bundle?"
    then
        print_info "Cancelled."
        pause
        return
    fi

    local SUPPORT_DIR="$ODOO_PATH/support"
    mkdir -p "$SUPPORT_DIR"

    local STAGE_DIR
    STAGE_DIR=$(mktemp -d)

    local TIMESTAMP
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)

    local OUTPUT_FILE="$SUPPORT_DIR/$(basename "$ODOO_PATH")_support_${TIMESTAMP}.tar.gz"

    build_support_bundle_contents "$STAGE_DIR"

    if tar -czf "$OUTPUT_FILE" -C "$STAGE_DIR" .
    then
        print_success "Support bundle created:"
        echo "$OUTPUT_FILE"
    else
        print_error "Failed to create support bundle."
        rm -f "$OUTPUT_FILE"
    fi

    rm -rf "$STAGE_DIR"

    pause

}

##############################################################################
# Workspace Archives & Snapshots
##############################################################################

create_workspace_payload_archive()
{

    local OUTPUT_FILE="$1"
    local INCLUDE_LOGS="${2:-0}"
    local PAYLOAD=()
    local ITEM

    for ITEM in custom_addons enterprise projects odoo/debian/odoo.conf
    do
        [ -e "$ODOO_PATH/$ITEM" ] && PAYLOAD+=("$ITEM")
    done

    if [ "$INCLUDE_LOGS" -eq 1 ] && [ -d "$ODOO_PATH/logs" ]
    then
        PAYLOAD+=("logs")
    fi

    [ ${#PAYLOAD[@]} -gt 0 ] || return 1

    tar -czf "$OUTPUT_FILE" -C "$ODOO_PATH" "${PAYLOAD[@]}"

}

create_snapshot_screen()
{

    show_header

    echo "Create Snapshot"
    echo "Workspace : $(basename "$ODOO_PATH")"
    echo "Project   : $PROJECT_NAME"

    separator
    echo
    echo "Snapshot includes:"
    echo "  - workspace archive"
    echo "  - doctor JSON report"
    echo "  - optional database dump"
    echo

    local SNAPSHOT_LABEL
    read -r -p "Snapshot label (optional): " SNAPSHOT_LABEL

    local SNAPSHOT_DIR="$ODOO_PATH/snapshots"
    mkdir -p "$SNAPSHOT_DIR"

    local STAGE_DIR
    STAGE_DIR=$(mktemp -d)

    local TIMESTAMP
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)

    create_workspace_payload_archive "$STAGE_DIR/workspace.tar.gz" 0 || {
        print_error "Failed to build workspace payload."
        rm -rf "$STAGE_DIR"
        pause
        return
    }

    local SNAPSHOT_DB=""
    if command_exists pg_dump && command_exists psql && confirm "Include a database dump in this snapshot?"
    then
        SNAPSHOT_DB="$(select_database)"

        if [ -n "$SNAPSHOT_DB" ]
        then
            pg_dump -Fc "$SNAPSHOT_DB" -f "$STAGE_DIR/database.dump" || {
                print_warning "Database dump failed - snapshot will continue without it."
                rm -f "$STAGE_DIR/database.dump"
                SNAPSHOT_DB=""
            }
        fi
    fi

    if type workspace_doctor_json_report >/dev/null 2>&1
    then
        workspace_doctor_json_report "$(basename "$ODOO_PATH")" > "$STAGE_DIR/workspace_doctor.json"
    fi

    {
        echo "workspace=$(basename "$ODOO_PATH")"
        echo "project=$PROJECT_NAME"
        echo "created_at=$(date '+%Y-%m-%d %H:%M:%S')"
        echo "label=$SNAPSHOT_LABEL"
        echo "database=$SNAPSHOT_DB"
        echo "version=$VERSION"
    } > "$STAGE_DIR/snapshot.meta"

    local SNAPSHOT_FILE="$SNAPSHOT_DIR/$(basename "$ODOO_PATH")_snapshot_${TIMESTAMP}.tar.gz"

    if tar -czf "$SNAPSHOT_FILE" -C "$STAGE_DIR" .
    then
        print_success "Snapshot created:"
        echo "$SNAPSHOT_FILE"
    else
        print_error "Snapshot creation failed."
        rm -f "$SNAPSHOT_FILE"
    fi

    rm -rf "$STAGE_DIR"

    pause

}

restore_snapshot_screen()
{

    show_header

    echo "Restore Snapshot"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    local SNAPSHOT_DIR="$ODOO_PATH/snapshots"

    if [ ! -d "$SNAPSHOT_DIR" ]
    then
        print_warning "No snapshots found in $SNAPSHOT_DIR"
        pause
        return
    fi

    local SNAPSHOTS=()
    local FILE

    for FILE in "$SNAPSHOT_DIR"/*_snapshot_*.tar.gz
    do
        [ -f "$FILE" ] && SNAPSHOTS+=("$FILE")
    done

    if [ ${#SNAPSHOTS[@]} -eq 0 ]
    then
        print_warning "No snapshot files found."
        pause
        return
    fi

    local COUNT=1
    for FILE in "${SNAPSHOTS[@]}"
    do
        menu_item "$COUNT" "$(basename "$FILE")"
        COUNT=$((COUNT+1))
    done

    echo
    menu_item "B" "Back"
    echo

    prompt_read CHOICE "Select Snapshot: "

    if [[ "$CHOICE" == "b" || "$CHOICE" == "B" ]]
    then
        return
    fi

    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]
    then
        invalid_option
        return
    fi

    local INDEX=$((CHOICE-1))
    if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#SNAPSHOTS[@]}" ]
    then
        invalid_option
        return
    fi

    local SELECTED_SNAPSHOT="${SNAPSHOTS[$INDEX]}"
    local STAGE_DIR
    STAGE_DIR=$(mktemp -d)

    if ! tar -xzf "$SELECTED_SNAPSHOT" -C "$STAGE_DIR"
    then
        print_error "Failed to extract snapshot."
        rm -rf "$STAGE_DIR"
        pause
        return
    fi

    print_warning "This will overwrite workspace payload files from the snapshot."
    echo

    if confirm "Restore workspace files now?"
    then
        if tar -xzf "$STAGE_DIR/workspace.tar.gz" -C "$ODOO_PATH"
        then
            print_success "Workspace files restored."
        else
            print_error "Workspace restore failed."
        fi
    fi

    if [ -f "$STAGE_DIR/database.dump" ] && command_exists pg_restore && confirm "Restore the snapshot database dump too?"
    then
        local SNAPSHOT_DB
        SNAPSHOT_DB=$(grep '^database=' "$STAGE_DIR/snapshot.meta" 2>/dev/null | cut -d '=' -f2-)

        read -r -p "Restore Into Database Name [${SNAPSHOT_DB:-new_db}]: " TARGET_DB
        TARGET_DB="${TARGET_DB:-${SNAPSHOT_DB:-new_db}}"

        if [ -n "$TARGET_DB" ]
        then
            createdb "$TARGET_DB" 2>/dev/null || true

            if pg_restore -d "$TARGET_DB" --clean --if-exists "$STAGE_DIR/database.dump"
            then
                print_success "Snapshot database restored into '$TARGET_DB'."
            else
                print_warning "Database restore completed with warnings."
            fi
        fi
    fi

    rm -rf "$STAGE_DIR"

    pause

}

##############################################################################
# Auto Backup Scheduler
#
# Sets up a system cron job to periodically dump all PostgreSQL databases
# into the workspace's backup/ directory. Supports daily or weekly
# schedules and a configurable retention policy (auto-delete old dumps).
##############################################################################

AUTO_BACKUP_SCRIPT_NAME="odoo_auto_backup.sh"
AUTO_BACKUP_CRON_TAG="# odoo-manager-auto-backup"

auto_backup_script_path()
{

    echo "$ODOO_PATH/backup/$AUTO_BACKUP_SCRIPT_NAME"

}

auto_backup_cron_entry_exists()
{

    crontab -l 2>/dev/null | grep -q "$AUTO_BACKUP_CRON_TAG"

}

auto_backup_show_status_screen()
{

    show_header

    echo "Auto Backup Scheduler"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    if auto_backup_cron_entry_exists
    then

        local CRON_LINE
        CRON_LINE=$(crontab -l 2>/dev/null | grep "$AUTO_BACKUP_CRON_TAG")

        print_success "Auto backup is ENABLED."
        echo
        echo "  Schedule : ${CRON_LINE%%$AUTO_BACKUP_CRON_TAG}"
        echo "  Script   : $(auto_backup_script_path)"
        echo "  Backups  : $ODOO_PATH/backup/"
        echo

    else

        print_warning "Auto backup is NOT configured."
        echo

    fi

    pause

}

auto_backup_setup_screen()
{

    show_header

    echo "Setup Auto Backup"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    if ! command_exists pg_dump
    then
        print_warning "pg_dump is required but not found."
        pause
        return
    fi

    if ! command_exists crontab
    then
        print_warning "crontab command not found - cannot schedule."
        pause
        return
    fi

    echo "Schedule:"
    menu_item "1" "Daily at 2:00 AM"
    menu_item "2" "Weekly (Sunday at 3:00 AM)"
    menu_item "3" "Custom cron expression"
    echo
    menu_item "B" "Back"
    echo

    prompt_read SCHEDULE_CHOICE "Select Schedule: "

    local CRON_SCHEDULE=""

    case "$SCHEDULE_CHOICE" in
        1) CRON_SCHEDULE="0 2 * * *" ;;
        2) CRON_SCHEDULE="0 3 * * 0" ;;
        3)
            echo
            read -r -p "Enter cron expression (e.g. '0 4 * * 1-5'): " CRON_SCHEDULE
            if [ -z "$CRON_SCHEDULE" ]
            then
                print_warning "Empty cron expression - cancelled."
                pause
                return
            fi
            ;;
        B|b)
            return
            ;;
        *)
            invalid_option
            return
            ;;
    esac

    echo

    local RETENTION_DAYS=""
    read -r -p "Keep backups for how many days? [7]: " RETENTION_DAYS
    RETENTION_DAYS="${RETENTION_DAYS:-7}"

    if ! [[ "$RETENTION_DAYS" =~ ^[0-9]+$ ]]
    then
        print_warning "Invalid number of days."
        pause
        return
    fi

    local BACKUP_DIR="$ODOO_PATH/backup"
    mkdir -p "$BACKUP_DIR"

    local SCRIPT_PATH
    SCRIPT_PATH=$(auto_backup_script_path)

    # Generate the backup script
    cat > "$SCRIPT_PATH" <<SCRIPT
#!/bin/bash
# Auto-generated by odoo-manager - do not edit manually
# Workspace: $(basename "$ODOO_PATH")
# Retention: ${RETENTION_DAYS} days

BACKUP_DIR="$BACKUP_DIR"
LOG_FILE="$BACKUP_DIR/auto_backup.log"
TIMESTAMP=\$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=$RETENTION_DAYS

echo "[\$TIMESTAMP] Auto backup started" >> "\$LOG_FILE"

# Backup all databases (except template dbs and postgres)
DATABASES=\$(psql -tAl 2>/dev/null | awk -F'|' 'NR>1 && \$1 !~ /^template/ && \$1 !~ /^postgres/ && \$1 ~ /^[a-zA-Z]/ {gsub(/^ +| +\$/,"",\$1); print \$1}')

SUCCESS=0
FAIL=0

for DB in \$DATABASES
do
    DUMP_FILE="\$BACKUP_DIR/\${DB}_auto_\${TIMESTAMP}.dump"
    if pg_dump -Fc "\$DB" -f "\$DUMP_FILE" 2>/dev/null
    then
        SUCCESS=\$((SUCCESS+1))
    else
        FAIL=\$((FAIL+1))
        rm -f "\$DUMP_FILE"
        echo "[\$TIMESTAMP] FAILED: \$DB" >> "\$LOG_FILE"
    fi
done

# Retention: delete backups older than RETENTION_DAYS
DELETED=\$(find "\$BACKUP_DIR" -name "*_auto_*.dump" -mtime +\${RETENTION_DAYS} -delete -print | wc -l)

END_TIME=\$(date +%Y%m%d_%H%M%S)
echo "[\$END_TIME] Done: \$SUCCESS ok, \$FAIL failed, \$DELETED old backups pruned" >> "\$LOG_FILE"
SCRIPT

    chmod +x "$SCRIPT_PATH"

    # Remove any existing auto-backup cron entry first
    local NEW_CRON
    NEW_CRON=$(crontab -l 2>/dev/null | grep -v "$AUTO_BACKUP_CRON_TAG" || true)
    NEW_CRON="${NEW_CRON}
${CRON_SCHEDULE} ${SCRIPT_PATH} ${AUTO_BACKUP_CRON_TAG}"

    echo "$NEW_CRON" | crontab -

    print_success "Auto backup configured."
    echo
    echo "  Schedule   : $CRON_SCHEDULE"
    echo "  Script     : $SCRIPT_PATH"
    echo "  Backup Dir : $BACKUP_DIR"
    echo "  Retention  : $RETENTION_DAYS days"
    echo "  Log        : $BACKUP_DIR/auto_backup.log"
    echo

    pause

}

auto_backup_disable_screen()
{

    show_header

    echo "Disable Auto Backup"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    if ! auto_backup_cron_entry_exists
    then
        print_warning "Auto backup is not configured."
        pause
        return
    fi

    if ! confirm "Remove the auto backup schedule?"
    then
        print_info "Cancelled."
        pause
        return
    fi

    local NEW_CRON
    NEW_CRON=$(crontab -l 2>/dev/null | grep -v "$AUTO_BACKUP_CRON_TAG" || true)

    echo "$NEW_CRON" | crontab -

    print_success "Auto backup disabled."

    local SCRIPT_PATH
    SCRIPT_PATH=$(auto_backup_script_path)

    if [ -f "$SCRIPT_PATH" ] && confirm "Also delete the backup script ($SCRIPT_PATH)?"
    then
        rm -f "$SCRIPT_PATH"
        print_success "Backup script removed."
    fi

    pause

}

##############################################################################
# Backup Retention Policy
#
# One-time cleanup: delete backup files older than N days.
##############################################################################

backup_retention_screen()
{

    show_header

    echo "Backup Retention Cleanup"
    echo "Workspace : $(basename "$ODOO_PATH")"

    separator
    echo

    local BACKUP_DIR="$ODOO_PATH/backup"

    if [ ! -d "$BACKUP_DIR" ]
    then
        print_warning "No backup directory found."
        pause
        return
    fi

    local TOTAL_COUNT
    TOTAL_COUNT=$(find "$BACKUP_DIR" -name "*.dump" -type f 2>/dev/null | wc -l | tr -d ' ')

    echo "Backup directory : $BACKUP_DIR"
    echo "Total .dump files: $TOTAL_COUNT"
    echo

    if [ "$TOTAL_COUNT" -eq 0 ]
    then
        print_info "Nothing to clean up."
        pause
        return
    fi

    read -r -p "Delete backups older than how many days? [30]: " DAYS
    DAYS="${DAYS:-30}"

    if ! [[ "$DAYS" =~ ^[0-9]+$ ]]
    then
        print_warning "Invalid number."
        pause
        return
    fi

    local OLD_COUNT
    OLD_COUNT=$(find "$BACKUP_DIR" -name "*.dump" -type f -mtime +"$DAYS" 2>/dev/null | wc -l | tr -d ' ')

    if [ "$OLD_COUNT" -eq 0 ]
    then
        print_success "No backups older than $DAYS days. Nothing to remove."
        pause
        return
    fi

    echo
    print_warning "$OLD_COUNT backup(s) older than $DAYS days will be deleted."
    echo

    if confirm "Proceed with cleanup?"
    then

        find "$BACKUP_DIR" -name "*.dump" -type f -mtime +"$DAYS" -delete

        print_success "$OLD_COUNT old backup(s) removed."

    else

        print_info "Cancelled."

    fi

    pause

}

##############################################################################
# Workspace Backup / Restore Menu
##############################################################################

workspace_backup_menu()
{

    while true
    do

        show_header

        echo "Workspace Backup"
        echo "Workspace : $(basename "$ODOO_PATH")"

        separator

        echo
        menu_section "Backup Actions"
        menu_item "1" "Create Backup"
        menu_item "2" "Restore Backup"
        menu_item "3" "Create Snapshot"
        menu_item "4" "Restore Snapshot"
        echo

        menu_section "Auto Backup"
        menu_item "5" "Auto Backup Status"
        menu_item "6" "Setup Auto Backup (cron)"
        menu_item "7" "Disable Auto Backup"
        menu_item "8" "Backup Retention Cleanup"
        echo

        separator
        echo
        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in

            1) backup_workspace_screen ;;
            2) restore_workspace_screen ;;
            3) create_snapshot_screen ;;
            4) restore_snapshot_screen ;;
            5) auto_backup_show_status_screen ;;
            6) auto_backup_setup_screen ;;
            7) auto_backup_disable_screen ;;
            8) backup_retention_screen ;;

            B|b)
                return
                ;;

            *)
                invalid_option
                ;;

        esac

    done

}

##############################################################################
# Create Workspace Backup
#
# Archives everything that ISN'T easily re-creatable: your addons,
# your projects, and odoo.conf. The Odoo source (odoo/) and Python
# venv (env/) are left out on purpose - they can be re-cloned /
# re-installed, and including them would make backups huge.
##############################################################################

backup_workspace_screen()
{

    show_header

    echo "Backup Workspace"
    echo "Workspace : $ODOO_PATH"

    separator

    echo
    echo "This will archive:"
    echo "  - custom_addons/"
    echo "  - enterprise/"
    echo "  - projects/  (all project modules)"
    echo "  - odoo/debian/odoo.conf"
    echo
    echo -e "${DIM}Not included (re-creatable): Odoo source (odoo/), Python venv (env/), logs/${NC}"
    echo

    if ! confirm "Create workspace backup?"
    then
        print_info "Cancelled."
        pause
        return
    fi

    local BACKUP_DIR="$ODOO_PATH/backup"

    mkdir -p "$BACKUP_DIR"

    local TIMESTAMP
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)

    local WS_NAME
    WS_NAME=$(basename "$ODOO_PATH")

    local BACKUP_FILE="$BACKUP_DIR/${WS_NAME}_workspace_${TIMESTAMP}.tar.gz"

    echo
    print_info "Archiving workspace... this may take a moment."
    echo

    if create_workspace_payload_archive "$BACKUP_FILE" 0 2>/dev/null
    then

        print_success "Workspace backup created:"
        echo "$BACKUP_FILE"

        if command_exists du
        then
            echo "Size: $(du -h "$BACKUP_FILE" 2>/dev/null | cut -f1)"
        fi

    else

        print_error "Backup failed."

        rm -f "$BACKUP_FILE"

    fi

    pause

}

##############################################################################
# Restore Workspace Backup
##############################################################################

restore_workspace_screen()
{

    show_header

    echo "Restore Workspace"
    echo "Workspace : $ODOO_PATH"

    separator

    echo

    local BACKUP_DIR="$ODOO_PATH/backup"

    if [ ! -d "$BACKUP_DIR" ]
    then
        print_warning "No backups found in $BACKUP_DIR"
        pause
        return
    fi

    local BACKUPS=()

    for f in "$BACKUP_DIR"/*_workspace_*.tar.gz
    do
        [ -f "$f" ] && BACKUPS+=("$f")
    done

    if [ ${#BACKUPS[@]} -eq 0 ]
    then
        print_warning "No workspace backups found in $BACKUP_DIR"
        pause
        return
    fi

    echo "Available Workspace Backups"
    echo

    local COUNT=1

    for B in "${BACKUPS[@]}"
    do
        menu_item "$COUNT" "$(basename "$B")"
        COUNT=$((COUNT+1))
    done

    echo
    menu_item "B" "Back"
    echo

    read -r -p "Select Backup: " CHOICE

    if [[ "$CHOICE" == "b" || "$CHOICE" == "B" ]]
    then
        return
    fi

    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]]
    then
        invalid_option
        return
    fi

    local INDEX=$((CHOICE-1))

    if [ "$INDEX" -lt 0 ] || [ "$INDEX" -ge "${#BACKUPS[@]}" ]
    then
        invalid_option
        return
    fi

    local SELECTED="${BACKUPS[$INDEX]}"

    echo
    print_warning "This will OVERWRITE the current custom_addons/, enterprise/,"
    print_warning "projects/, and odoo.conf with the contents of this backup."
    echo

    if confirm "Restore from '$(basename "$SELECTED")'?"
    then

        print_info "Restoring..."
        echo

        if tar -xzf "$SELECTED" -C "$ODOO_PATH"
        then
            print_success "Workspace restored successfully."
        else
            print_error "Restore failed."
        fi

    else

        print_info "Cancelled."

    fi

    pause

}
