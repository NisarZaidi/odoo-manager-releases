#!/bin/bash

##############################################################################
# ui.sh
# User Interface
##############################################################################

##############################################################################
# Header
##############################################################################

show_header()
{

    clear

    local WIDTH=68
    local BORDER
    BORDER=$(printf '═%.0s' $(seq 1 $WIDTH))

    echo -e "${CYAN}"
    printf "╔%s╗\n" "$BORDER"
    printf "║%s║\n" "$(center_text "ODOO DEVELOPMENT MANAGER" "$WIDTH")"
    printf "║%s║\n" "$(center_text "Version $VERSION" "$WIDTH")"
    printf "╠%s╣\n" "$BORDER"
    printf "║%s║\n" "$(center_text "Manage • Build • Debug • Deploy" "$WIDTH")"
    printf "║%s║\n" "$(center_text "Multiple Odoo Development Environments" "$WIDTH")"
    printf "╚%s╝\n" "$BORDER"
    echo -e "${NC}"
}

##############################################################################
# Workspace Information
##############################################################################

show_workspace_info()
{

    echo
    printf "  ${WHITE}%-11s${NC} %s\n" "Workspace" "$WORKSPACE_ROOT"

    if [ -n "$ODOO_PATH" ]
    then
        local ODOO_LABEL
        ODOO_LABEL="$(basename "$ODOO_PATH")"

        if type is_workspace_favorite >/dev/null 2>&1 && is_workspace_favorite "$ODOO_PATH"
        then
            ODOO_LABEL="${ODOO_LABEL} ${YELLOW}★${NC}"
        fi

        printf "  ${WHITE}%-11s${NC} %b\n" "Odoo" "$ODOO_LABEL"
    fi

    if [ -n "$PROJECT_NAME" ]
    then
        local PROJECT_LABEL
        PROJECT_LABEL="$PROJECT_NAME"

        if type is_project_favorite >/dev/null 2>&1 && is_project_favorite "$ODOO_PATH" "$PROJECT_PATH"
        then
            PROJECT_LABEL="${PROJECT_LABEL} ${YELLOW}★${NC}"
        fi

        printf "  ${WHITE}%-11s${NC} %b\n" "Project" "$PROJECT_LABEL"
    fi

    if [ -n "$CONFIG_FILE" ]
    then
        printf "  ${WHITE}%-11s${NC} ${DIM}%s${NC}\n" "Config" "$CONFIG_FILE"
    fi

    if [ -n "$ODOO_PATH" ] && [ -d "$ODOO_PATH" ] && command_exists is_odoo_running
    then

        if is_odoo_running
        then

            local RUNNING_PID
            RUNNING_PID=$(get_odoo_pid 2>/dev/null)

            local RUNNING_PORT=""
            if command_exists get_configured_port
            then
                RUNNING_PORT=$(get_configured_port 2>/dev/null)
            fi

            if [ -n "$RUNNING_PORT" ]
            then
                printf "  ${WHITE}%-11s${NC} ${GREEN}● Running${NC}  ${DIM}(PID ${RUNNING_PID:-?}, port ${RUNNING_PORT})${NC}\n" "Status"
            else
                printf "  ${WHITE}%-11s${NC} ${GREEN}● Running${NC}  ${DIM}(PID ${RUNNING_PID:-?})${NC}\n" "Status"
            fi

        else

            printf "  ${WHITE}%-11s${NC} ${DIM}○ Stopped${NC}\n" "Status"

        fi

    fi

    # Project-level summary - only inside a specific project's Development
    # Menu (both workspace and project are chosen).
    if [ -n "$PROJECT_PATH" ] && [ -d "$PROJECT_PATH" ]
    then

        local P_MODULE_COUNT=0
        local m

        for m in "$PROJECT_PATH"/*
        do
            if [ -d "$m" ] && { [ -f "$m/__manifest__.py" ] || [ -f "$m/__openerp__.py" ]; }
            then
                P_MODULE_COUNT=$((P_MODULE_COUNT+1))
            fi
        done

        printf "  ${WHITE}%-11s${NC} %s\n" "Modules" "$P_MODULE_COUNT"

        if command_exists project_git_badge
        then

            local P_GIT_BADGE
            P_GIT_BADGE=$(project_git_badge "$PROJECT_PATH" 2>/dev/null)

            if [ -n "$P_GIT_BADGE" ]
            then
                echo -e "  ${WHITE}Git${NC}         : $P_GIT_BADGE"
            else
                echo -e "  ${WHITE}Git${NC}         : ${DIM}not a repo${NC}"
            fi

        fi

        if command_exists project_git_last_commit
        then

            local P_LAST_COMMIT
            P_LAST_COMMIT=$(project_git_last_commit "$PROJECT_PATH" 2>/dev/null)

            [ -n "$P_LAST_COMMIT" ] && printf "  ${WHITE}%-11s${NC} ${DIM}%s${NC}\n" "Last Commit" "$P_LAST_COMMIT"

        fi

        if command_exists project_git_ahead_behind && project_is_git_repo "$PROJECT_PATH" 2>/dev/null
        then

            local P_AHEAD_BEHIND
            P_AHEAD_BEHIND=$(project_git_ahead_behind "$PROJECT_PATH" 2>/dev/null)

            [ -n "$P_AHEAD_BEHIND" ] && printf "  ${WHITE}%-11s${NC} ${DIM}%s${NC}\n" "Remote" "$P_AHEAD_BEHIND"

        fi

        if command_exists du
        then

            local P_SIZE
            P_SIZE=$(du -sh "$PROJECT_PATH" 2>/dev/null | cut -f1)

            [ -n "$P_SIZE" ] && printf "  ${WHITE}%-11s${NC} %s\n" "Size" "$(human_size "$P_SIZE")"

        fi

    fi

    # Workspace-level summary - only on the project selection screen
    # (ODOO_PATH chosen, but no project chosen yet), so it doesn't repeat
    # once you're already inside a project's Development Menu.
    if [ -n "$ODOO_PATH" ] && [ -d "$ODOO_PATH" ] && [ -z "$PROJECT_NAME" ]
    then

        if [ -d "$ODOO_PATH/odoo/.git" ]
        then
            printf "  ${WHITE}%-11s${NC} ${GREEN}✔ Cloned${NC}\n" "Odoo Source"
        else
            printf "  ${WHITE}%-11s${NC} ${RED}✘ Not cloned${NC}\n" "Odoo Source"
        fi

        if [ -f "$ODOO_PATH/odoo/debian/odoo.conf" ]
        then

            local WS_PORT
            WS_PORT=$(grep "^http_port" "$ODOO_PATH/odoo/debian/odoo.conf" 2>/dev/null | cut -d '=' -f2- | xargs)

            [ -n "$WS_PORT" ] && printf "  ${WHITE}%-11s${NC} %s\n" "HTTP Port" "$WS_PORT"

        fi

        if [ -d "$ODOO_PATH/projects" ]
        then

            local PROJ_COUNT MODULE_TOTAL
            PROJ_COUNT=$(find "$ODOO_PATH/projects" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')
            MODULE_TOTAL=$(find "$ODOO_PATH/projects" -mindepth 2 -maxdepth 2 -name "__manifest__.py" 2>/dev/null | wc -l | tr -d ' ')

            if type count_odoo_modules_in_dir >/dev/null 2>&1 && [ -d "$ODOO_PATH/custom_addons" ]
            then
                local LEGACY_MODULES
                LEGACY_MODULES=$(count_odoo_modules_in_dir "$ODOO_PATH/custom_addons")

                if [ "$LEGACY_MODULES" -gt 0 ]
                then
                    PROJ_COUNT=$((PROJ_COUNT + 1))
                    MODULE_TOTAL=$((MODULE_TOTAL + LEGACY_MODULES))
                fi
            fi

            printf "  ${WHITE}%-11s${NC} %s\n" "Projects" "$PROJ_COUNT"
            printf "  ${WHITE}%-11s${NC} %s\n" "Modules" "$MODULE_TOTAL"

        fi

        if [ -d "$ODOO_PATH/env" ] && command_exists du
        then

            local WS_SIZE
            WS_SIZE=$(du -sh "$ODOO_PATH" 2>/dev/null | cut -f1)

            [ -n "$WS_SIZE" ] && printf "  ${WHITE}%-11s${NC} %s\n" "Disk Usage" "$(human_size "$WS_SIZE")"

        fi

    fi

    # Extra at-a-glance info - only shown at the top-level (workspace not
    # yet selected), so it doesn't clutter screens deeper in the menu.
    if [ -z "$ODOO_PATH" ]
    then

        if [ "${#WORKSPACES[@]}" -gt 0 ] 2>/dev/null
        then

            printf "  ${WHITE}%-11s${NC} %s\n" "Found" "${#WORKSPACES[@]} workspace(s)"

            # How many of the found workspaces have Odoo running right now,
            # and how many projects exist across all of them combined.
            local RUNNING_COUNT=0
            local TOTAL_PROJECTS=0
            local WS

            for WS in "${WORKSPACES[@]}"
            do

                if command_exists is_workspace_running && is_workspace_running "$WS" >/dev/null 2>&1
                then
                    RUNNING_COUNT=$((RUNNING_COUNT+1))
                fi

                if [ -d "$WS/projects" ]
                then
                    local WS_PROJECTS
                    WS_PROJECTS=$(find "$WS/projects" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')
                    TOTAL_PROJECTS=$((TOTAL_PROJECTS + WS_PROJECTS))
                fi

                if type count_odoo_modules_in_dir >/dev/null 2>&1 && [ -d "$WS/custom_addons" ]
                then
                    local LEGACY_WS_MODULES
                    LEGACY_WS_MODULES=$(count_odoo_modules_in_dir "$WS/custom_addons")

                    if [ "$LEGACY_WS_MODULES" -gt 0 ]
                    then
                        TOTAL_PROJECTS=$((TOTAL_PROJECTS + 1))
                    fi
                fi

            done

            if [ "$RUNNING_COUNT" -gt 0 ]
            then
                printf "  ${WHITE}%-11s${NC} ${GREEN}%s${NC} of %s active\n" "Running" "$RUNNING_COUNT" "${#WORKSPACES[@]}"
            else
                printf "  ${WHITE}%-11s${NC} ${DIM}none active${NC}\n" "Running"
            fi

            printf "  ${WHITE}%-11s${NC} %s total\n" "Projects" "$TOTAL_PROJECTS"

        fi

        if command_exists df && [ -d "$WORKSPACE_ROOT" ]
        then

            local FREE_SPACE
            FREE_SPACE=$(df -h "$WORKSPACE_ROOT" 2>/dev/null | awk 'NR==2 {print $4}')

            [ -n "$FREE_SPACE" ] && printf "  ${WHITE}%-11s${NC} %s free\n" "Disk" "$(human_size "$FREE_SPACE")"

        fi

        if command_exists free
        then

            local MEM_FREE_RAW MEM_TOTAL_RAW
            MEM_FREE_RAW=$(free -h 2>/dev/null | awk '/^Mem:/ {print $7}')
            MEM_TOTAL_RAW=$(free -h 2>/dev/null | awk '/^Mem:/ {print $2}')

            if [ -n "$MEM_FREE_RAW" ] && [ -n "$MEM_TOTAL_RAW" ]
            then
                printf "  ${WHITE}%-11s${NC} %s free of %s\n" "Memory" "$(human_size "$MEM_FREE_RAW")" "$(human_size "$MEM_TOTAL_RAW")"
            fi

        fi

        if command_exists check_database_connection
        then

            if check_database_connection
            then
                printf "  ${WHITE}%-11s${NC} ${GREEN}● Reachable${NC}\n" "PostgreSQL"
            else
                printf "  ${WHITE}%-11s${NC} ${YELLOW}● Not reachable${NC}\n" "PostgreSQL"
            fi

        fi

        if command_exists python3
        then
            printf "  ${WHITE}%-11s${NC} %s\n" "Python" "$(python3 --version 2>&1 | awk '{print $2}')"
        fi

        if command_exists git
        then
            printf "  ${WHITE}%-11s${NC} %s\n" "Git" "$(git --version 2>/dev/null | awk '{print $3}')"
        fi

        if [ -f /etc/os-release ]
        then
            local OS_NAME
            OS_NAME=$(. /etc/os-release && echo "$PRETTY_NAME")
            [ -n "$OS_NAME" ] && printf "  ${WHITE}%-11s${NC} ${DIM}%s${NC}\n" "System" "$OS_NAME"
        fi

    fi

    echo

}

##############################################################################
# Expand a du/df/free short-form size suffix (K/M/G/T) into a proper
# short unit label (KB/MB/GB/TB), e.g. "480M" -> "480 MB", "171G" -> "171 GB"
##############################################################################

human_size()
{

    local RAW="$1"

    [ -z "$RAW" ] && return

    local NUM UNIT

    NUM=$(echo "$RAW" | sed -E 's/[A-Za-z]+$//')
    UNIT=$(echo "$RAW" | sed -E 's/^[0-9.,]+//')

    case "$UNIT" in
        K|Ki) UNIT="KB" ;;
        M|Mi) UNIT="MB" ;;
        G|Gi) UNIT="GB" ;;
        T|Ti) UNIT="TB" ;;
        B|"") UNIT="B"  ;;
        *)    UNIT="$UNIT" ;;
    esac

    echo "${NUM} ${UNIT}"

}

##############################################################################
# Separator
##############################################################################

separator()
{
    line
}

##############################################################################
# Menu Title
##############################################################################

menu_title()
{

    echo
    separator
    echo
    echo -e " ${CYAN}▶${NC} ${BOLD}${WHITE}$1${NC}"
    echo
}

##############################################################################
# Quit Option
##############################################################################

show_quit()
{

    echo
	separator
    echo

    menu_section "Workspace Actions"
    menu_item "N" "Create New Workspace"
    menu_item "R" "Refresh"
    echo

    menu_section "Setup Tools"
    menu_item "I" "Install Development Tools (VS Code / Cursor / PyCharm)"
    menu_item "Y" "Install System Requirements (Git / Python / pip / PostgreSQL / openssl)"
    echo

    menu_section "Global Tools"
    menu_item "B" "Batch Operations (all workspaces)"
    menu_item "E" "Environment Templates"
    menu_item "M" "Remote Server Management"
    menu_item "A" "Custom Aliases"
    echo

    menu_section "Navigation"
    menu_item "Q" "Quit"

    echo

    echo -e "  ${DIM}Note: type a NUMBER (e.g. 1) to open that workspace and choose a project.${NC}"
    echo -e "  ${DIM}      type a LETTER (N/R/I/Y/B/E/M/A/Q) to run that action instead.${NC}"
    echo -e "  ${DIM}Tip: each workspace gets its own port, so you can run more than${NC}"
    echo -e "  ${DIM}one Odoo version at the same time.${NC}"
    echo

}

##############################################################################
# Quit Project Option
##############################################################################

show_Project_quit()
{

    echo
	separator
    echo

    menu_section "Project Actions"
    menu_item "N" "Project Generator"
    menu_item "R" "Refresh"
    echo

    menu_section "Project Tools"
    menu_item "T" "Time Tracker"
    menu_item "D" "Project Metadata (client/deadline)"
    menu_item "S" "Team Sync (export/import config)"
    echo

    menu_section "Navigation"
    menu_item "B" "Back"
    menu_item "Q" "Quit"

    echo

    echo -e "  ${DIM}Note: type a NUMBER (e.g. 1) to open that project's Development Menu.${NC}"
    echo -e "  ${DIM}      type a LETTER (N/R/T/D/S/B/Q) to run that action instead.${NC}"
    echo

}

##############################################################################
# Menu Item (colorized letter + label, consistent across all menus)
##############################################################################

menu_item()
{

    printf "  ${GREEN}%s${NC}) %s\n" "$1" "$2"

}

##############################################################################
# Menu Section Label (grouping header, e.g. "▶ Odoo Management")
##############################################################################

menu_section()
{

    echo -e " ${CYAN}▶ ${BOLD}${WHITE}$1${NC}"

}

##############################################################################
# Colored Input Prompt (consistent across every menu that reads a choice)
#
# Usage: prompt_read CHOICE "Select Option: "
# Sets the variable named in $1 to whatever the user typed - works because
# bash's "read" without a preceding "local" in this function resolves the
# variable name against the caller's scope (dynamic scoping).
##############################################################################

prompt_read()
{

    local __VARNAME="$1"
    local __LABEL="$2"

    echo -en "  ${GREEN}${__LABEL}${NC}"

    read -r "$__VARNAME"

}

##############################################################################
# Invalid Option
##############################################################################

invalid_option()
{

    print_error "  ✘ Invalid option. Please try again."

    sleep 1

}

##############################################################################
# Workspace List
##############################################################################

show_workspace_menu()
{

    show_header
    show_workspace_info

    menu_title "Available Odoo Versions"

    local COUNT=1

    for workspace in "${WORKSPACES[@]}"
    do

        local WS_NAME
        WS_NAME="$(basename "$workspace")"

        local PROJECT_COUNT=0

        if [ -d "$workspace/projects" ]
        then
            PROJECT_COUNT=$(find "$workspace/projects" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')
        fi

        local STATUS_TEXT
        local STATUS_DOT

        if is_workspace_running "$workspace" >/dev/null 2>&1
        then
            STATUS_DOT="${GREEN}●${NC}"
            STATUS_TEXT="${GREEN}Running${NC}"
        else
            STATUS_DOT="${DIM}○${NC}"
            STATUS_TEXT="${DIM}Stopped${NC}"
        fi

        local CLONED_TEXT
        if [ -d "$workspace/odoo/.git" ]
        then
            CLONED_TEXT="${GREEN}✔${NC}"
        else
            CLONED_TEXT="${RED}✘ not cloned${NC}"
        fi

        local WS_MARKERS=""
        if type is_workspace_favorite >/dev/null 2>&1 && is_workspace_favorite "$workspace"
        then
            WS_MARKERS="${WS_MARKERS} ${YELLOW}★ favorite${NC}"
        fi
        if type is_workspace_recent >/dev/null 2>&1 && is_workspace_recent "$workspace"
        then
            WS_MARKERS="${WS_MARKERS} ${CYAN}recent${NC}"
        fi

        printf "  ${GREEN}%s${NC}) ${BOLD}${WHITE}%-10s${NC}%b %b %b\n" "$COUNT" "$WS_NAME" "$WS_MARKERS" "$STATUS_DOT" "$STATUS_TEXT"
        echo -e "       ${DIM}Projects${NC}    : ${CYAN}${PROJECT_COUNT}${NC}"
        echo -e "       ${DIM}Odoo Source${NC} : ${CLONED_TEXT}"
        echo

        COUNT=$((COUNT+1))

    done

    if [ ${#WORKSPACES[@]} -eq 0 ]
    then
        echo -e "  ${DIM}No workspaces yet - create one below to get started.${NC}"
        echo
    fi

    show_quit

}

##############################################################################
# Project List
##############################################################################

show_project_menu()
{

    show_header
    show_workspace_info

    menu_title "Projects"

    local COUNT=1

    for project in "${PROJECTS[@]}"
    do

        local PROJ_NAME
        PROJ_NAME="$(basename "$project")"

        local MODULE_COUNT=0

        for m in "$project"/*
        do
            if [ -d "$m" ] && { [ -f "$m/__manifest__.py" ] || [ -f "$m/__openerp__.py" ]; }
            then
                MODULE_COUNT=$((MODULE_COUNT+1))
            fi
        done

        local PROJ_MARKERS=""
        if type is_project_favorite >/dev/null 2>&1 && is_project_favorite "$ODOO_PATH" "$project"
        then
            PROJ_MARKERS="${PROJ_MARKERS} ${YELLOW}★ favorite${NC}"
        fi
        if type is_project_recent >/dev/null 2>&1 && is_project_recent "$ODOO_PATH" "$project"
        then
            PROJ_MARKERS="${PROJ_MARKERS} ${CYAN}recent${NC}"
        fi

        printf "  ${GREEN}%s${NC}) ${BOLD}${WHITE}%s${NC}%b\n" "$COUNT" "$PROJ_NAME" "$PROJ_MARKERS"

        local GIT_BADGE
        GIT_BADGE=$(project_git_badge "$project" 2>/dev/null)

        echo -e "       ${DIM}Modules${NC}     : ${CYAN}${MODULE_COUNT}${NC}"

        if [ -n "$GIT_BADGE" ]
        then
            echo -e "       ${DIM}Git${NC}         : $GIT_BADGE"
        else
            echo -e "       ${DIM}Git${NC}         : ${DIM}not a repo${NC}"
        fi

        if command_exists project_git_last_commit
        then

            local LAST_COMMIT
            LAST_COMMIT=$(project_git_last_commit "$project" 2>/dev/null)

            [ -n "$LAST_COMMIT" ] && echo -e "       ${DIM}Last Commit${NC} : ${DIM}${LAST_COMMIT}${NC}"

        fi

        if command_exists du
        then

            local PROJ_SIZE
            PROJ_SIZE=$(du -sh "$project" 2>/dev/null | cut -f1)

            [ -n "$PROJ_SIZE" ] && echo -e "       ${DIM}Size${NC}        : ${DIM}$(human_size "$PROJ_SIZE")${NC}"

        fi

        echo

        COUNT=$((COUNT+1))

    done

    if [ ${#PROJECTS[@]} -eq 0 ]
    then
        echo -e "  ${DIM}No projects yet - create one below to get started.${NC}"
        echo
    fi

    show_Project_quit

}

##############################################################################
# Main Menu
##############################################################################

show_main_menu()
{

    show_header
    show_workspace_info

    menu_title "Development Menu"

    menu_section "Odoo Management"
    menu_item "S" "Start Odoo"
    menu_item "R" "Restart Odoo"
    menu_item "K" "Stop Odoo"
    menu_item "L" "View Logs"
    menu_item "X" "Shell Shortcuts (Odoo/psql/venv)"
    menu_item "Z" "Log Search (grep/filter)"
    echo

    menu_section "Module Management"
    menu_item "U" "Upgrade Module"
    menu_item "M" "Create New Module"
    menu_item "I" "Manifest Inspector"
    echo

    menu_section "Database & Workspace"
    menu_item "D" "Database Manager"
    menu_item "A" "Backup / Restore / Snapshots / Auto Backup"
    menu_item "H" "Workspace Doctor"
    menu_item "E" "Export Support Bundle"
    menu_item "N" "Workspace Notes"
    echo

    menu_section "Development Tools"
    menu_item "O" "Update Odoo Core"
    menu_item "V" "Open in Editor (whole project or a single module)"
    menu_item "G" "Git Status"
    menu_item "C" "Configuration"
    menu_item "T" "Project Quality Checks / Tests / Lint"
    echo

    menu_section "Advanced Tools"
    menu_item "7" "Advanced Module Scaffold"
    menu_item "8" "Module Dependency Graph"
    menu_item "9" "Module Quality Checker"
    menu_item "M" "DB Migration Helper"
    menu_item "W" "DB Snapshot & Compare"
    menu_item "P" "Multi-Database Testing"
    echo

    menu_section "Overview & Environment"
    menu_item "1" "Dashboard (unified overview)"
    menu_item "2" "Config Profiles (dev/staging/prod)"
    menu_item "3" "System Resource Check"
    menu_item "4" "License Info"
    menu_item "5" "Export Environment"
    menu_item "6" "Import Environment"
    echo

    menu_section "Navigation"
    menu_item "F" "Toggle Favorite Workspace"
    menu_item "J" "Toggle Favorite Project"
    menu_item "B" "Back"
    menu_item "Q" "Quit"
    echo

    separator
    echo
    echo -e "  ${DIM}Tip: 'odoo-manager --help' shows CLI commands for scripts/automation.${NC}"
    echo -e "  ${DIM}Tip: Start Odoo (S) offers a Hot Reload option for auto-restart on file changes.${NC}"
    echo

}

##############################################################################
# Workspace Wizard Header
##############################################################################

show_wizard_header()
{

    show_header

    print_info "  First Time Setup Wizard"

    echo

    separator

    echo

}

##############################################################################
# Success Screen
##############################################################################

show_success()
{

    show_header

    print_success "  ✔ $1"

    echo

}

##############################################################################
# Error Screen
##############################################################################

show_error()
{

    show_header

    print_error "  ✘ $1"

    echo

}

##############################################################################
# Loading Message
##############################################################################

loading()
{

    echo
    print_info "  $1"
    echo

}

##############################################################################
# Wizard Step Progress
##############################################################################

wizard_progress()
{

    local STEP="$1"
    local TOTAL="$2"
    local MESSAGE="$3"

    echo
    echo -e "  ${CYAN}[${STEP}/${TOTAL}]${NC} ${BOLD}${MESSAGE}${NC}"
    echo

}

##############################################################################
# Welcome
##############################################################################

welcome()
{

    show_header

    echo "  Welcome to Odoo Development Manager"
    echo
    echo "  This tool helps you manage multiple"
    echo "  Odoo development environments."
    echo

}

##############################################################################
# Goodbye
##############################################################################

goodbye()
{

    show_header

    local WIDTH=68
    local BORDER
    BORDER=$(printf '─%.0s' $(seq 1 $WIDTH))

    echo -e "${CYAN}"
    printf "┌%s┐\n" "$BORDER"
    printf "│%s│\n" "$(center_text "✔ Session Closed Successfully" "$WIDTH")"
    printf "└%s┘\n" "$BORDER"
    echo -e "${NC}"

    if [ -n "$SESSION_START" ]
    then

        local ELAPSED=$(( $(date +%s) - SESSION_START ))
        local ELAPSED_H=$((ELAPSED / 3600))
        local ELAPSED_M=$(((ELAPSED % 3600) / 60))
        local ELAPSED_S=$((ELAPSED % 60))

        local ELAPSED_TEXT
        if [ "$ELAPSED_H" -gt 0 ]
        then
            ELAPSED_TEXT=$(printf "%dh %dm %ds" "$ELAPSED_H" "$ELAPSED_M" "$ELAPSED_S")
        elif [ "$ELAPSED_M" -gt 0 ]
        then
            ELAPSED_TEXT=$(printf "%dm %ds" "$ELAPSED_M" "$ELAPSED_S")
        else
            ELAPSED_TEXT=$(printf "%ds" "$ELAPSED_S")
        fi

        printf "  ${WHITE}%-14s${NC} %s\n" "Session Length" "$ELAPSED_TEXT"

    fi

    printf "  ${WHITE}%-14s${NC} %s\n" "Ended At" "$(date '+%Y-%m-%d %H:%M:%S')"
    printf "  ${WHITE}%-14s${NC} v%s\n" "Version" "$VERSION"

    echo
    separator
    echo

    echo -e "  ${DIM}All running Odoo instances have been stopped.${NC}"
    echo -e "  ${DIM}Your workspaces, projects, and databases were left untouched.${NC}"
    echo
    echo -e "  ${DIM}Run 'odoo-manager' anytime to pick up where you left off.${NC}"
    echo -e "  ${DIM}Run 'odoo-manager --help' for CLI / scripting usage.${NC}"
    echo
    echo -e "  ${CYAN}Happy Coding • Happy Debugging • Happy Developing${NC}"
    echo

}
