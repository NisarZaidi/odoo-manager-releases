#!/bin/bash

##############################################################################
# timetrack.sh
# Per-Project Time Tracker
# Tracks time spent on each project for billing/productivity
##############################################################################

timetrack_dir()
{
    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}/timetrack"
}

timetrack_file()
{
    local KEY="$1"
    mkdir -p "$(timetrack_dir)"
    echo "$(timetrack_dir)/${KEY}.log"
}

##############################################################################
# Start tracking time for current project
##############################################################################

timetrack_start()
{

    if [ -z "$PROJECT_PATH" ] || [ -z "$ODOO_PATH" ]
    then
        print_error "No project selected."
        return 1
    fi

    local WS_NAME
    WS_NAME="$(basename "$ODOO_PATH")"
    local PROJ_NAME
    PROJ_NAME="$(basename "$PROJECT_PATH")"
    local KEY="${WS_NAME}_${PROJ_NAME}"
    local LOG_FILE
    LOG_FILE="$(timetrack_file "$KEY")"

    # Check if already tracking
    if [ -f "${LOG_FILE}.active" ]
    then
        local START_TIME
        START_TIME=$(cat "${LOG_FILE}.active")
        local ELAPSED=$(( $(date +%s) - START_TIME ))
        local MINS=$((ELAPSED / 60))

        print_warning "Already tracking since ${MINS}m ago."
        return 1
    fi

    date +%s > "${LOG_FILE}.active"

    print_success "Time tracking started for $PROJ_NAME"
    echo -e "  ${DIM}Started at: $(date '+%H:%M:%S')${NC}"

}

##############################################################################
# Stop tracking and record the session
##############################################################################

timetrack_stop()
{

    if [ -z "$PROJECT_PATH" ] || [ -z "$ODOO_PATH" ]
    then
        print_error "No project selected."
        return 1
    fi

    local WS_NAME
    WS_NAME="$(basename "$ODOO_PATH")"
    local PROJ_NAME
    PROJ_NAME="$(basename "$PROJECT_PATH")"
    local KEY="${WS_NAME}_${PROJ_NAME}"
    local LOG_FILE
    LOG_FILE="$(timetrack_file "$KEY")"

    if [ ! -f "${LOG_FILE}.active" ]
    then
        print_warning "No active tracking session."
        return 1
    fi

    local START_TIME
    START_TIME=$(cat "${LOG_FILE}.active")
    local END_TIME
    END_TIME=$(date +%s)
    local DURATION=$((END_TIME - START_TIME))

    # Log the session
    echo "$(date -d @"$START_TIME" '+%Y-%m-%d %H:%M:%S')|$(date -d @"$END_TIME" '+%Y-%m-%d %H:%M:%S')|$DURATION" >> "$LOG_FILE"

    # Remove active marker
    rm -f "${LOG_FILE}.active"

    local HOURS=$((DURATION / 3600))
    local MINS=$(( (DURATION % 3600) / 60 ))
    local SECS=$((DURATION % 60))

    print_success "Time tracking stopped for $PROJ_NAME"
    echo -e "  ${WHITE}Duration${NC}: ${HOURS}h ${MINS}m ${SECS}s"

}

##############################################################################
# Show time report for current project
##############################################################################

timetrack_report()
{

    show_header
    echo "Time Tracking Report"
    separator
    echo

    local TT_DIR
    TT_DIR="$(timetrack_dir)"

    if [ ! -d "$TT_DIR" ] || [ -z "$(ls -A "$TT_DIR"/*.log 2>/dev/null)" ]
    then
        print_info "No time tracking data yet."
        echo
        echo -e "  ${DIM}Use the Time Tracker from the Development Menu to start tracking.${NC}"
        pause
        return
    fi

    local LOG_FILE
    for LOG_FILE in "$TT_DIR"/*.log
    do
        local PROJ_KEY
        PROJ_KEY="$(basename "$LOG_FILE" .log)"
        local WS_NAME="${PROJ_KEY%%_*}"
        local PROJ_NAME="${PROJ_KEY#*_}"

        # Calculate totals
        local TOTAL_SECS=0
        local SESSION_COUNT=0

        while IFS='|' read -r start end duration
        do
            [ -z "$duration" ] && continue
            TOTAL_SECS=$((TOTAL_SECS + duration))
            SESSION_COUNT=$((SESSION_COUNT + 1))
        done < "$LOG_FILE"

        local HOURS=$((TOTAL_SECS / 3600))
        local MINS=$(( (TOTAL_SECS % 3600) / 60 ))

        echo -e "  ${CYAN}${BOLD}$WS_NAME / $PROJ_NAME${NC}"
        echo -e "    ${WHITE}Total Time${NC} : ${HOURS}h ${MINS}m"
        echo -e "    ${WHITE}Sessions${NC}   : $SESSION_COUNT"

        # Show recent sessions (last 5)
        if [ "$SESSION_COUNT" -gt 0 ]
        then
            echo -e "    ${DIM}Recent sessions:${NC}"
            tail -n 5 "$LOG_FILE" | while IFS='|' read -r start end duration
            do
                local H=$((duration / 3600))
                local M=$(( (duration % 3600) / 60 ))
                echo -e "      ${DIM}$start → $end (${H}h ${M}m)${NC}"
            done
        fi

        echo
    done

    pause

}

##############################################################################
# Export time report to CSV
##############################################################################

timetrack_export_csv()
{

    local EXPORT_FILE="$HOME/timetrack_export_$(date +%Y%m%d).csv"

    echo "Project,Workspace,Date,Start,End,Duration_Minutes" > "$EXPORT_FILE"

    local TT_DIR
    TT_DIR="$(timetrack_dir)"

    if [ ! -d "$TT_DIR" ]
    then
        print_warning "No data to export."
        return
    fi

    local LOG_FILE
    for LOG_FILE in "$TT_DIR"/*.log
    do
        local PROJ_KEY
        PROJ_KEY="$(basename "$LOG_FILE" .log)"
        local WS_NAME="${PROJ_KEY%%_*}"
        local PROJ_NAME="${PROJ_KEY#*_}"

        while IFS='|' read -r start end duration
        do
            [ -z "$duration" ] && continue
            local MINS=$((duration / 60))
            echo "$PROJ_NAME,$WS_NAME,${start%% *},$start,$end,$MINS" >> "$EXPORT_FILE"
        done < "$LOG_FILE"
    done

    print_success "Exported to: $EXPORT_FILE"

}

##############################################################################
# Time tracker menu
##############################################################################

timetrack_menu()
{

    while true
    do

        show_header

        echo "Time Tracker"
        echo -e "${DIM}Track time spent on projects${NC}"

        separator
        echo

        if [ -n "$PROJECT_PATH" ] && [ -n "$ODOO_PATH" ]
        then
            local PROJ_NAME
            PROJ_NAME="$(basename "$PROJECT_PATH")"

            if [ -f "$(timetrack_file "$(basename "$ODOO_PATH")_${PROJ_NAME}").active" ]
            then
                local START_TIME
                START_TIME=$(cat "$(timetrack_file "$(basename "$ODOO_PATH")_${PROJ_NAME}").active")
                local ELAPSED=$(( $(date +%s) - START_TIME ))
                local H=$((ELAPSED / 3600))
                local M=$(( (ELAPSED % 3600) / 60 ))

                echo -e "  ${GREEN}● Tracking${NC}: $PROJ_NAME (${H}h ${M}m elapsed)"
            else
                echo -e "  ${DIM}○ Not tracking${NC}"
            fi

            echo
        fi

        menu_item "1" "Start Tracking"
        menu_item "2" "Stop Tracking"
        menu_item "3" "View Report"
        menu_item "4" "Export to CSV"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            1) timetrack_start; pause ;;
            2) timetrack_stop; pause ;;
            3) timetrack_report ;;
            4) timetrack_export_csv; pause ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}
