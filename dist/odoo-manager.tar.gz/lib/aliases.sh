#!/bin/bash

##############################################################################
# aliases.sh
# Custom Command Aliases
# Users can define their own shortcut commands
##############################################################################

aliases_config_file()
{
    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}/aliases.conf"
}

##############################################################################
# Load custom aliases
##############################################################################

load_custom_aliases()
{

    local CONF
    CONF="$(aliases_config_file)"

    [ -f "$CONF" ] || return 0

    while IFS='=' read -r alias_name alias_cmd
    do
        alias_name=$(echo "$alias_name" | xargs)
        alias_cmd=$(echo "$alias_cmd" | xargs)

        [ -z "$alias_name" ] && continue
        [[ "$alias_name" == \#* ]] && continue

        # Create a shell function for each alias
        eval "alias_${alias_name}() { $alias_cmd; }"
    done < "$CONF"

}

##############################################################################
# Add a new alias
##############################################################################

add_custom_alias()
{

    show_header
    echo "Add Custom Alias"
    separator
    echo

    echo "Define a shortcut command for frequently used operations."
    echo
    echo "Examples:"
    echo -e "  ${DIM}dev = start --workspace odoo18 --project agri${NC}"
    echo -e "  ${DIM}deploy = git push && restart${NC}"
    echo

    read -r -p "Alias name (e.g., dev): " ALIAS_NAME

    if [ -z "$ALIAS_NAME" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    ALIAS_NAME=$(echo "$ALIAS_NAME" | tr -d ' ')

    read -r -p "Command (e.g., start --workspace odoo18 --project agri): " ALIAS_CMD

    if [ -z "$ALIAS_CMD" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    local CONF
    CONF="$(aliases_config_file)"
    mkdir -p "$(dirname "$CONF")"

    echo "$ALIAS_NAME = $ALIAS_CMD" >> "$CONF"

    echo
    print_success "Alias added: $ALIAS_NAME → $ALIAS_CMD"
    echo -e "  ${DIM}Use 'odoo-manager $ALIAS_NAME' to run this command${NC}"

    pause

}

##############################################################################
# List all custom aliases
##############################################################################

list_custom_aliases()
{

    local CONF
    CONF="$(aliases_config_file)"

    if [ ! -f "$CONF" ] || [ ! -s "$CONF" ]
    then
        echo -e "  ${DIM}No custom aliases defined.${NC}"
        return
    fi

    while IFS='=' read -r alias_name alias_cmd
    do
        alias_name=$(echo "$alias_name" | xargs)
        alias_cmd=$(echo "$alias_cmd" | xargs)

        [ -z "$alias_name" ] && continue
        [[ "$alias_name" == \#* ]] && continue

        printf "  ${GREEN}%-15s${NC} → %s\n" "$alias_name" "$alias_cmd"
    done < "$CONF"

}

##############################################################################
# Delete a custom alias
##############################################################################

delete_custom_alias()
{

    show_header
    echo "Delete Custom Alias"
    separator
    echo

    list_custom_aliases
    echo

    read -r -p "Alias name to delete: " DEL_NAME

    if [ -z "$DEL_NAME" ]
    then
        print_warning "Cancelled."
        pause
        return
    fi

    local CONF
    CONF="$(aliases_config_file)"

    if [ ! -f "$CONF" ]
    then
        print_error "No aliases file found."
        pause
        return
    fi

    if grep -q "^${DEL_NAME} = " "$CONF"
    then
        sed -i "/^${DEL_NAME} = /d" "$CONF"
        print_success "Alias '$DEL_NAME' deleted."
    else
        print_error "Alias '$DEL_NAME' not found."
    fi

    pause

}

##############################################################################
# Check if a command matches a custom alias and execute it
##############################################################################

try_custom_alias()
{

    local CMD="$1"
    shift

    local CONF
    CONF="$(aliases_config_file)"

    [ -f "$CONF" ] || return 1

    local ALIAS_CMD
    ALIAS_CMD=$(grep "^${CMD} = " "$CONF" 2>/dev/null | head -n1 | cut -d'=' -f2- | xargs)

    if [ -n "$ALIAS_CMD" ]
    then
        echo -e "${DIM}(running alias: $CMD → $ALIAS_CMD)${NC}"
        echo

        # Execute as CLI command
        run_cli $ALIAS_CMD "$@"
        return 0
    fi

    return 1

}

##############################################################################
# Aliases management menu
##############################################################################

aliases_menu()
{

    while true
    do

        show_header

        echo "Custom Command Aliases"
        echo -e "${DIM}Define shortcut commands for frequently used operations${NC}"

        separator
        echo

        list_custom_aliases

        echo
        separator
        echo

        menu_item "A" "Add New Alias"
        menu_item "D" "Delete Alias"
        echo

        menu_section "Navigation"
        menu_item "B" "Back"
        echo

        prompt_read CHOICE "Select Option: "

        case "$CHOICE" in
            A|a) add_custom_alias ;;
            D|d) delete_custom_alias ;;
            B|b) return ;;
            *) invalid_option ;;
        esac

    done

}
