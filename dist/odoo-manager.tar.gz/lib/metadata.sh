#!/bin/bash

##############################################################################
# metadata.sh
# Client/Project Metadata
# Store client name, project description, deadline per project
##############################################################################

metadata_dir()
{
    echo "${ODOO_MANAGER_STATE_HOME:-$HOME/.local/share/odoo-manager}/metadata"
}

metadata_file()
{
    local KEY="$1"
    mkdir -p "$(metadata_dir)"
    echo "$(metadata_dir)/${KEY}.json"
}

##############################################################################
# Set project metadata
##############################################################################

set_project_metadata()
{

    show_header
    echo "Project Metadata"
    separator
    echo

    if [ -z "$PROJECT_PATH" ] || [ -z "$ODOO_PATH" ]
    then
        print_error "No project selected."
        pause
        return
    fi

    local WS_NAME
    WS_NAME="$(basename "$ODOO_PATH")"
    local PROJ_NAME
    PROJ_NAME="$(basename "$PROJECT_PATH")"
    local KEY="${WS_NAME}_${PROJ_NAME}"
    local META_FILE
    META_FILE="$(metadata_file "$KEY")"

    # Load existing values
    local EXISTING_CLIENT="" EXISTING_DESC="" EXISTING_DEADLINE=""
    if [ -f "$META_FILE" ]
    then
        EXISTING_CLIENT=$(grep '"client"' "$META_FILE" | cut -d'"' -f4)
        EXISTING_DESC=$(grep '"description"' "$META_FILE" | cut -d'"' -f4)
        EXISTING_DEADLINE=$(grep '"deadline"' "$META_FILE" | cut -d'"' -f4)
    fi

    echo -e "  ${WHITE}Project${NC} : $PROJ_NAME"
    echo -e "  ${WHITE}Workspace${NC}: $WS_NAME"
    echo

    read -r -p "Client name [$EXISTING_CLIENT]: " CLIENT
    CLIENT="${CLIENT:-$EXISTING_CLIENT}"

    read -r -p "Description [$EXISTING_DESC]: " DESC
    DESC="${DESC:-$EXISTING_DESC}"

    read -r -p "Deadline (YYYY-MM-DD) [$EXISTING_DEADLINE]: " DEADLINE
    DEADLINE="${DEADLINE:-$EXISTING_DEADLINE}"

    cat > "$META_FILE" <<JSONEOF
{
    "project": "$PROJ_NAME",
    "workspace": "$WS_NAME",
    "client": "$CLIENT",
    "description": "$DESC",
    "deadline": "$DEADLINE",
    "updated": "$(date -Iseconds)"
}
JSONEOF

    echo
    print_success "Metadata saved."
    pause

}

##############################################################################
# Show project metadata
##############################################################################

show_project_metadata()
{

    if [ -z "$PROJECT_PATH" ] || [ -z "$ODOO_PATH" ]
    then
        return
    fi

    local WS_NAME
    WS_NAME="$(basename "$ODOO_PATH")"
    local PROJ_NAME
    PROJ_NAME="$(basename "$PROJECT_PATH")"
    local KEY="${WS_NAME}_${PROJ_NAME}"
    local META_FILE
    META_FILE="$(metadata_file "$KEY")"

    if [ ! -f "$META_FILE" ]
    then
        return
    fi

    local CLIENT DESC DEADLINE
    CLIENT=$(grep '"client"' "$META_FILE" | cut -d'"' -f4)
    DESC=$(grep '"description"' "$META_FILE" | cut -d'"' -f4)
    DEADLINE=$(grep '"deadline"' "$META_FILE" | cut -d'"' -f4)

    if [ -n "$CLIENT" ]
    then
        echo -e "  ${WHITE}Client${NC}    : $CLIENT"
    fi

    if [ -n "$DESC" ]
    then
        echo -e "  ${WHITE}Desc${NC}      : $DESC"
    fi

    if [ -n "$DEADLINE" ]
    then
        # Show warning if deadline is approaching (within 7 days)
        local TODAY_EPOCH
        TODAY_EPOCH=$(date +%s)
        local DEADLINE_EPOCH
        DEADLINE_EPOCH=$(date -d "$DEADLINE" +%s 2>/dev/null)

        if [ -n "$DEADLINE_EPOCH" ]
        then
            local DAYS_LEFT=$(( (DEADLINE_EPOCH - TODAY_EPOCH) / 86400 ))

            if [ "$DAYS_LEFT" -lt 0 ]
            then
                echo -e "  ${RED}Deadline${NC}  : $DEADLINE ${RED}(OVERDUE by ${DAYS_LEFT#-} days)${NC}"
            elif [ "$DAYS_LEFT" -le 7 ]
            then
                echo -e "  ${YELLOW}Deadline${NC}  : $DEADLINE ${YELLOW}($DAYS_LEFT days left)${NC}"
            else
                echo -e "  ${WHITE}Deadline${NC}  : $DEADLINE ($DAYS_LEFT days left)"
            fi
        else
            echo -e "  ${WHITE}Deadline${NC}  : $DEADLINE"
        fi
    fi

}

##############################################################################
# View all project metadata
##############################################################################

view_all_metadata()
{

    show_header
    echo "All Project Metadata"
    separator
    echo

    local META_DIR
    META_DIR="$(metadata_dir)"

    if [ ! -d "$META_DIR" ] || [ -z "$(ls -A "$META_DIR"/*.json 2>/dev/null)" ]
    then
        print_info "No project metadata saved yet."
        pause
        return
    fi

    local META_FILE
    for META_FILE in "$META_DIR"/*.json
    do
        local PROJ WS CLIENT DESC DEADLINE
        PROJ=$(grep '"project"' "$META_FILE" | cut -d'"' -f4)
        WS=$(grep '"workspace"' "$META_FILE" | cut -d'"' -f4)
        CLIENT=$(grep '"client"' "$META_FILE" | cut -d'"' -f4)
        DESC=$(grep '"description"' "$META_FILE" | cut -d'"' -f4)
        DEADLINE=$(grep '"deadline"' "$META_FILE" | cut -d'"' -f4)

        echo -e "  ${CYAN}${BOLD}$WS / $PROJ${NC}"
        [ -n "$CLIENT" ] && echo -e "    ${WHITE}Client${NC}   : $CLIENT"
        [ -n "$DESC" ] && echo -e "    ${WHITE}Desc${NC}     : $DESC"
        [ -n "$DEADLINE" ] && echo -e "    ${WHITE}Deadline${NC} : $DEADLINE"
        echo
    done

    pause

}
