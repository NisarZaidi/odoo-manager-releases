#!/bin/bash

##############################################################################
# team.sh
# Team Sync
# Export/import workspace config for team members
##############################################################################

##############################################################################
# Export team config
##############################################################################

export_team_config()
{

    show_header
    echo "Export Team Config"
    echo -e "${DIM}Share your workspace setup with team members${NC}"
    separator
    echo

    if [ -z "$ODOO_PATH" ] || [ ! -d "$ODOO_PATH" ]
    then
        print_error "No workspace selected."
        pause
        return
    fi

    local WS_NAME
    WS_NAME="$(basename "$ODOO_PATH")"
    local EXPORT_FILE="$ODOO_PATH/.odoo-team.json"

    # Collect config
    local ODOO_VERSION
    ODOO_VERSION=$(echo "$WS_NAME" | grep -oE '[0-9]+')

    local HTTP_PORT="" DB_NAME="" DB_USER="" ADDONS_PATH=""
    if [ -f "$CONFIG_FILE" ]
    then
        HTTP_PORT=$(grep "^http_port" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
        DB_NAME=$(grep "^db_name" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
        DB_USER=$(grep "^db_user" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
        ADDONS_PATH=$(grep "^addons_path" "$CONFIG_FILE" 2>/dev/null | cut -d '=' -f2- | xargs)
    fi

    # Collect project list
    local PROJECTS=""
    if [ -d "$ODOO_PATH/projects" ]
    then
        PROJECTS=$(find "$ODOO_PATH/projects" -mindepth 1 -maxdepth 1 -type d -exec basename {} \; 2>/dev/null | paste -sd ',' -)
    fi

    # Collect module list per project
    local MODULE_LIST=""
    if [ -d "$ODOO_PATH/projects" ]
    then
        local p
        for p in "$ODOO_PATH/projects"/*/custom_addons/*
        do
            if [ -d "$p" ] && [ -f "$p/__manifest__.py" ]
            then
                MODULE_LIST="${MODULE_LIST}$(basename "$(dirname "$(dirname "$p")")")/:$(basename "$p"),"
            fi
        done
    fi

    cat > "$EXPORT_FILE" <<JSONEOF
{
    "team_config_version": "1.0",
    "workspace": "$WS_NAME",
    "odoo_version": "$ODOO_VERSION",
    "http_port": "$HTTP_PORT",
    "db_user": "$DB_USER",
    "projects": "$PROJECTS",
    "modules": "$MODULE_LIST",
    "has_enterprise": $([ -d "$ODOO_PATH/enterprise" ] && echo "true" || echo "false"),
    "exported_by": "$(whoami)",
    "exported_at": "$(date -Iseconds)"
}
JSONEOF

    echo
    print_success "Team config exported: $EXPORT_FILE"
    echo
    echo -e "  ${WHITE}File${NC}     : .odoo-team.json (in workspace root)"
    echo -e "  ${WHITE}Projects${NC} : ${PROJECTS:-none}"
    echo -e "  ${WHITE}Port${NC}     : ${HTTP_PORT:-default}"
    echo
    echo -e "  ${DIM}Share this file via git. Team members run 'Import Team Config'${NC}"
    echo -e "  ${DIM}to replicate this workspace structure on their machine.${NC}"

    pause

}

##############################################################################
# Import team config
##############################################################################

import_team_config()
{

    show_header
    echo "Import Team Config"
    echo -e "${DIM}Replicate a teammate's workspace structure${NC}"
    separator
    echo

    if [ -z "$ODOO_PATH" ] || [ ! -d "$ODOO_PATH" ]
    then
        print_error "No workspace selected."
        pause
        return
    fi

    local IMPORT_FILE="$ODOO_PATH/.odoo-team.json"

    if [ ! -f "$IMPORT_FILE" ]
    then
        print_warning "No .odoo-team.json found in workspace root."
        echo
        echo -e "  ${DIM}Ask your teammate to export their config first,${NC}"
        echo -e "  ${DIM}then commit .odoo-team.json to git and pull it.${NC}"
        pause
        return
    fi

    local EXPORTED_BY EXPORTED_AT PROJ_LIST
    EXPORTED_BY=$(grep '"exported_by"' "$IMPORT_FILE" | cut -d'"' -f4)
    EXPORTED_AT=$(grep '"exported_at"' "$IMPORT_FILE" | cut -d'"' -f4)
    PROJ_LIST=$(grep '"projects"' "$IMPORT_FILE" | cut -d'"' -f4)

    echo -e "  ${WHITE}Config from${NC}: $EXPORTED_BY"
    echo -e "  ${WHITE}Exported at${NC}: ${EXPORTED_AT%T*}"
    echo -e "  ${WHITE}Projects${NC}   : ${PROJ_LIST:-none}"
    echo

    if ! confirm "Create missing project directories from this config?"
    then
        print_info "Cancelled."
        pause
        return
    fi

    local CREATED=0
    if [ -n "$PROJ_LIST" ]
    then
        IFS=',' read -ra PROJS <<< "$PROJ_LIST"
        local PROJ
        for PROJ in "${PROJS[@]}"
        do
            PROJ=$(echo "$PROJ" | xargs)
            [ -z "$PROJ" ] && continue

            local PROJ_DIR="$ODOO_PATH/projects/$PROJ"

            if [ -d "$PROJ_DIR" ]
            then
                echo -e "  ${DIM}$PROJ - already exists${NC}"
            else
                mkdir -p "$PROJ_DIR/custom_addons"
                echo -e "  ${GREEN}✔${NC} Created: $PROJ"
                CREATED=$((CREATED + 1))
            fi
        done
    fi

    echo
    print_success "Import complete. $CREATED project(s) created."
    echo -e "  ${DIM}Note: module code must be cloned/created separately.${NC}"

    pause

}
